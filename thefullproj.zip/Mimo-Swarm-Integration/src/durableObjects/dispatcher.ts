/**
 * Dispatcher Durable Object
 * Load balancer and pool manager for the executor swarm
 */

import { DurableObject } from 'cloudflare:workers';
import type {
  ExecutorInfo,
  PendingTask,
  SwarmMetrics,
  SwarmConfig,
  ExecutionRequest,
  ExecutionResponse,
} from '../types';
import { DEFAULT_CONFIG, EXECUTOR_STATUS } from '../types';
import { ExecutorDO } from './executor';

export class DispatcherDO implements DurableObject {
  private executorPool: Map<string, ExecutorInfo> = new Map();
  private queue: PendingTask[] = [];
  private metrics: SwarmMetrics = {
    totalExecutions: 0,
    successfulExecutions: 0,
    failedExecutions: 0,
    averageExecutionTime: 0,
    peakConcurrent: 0,
  };
  private config: SwarmConfig = DEFAULT_CONFIG;
  private processingQueue = false;

  constructor(
    private readonly ctx: DurableObjectState,
    private readonly env: Env
  ) {
    this.ctx.blockConcurrencyWhile(async () => {
      const stored = await this.ctx.storage.get<{
        executorPool: [string, ExecutorInfo][];
        metrics: SwarmMetrics;
        config: SwarmConfig;
      }>('dispatcher-state');

      if (stored) {
        this.executorPool = new Map(stored.executorPool || []);
        this.metrics = stored.metrics || this.metrics;
        this.config = stored.config || this.config;
      }

      await this.ctx.storage.setAlarm(Date.now() + this.config.gcIntervalMs);
    });
  }

  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);
    const method = request.method;

    if (url.pathname === '/health') {
      return this.handleHealth();
    }

    if (url.pathname === '/stats') {
      return this.handleStats();
    }

    if (method === 'POST' && url.pathname === '/execute') {
      try {
        const requestData: ExecutionRequest = await request.json();
        return await this.handleExecute(requestData);
      } catch (error: any) {
        return new Response(JSON.stringify({
          error: error.message,
        }), {
          status: 500,
          headers: { 'Content-Type': 'application/json' },
        });
      }
    }

    if (method === 'GET' && url.pathname === '/executors') {
      return this.handleListExecutors();
    }

    if (method === 'POST' && url.pathname === '/scale') {
      try {
        const { minExecutors, maxExecutors } = await request.json();
        return await this.handleScale(minExecutors, maxExecutors);
      } catch (error: any) {
        return new Response(JSON.stringify({
          error: error.message,
        }), {
          status: 500,
          headers: { 'Content-Type': 'application/json' },
        });
      }
    }

    if (method === 'POST' && url.pathname === '/clear') {
      return this.handleClearQueue();
    }

    return new Response('Not Found', { status: 404 });
  }

  private async handleHealth(): Promise<Response> {
    const idleExecutors = Array.from(this.executorPool.values())
      .filter(e => e.status === EXECUTOR_STATUS.IDLE).length;
    const busyExecutors = Array.from(this.executorPool.values())
      .filter(e => e.status === EXECUTOR_STATUS.BUSY).length;

    return new Response(JSON.stringify({
      status: 'healthy',
      poolSize: this.executorPool.size,
      idleExecutors,
      busyExecutors,
      queueLength: this.queue.length,
      config: this.config,
    }), {
      headers: { 'Content-Type': 'application/json' },
    });
  }

  private async handleStats(): Promise<Response> {
    return new Response(JSON.stringify({
      metrics: this.metrics,
      pool: Array.from(this.executorPool.values()),
      queueLength: this.queue.length,
    }), {
      headers: { 'Content-Type': 'application/json' },
    });
  }

  private async handleExecute(request: ExecutionRequest): Promise<Response> {
    const executionId = request.executionId || `exec-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const execution: PendingTask = {
      executionId,
      request: { ...request, executionId },
      submittedAt: Date.now(),
      priority: 0,
    };

    const executor = this.findAvailableExecutor();
    
    if (executor) {
      return await this.assignToExecutor(executor, execution);
    }

    if (this.executorPool.size < this.config.maxExecutors) {
      const executorId = await this.spawnExecutor();
      if (executorId) {
        return await this.assignToExecutor(executorId, execution);
      }
    }

    this.queue.push(execution);
    await this.saveState();

    if (!this.processingQueue) {
      this.processQueue();
    }

    return new Response(JSON.stringify({
      executionId,
      status: 'queued',
      queuePosition: this.queue.length,
      message: 'Execution queued - will start when executor available',
    }), {
      headers: { 'Content-Type': 'application/json' },
    });
  }

  private findAvailableExecutor(): string | null {
    for (const [id, info] of this.executorPool) {
      if (info.status === EXECUTOR_STATUS.IDLE) {
        return id;
      }
    }
    return null;
  }

  private async spawnExecutor(): Promise<string | null> {
    const executorId = `executor-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    try {
      const stub = this.ctx.env.EXECUTOR_DO.get(this.ctx.env.EXECUTOR_DO.idFromName(executorId));
      
      this.executorPool.set(executorId, {
        id: executorId,
        status: EXECUTOR_STATUS.STARTING,
        lastUsed: Date.now(),
      });
      
      const response = await stub.fetch('https://placeholder/health');
      
      if (response.ok) {
        this.executorPool.set(executorId, {
          id: executorId,
          status: EXECUTOR_STATUS.IDLE,
          lastUsed: Date.now(),
          warmupTime: Date.now() - parseInt(executorId.split('-')[1]),
        });
        
        await this.saveState();
        return executorId;
      }
    } catch (error) {
      console.error('Failed to spawn executor:', error);
      this.executorPool.delete(executorId);
    }
    
    return null;
  }

  private async assignToExecutor(executorId: string, task: PendingTask): Promise<Response> {
    const executor = this.executorPool.get(executorId);
    if (!executor) {
      return new Response(JSON.stringify({
        error: 'Executor not found',
        executionId: task.executionId,
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    executor.status = EXECUTOR_STATUS.BUSY;
    executor.currentExecution = task.executionId;
    await this.saveState();

    try {
      const stub = this.ctx.env.EXECUTOR_DO.get(
        this.ctx.env.EXECUTOR_DO.idFromName(executorId)
      );

      const startTime = Date.now();
      const response = await stub.fetch(new Request('https://placeholder/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(task.request),
      }));

      const result = await response.json() as ExecutionResponse;
      
      this.metrics.totalExecutions++;
      if (result.status === 'completed') {
        this.metrics.successfulExecutions++;
      } else {
        this.metrics.failedExecutions++;
      }
      
      const executionTime = Date.now() - startTime;
      this.metrics.averageExecutionTime = 
        (this.metrics.averageExecutionTime * (this.metrics.totalExecutions - 1) + executionTime) 
        / this.metrics.totalExecutions;

      executor.status = EXECUTOR_STATUS.IDLE;
      executor.lastUsed = Date.now();
      executor.currentExecution = undefined;
      await this.saveState();

      this.processQueue();

      return new Response(JSON.stringify({
        ...result,
        executorId,
        queuePosition: 0,
      }), {
        headers: { 'Content-Type': 'application/json' },
      });

    } catch (error: any) {
      executor.status = EXECUTOR_STATUS.DEAD;
      this.executorPool.delete(executorId);
      await this.saveState();

      await this.spawnExecutor();

      this.queue.unshift(task);
      this.processQueue();

      return new Response(JSON.stringify({
        error: 'Executor failed, task requeued',
        executionId: task.executionId,
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' },
      });
    }
  }

  private async processQueue(): Promise<void> {
    if (this.processingQueue) return;
    this.processingQueue = true;

    try {
      while (this.queue.length > 0) {
        const executorId = this.findAvailableExecutor();
        
        if (!executorId) {
          if (this.executorPool.size < this.config.maxExecutors) {
            const newId = await this.spawnExecutor();
            if (newId) {
              const task = this.queue.shift()!;
              await this.assignToExecutor(newId, task);
            }
          }
          break;
        }

        const task = this.queue.shift()!;
        await this.assignToExecutor(executorId, task);
      }
    } finally {
      this.processingQueue = false;
      await this.saveState();
    }
  }

  private async handleScale(minExecutors?: number, maxExecutors?: number): Promise<Response> {
    if (minExecutors !== undefined) {
      this.config.minExecutors = minExecutors;
    }
    if (maxExecutors !== undefined) {
      this.config.maxExecutors = maxExecutors;
    }

    while (this.executorPool.size < this.config.minExecutors) {
      await this.spawnExecutor();
    }

    await this.saveState();

    return new Response(JSON.stringify({
      success: true,
      poolSize: this.executorPool.size,
      config: this.config,
    }), {
      headers: { 'Content-Type': 'application/json' },
    });
  }

  private async handleListExecutors(): Promise<Response> {
    const executors = Array.from(this.executorPool.values()).map(e => ({
      id: e.id,
      status: e.status,
      lastUsed: e.lastUsed,
      currentExecution: e.currentExecution,
    }));

    return new Response(JSON.stringify(executors), {
      headers: { 'Content-Type': 'application/json' },
    });
  }

  private async handleClearQueue(): Promise<Response> {
    const cleared = this.queue.length;
    this.queue = [];
    await this.saveState();

    return new Response(JSON.stringify({
      success: true,
      cleared,
    }), {
      headers: { 'Content-Type': 'application/json' },
    });
  }

  private async saveState(): Promise<void> {
    await this.ctx.storage.put('dispatcher-state', {
      executorPool: Array.from(this.executorPool.entries()),
      metrics: this.metrics,
      config: this.config,
    });
  }

  async alarm(): Promise<void> {
    const now = Date.now();

    for (const [id, info] of this.executorPool) {
      if (info.status === EXECUTOR_STATUS.DEAD) {
        this.executorPool.delete(id);
      }
    }

    const idleExecutors = Array.from(this.executorPool.values())
      .filter(e => e.status === EXECUTOR_STATUS.IDLE);

    while (idleExecutors.length > this.config.minExecutors) {
      const oldest = idleExecutors.shift();
      if (oldest && (now - oldest.lastUsed) > this.config.idleTimeoutMs) {
        this.executorPool.delete(oldest.id);
      }
    }

    await this.ctx.storage.setAlarm(now + this.config.gcIntervalMs);
    await this.saveState();
  }
}

export interface Env {
  EXECUTOR_DO: DurableObjectNamespace;
}
