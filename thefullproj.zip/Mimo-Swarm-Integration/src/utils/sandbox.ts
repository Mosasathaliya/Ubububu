/**
 * Secure Sandbox for Code Execution
 * Provides isolation and security for executing untrusted code
 */

import type { ExecutionRequest, StreamMessage } from './types';

// Global console capture
let outputBuffer: string[] = [];
let flushCallback: ((msg: StreamMessage) => void) | null = null;

export function setOutputHandler(callback: (msg: StreamMessage) => void): void {
  flushCallback = callback;
}

function flushOutput(): void {
  if (flushCallback && outputBuffer.length > 0) {
    for (const line of outputBuffer) {
      flushCallback({
        type: 'stdout',
        data: line,
        timestamp: Date.now(),
      });
    }
    outputBuffer = [];
  }
}

// Secure console implementation
const secureConsole = {
  log: (...args: any[]) => {
    const line = args.map(a => {
      if (typeof a === 'object') {
        try {
          return JSON.stringify(a, null, 2);
        } catch {
          return String(a);
        }
      }
      return String(a);
    }).join(' ');
    outputBuffer.push(`[LOG] ${line}`);
  },
  error: (...args: any[]) => {
    const line = args.map(a => {
      if (typeof a === 'object') {
        try {
          return JSON.stringify(a, null, 2);
        } catch {
          return String(a);
        }
      }
      return String(a);
    }).join(' ');
    outputBuffer.push(`[ERROR] ${line}`);
    flushOutput();
  },
  warn: (...args: any[]) => {
    const line = args.map(a => {
      if (typeof a === 'object') {
        try {
          return JSON.stringify(a, null, 2);
        } catch {
          return String(a);
        }
      }
      return String(a);
    }).join(' ');
    outputBuffer.push(`[WARN] ${line}`);
  },
  info: (...args: any[]) => {
    const line = args.map(a => {
      if (typeof a === 'object') {
        try {
          return JSON.stringify(a, null, 2);
        } catch {
          return String(a);
        }
      }
      return String(a);
    }).join(' ');
    outputBuffer.push(`[INFO] ${line}`);
  },
  debug: (...args: any[]) => {
    const line = args.map(a => {
      if (typeof a === 'object') {
        try {
          return JSON.stringify(a, null, 2);
        } catch {
          return String(a);
        }
      }
      return String(a);
    }).join(' ');
    outputBuffer.push(`[DEBUG] ${line}`);
  },
  clear: () => {
    outputBuffer = [];
  },
  table: (data: any) => {
    outputBuffer.push(`[TABLE] ${JSON.stringify(data)}`);
  },
  time: () => {},
  timeEnd: () => {},
  group: () => {},
  groupEnd: () => {},
  trace: () => {},
  assert: (condition: boolean, ...args: any[]) => {
    if (!condition) {
      outputBuffer.push(`[ASSERT] ${args.join(' ')}`);
    }
  },
};

// Create secure context
export function createSecureContext(envVars: Record<string, string> = {}): Record<string, any> {
  return {
    console: secureConsole,
    Math,
    JSON,
    Number,
    Boolean,
    String,
    Array,
    Object,
    Map,
    Set,
    WeakMap,
    WeakSet,
    Symbol,
    BigInt,
    Date,
    RegExp,
    Error,
    TypeError,
    RangeError,
    SyntaxError,
    ReferenceError,
    parseInt,
    parseFloat,
    isNaN,
    isFinite,
    encodeURI,
    decodeURI,
    encodeURIComponent,
    decodeURIComponent,
    setTimeout: (fn: Function, ms: number, ...args: any[]) => {
      if (ms > 30000) ms = 30000;
      return setTimeout(fn, ms, ...args);
    },
    setInterval: (fn: Function, ms: number, ...args: any[]) => {
      if (ms > 30000) ms = 30000;
      return setInterval(fn, ms, ...args);
    },
    clearTimeout,
    clearInterval,
    Promise,
    setImmediate: (fn: Function, ...args: any[]) => {
      return setTimeout(fn, 0, ...args);
    },
    clearImmediate,
    console: secureConsole,
    ...envVars,
    fetch: restrictedFetch,
    performance: {
      now: () => Date.now(),
      timing: {},
      navigation: {},
      memory: {
        jsHeapSizeLimit: 0,
        totalJSHeapSize: 0,
        usedJSHeapSize: 0,
      },
    },
    crypto: {
      getRandomValues: (arr: Uint8Array) => {
        for (let i = 0; i < arr.length; i++) {
          arr[i] = Math.floor(Math.random() * 256);
        }
        return arr;
      },
      subtle: undefined,
    },
    globalThis: {},
    self: {},
    URL,
    URLSearchParams,
    TextEncoder,
    TextDecoder,
    AbortController,
    AbortSignal,
  };
}

async function restrictedFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  throw new Error('fetch is disabled in sandbox. Use a different approach or configure allowed domains.');
}

// Execute code in sandbox
export async function executeInSandbox(
  code: string,
  timeoutMs: number = 30000,
  envVars: Record<string, string> = {}
): Promise<{ result: any; error: string | null; metrics: { cpuTimeMs: number; wallTimeMs: number } }> {
  outputBuffer = [];
  const startTime = Date.now();
  let cpuTime = 0;
  
  const context = createSecureContext(envVars);
  
  const originalLog = context.console.log;
  context.console.log = (...args: any[]) => {
    originalLog.apply(context.console, args);
    flushOutput();
  };
  
  try {
    const wrappedCode = `
      "use strict";
      ${code}
    `;
    
    const executeWithTimeout = new Promise<any>((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('Execution timeout'));
      }, timeoutMs);
      
      try {
        const fn = new Function(wrappedCode);
        const result = fn.call(context);
        
        if (result instanceof Promise) {
          result
            .then(r => {
              clearTimeout(timeout);
              resolve(r);
            })
            .catch(err => {
              clearTimeout(timeout);
              reject(err);
            });
        } else {
          clearTimeout(timeout);
          resolve(result);
        }
      } catch (err) {
        clearTimeout(timeout);
        reject(err);
      }
    });
    
    const result = await executeWithTimeout;
    cpuTime = Date.now() - startTime;
    
    flushOutput();
    
    return {
      result,
      error: null,
      metrics: {
        cpuTimeMs: cpuTime,
        wallTimeMs: Date.now() - startTime,
      },
    };
  } catch (error: any) {
    cpuTime = Date.now() - startTime;
    
    flushCallback?.({
      type: 'error',
      data: error.message || String(error),
      timestamp: Date.now(),
    });
    
    flushOutput();
    
    return {
      result: undefined,
      error: error.message || String(error),
      metrics: {
        cpuTimeMs: cpuTime,
        wallTimeMs: Date.now() - startTime,
      },
    };
  }
}

// Validate code for dangerous patterns
export function validateCode(code: string): { valid: boolean; issues: string[] } {
  const issues: string[] = [];
  
  const dangerousPatterns = [
    { pattern: /while\s*\(\s*true\s*\)/gi, message: 'Infinite while loop detected' },
    { pattern: /for\s*\(\s*;\s*;\s*\)/gi, message: 'Infinite for loop detected' },
    { pattern: /eval\s*\(/gi, message: 'eval() is not allowed' },
    { pattern: /Function\s*\(/gi, message: 'Function constructor is not allowed' },
    { pattern: /import\s+.*\s+from\s+['"]/gi, message: 'ES modules are not supported' },
    { pattern: /require\s*\(/gi, message: 'require() is not allowed' },
    { pattern: /process\./gi, message: 'process global is not allowed' },
    { pattern: /__dirname|__filename/gi, message: 'File system paths are not allowed' },
  ];
  
  for (const { pattern, message } of dangerousPatterns) {
    if (pattern.test(code)) {
      issues.push(message);
    }
  }
  
  return {
    valid: issues.length === 0,
    issues,
  };
}
