/**
 * Mimo Swarm - Integrated Worker
 * Combines Mimo AI with Durable Object Swarm for code execution
 */

import { DurableObjectNamespace } from 'cloudflare:workers';
import { DispatcherDO } from './durableObjects/dispatcher';
import { ExecutorDO } from './durableObjects/executor';
import type { ExecutionRequest, ExecutionResponse } from './types';

// Re-export for the worker
export { DispatcherDO, ExecutorDO };

// Default settings
const DEFAULT_DISPATCHER = 'mimo-swarm-dispatcher';

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    const method = request.method;

    // CORS headers
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    };

    // Handle CORS preflight
    if (method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    // Health check
    if (url.pathname === '/health') {
      return new Response(JSON.stringify({
        status: 'healthy',
        service: 'Mimo Swarm - AI App Builder',
        version: '2.0.0',
        features: ['ai-code-generation', 'code-execution', 'live-preview'],
        timestamp: Date.now(),
      }), {
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }

    // API v1 routes
    if (url.pathname.startsWith('/v1/')) {
      return handleApiV1(request, env, url, corsHeaders);
    }

    // WebSocket for streaming
    if (url.pathname.startsWith('/ws/')) {
      return handleWebSocket(request, env, url, corsHeaders);
    }

    // Root: return service info
    return new Response(JSON.stringify({
      service: 'Mimo Swarm - AI App Builder',
      version: '2.0.0',
      description: 'AI-powered code generation and execution platform',
      endpoints: {
        // AI Endpoints
        'POST /v1/chat': 'Chat with Mimo AI',
        'POST /v1/generate': 'Generate code from prompt',
        'POST /v1/execute': 'Execute code in swarm',
        
        // Swarm Endpoints
        'GET /v1/stats': 'Get swarm statistics',
        'GET /v1/executors': 'List executors',
        'POST /v1/scale': 'Scale the swarm',
        
        // Streaming
        'WS /ws/:executionId': 'Stream execution output',
        
        // Health
        'GET /health': 'Health check',
      },
      templates: [
        'todo', 'counter', 'weather', 'chat', 'calculator', 'dashboard'
      ],
    }), {
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });
  },
};

async function handleApiV1(
  request: Request,
  env: Env,
  url: URL,
  corsHeaders: Record<string, string>
): Promise<Response> {
  const method = request.method;

  // Get dispatcher
  const dispatcher = env.DISPATCHER_DO.get(
    env.DISPATCHER_DO.idFromName(DEFAULT_DISPATCHER)
  );

  // Execute code in swarm
  if (method === 'POST' && url.pathname === '/v1/execute') {
    try {
      const reqData: ExecutionRequest = await request.json();
      
      if (!reqData.code) {
        return new Response(JSON.stringify({
          error: 'Missing code in request',
        }), {
          status: 400,
          headers: { 'Content-Type': 'application/json', ...corsHeaders },
        });
      }

      reqData.language = reqData.language || 'javascript';
      reqData.timeoutMs = reqData.timeoutMs || 30000;
      reqData.executionId = reqData.executionId || `exec-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

      const response = await dispatcher.fetch(new Request('https://placeholder/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reqData),
      }));

      const result = await response.json();
      const wsUrl = `${url.protocol.replace('http', 'ws')}//${url.host}/ws/${reqData.executionId}`;
      
      if (result.executionId) {
        result.websocketUrl = wsUrl;
      }

      return new Response(JSON.stringify(result), {
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });

    } catch (error: any) {
      return new Response(JSON.stringify({
        error: error.message,
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }
  }

  // Generate code from prompt (AI-powered)
  if (method === 'POST' && url.pathname === '/v1/generate') {
    try {
      const { prompt, template } = await request.json();
      
      if (!prompt) {
        return new Response(JSON.stringify({
          error: 'Missing prompt in request',
        }), {
          status: 400,
          headers: { 'Content-Type': 'application/json', ...corsHeaders },
        });
      }

      // Use template if specified, otherwise use AI
      let generatedCode = '';
      let language: 'tsx' | 'jsx' = 'tsx';
      let description = '';

      if (template) {
        // Use predefined template
        const templates: Record<string, string> = {
          todo: getTodoTemplate(),
          counter: getCounterTemplate(),
          weather: getWeatherTemplate(),
          chat: getChatTemplate(),
          calculator: getCalculatorTemplate(),
          dashboard: getDashboardTemplate(),
        };
        
        generatedCode = templates[template] || templates.todo;
        description = `Generated ${template} app from template`;
      } else {
        // Use AI to generate (placeholder - would integrate with Kimi)
        const lowerPrompt = prompt.toLowerCase();
        
        if (lowerPrompt.includes('todo') || lowerPrompt.includes('task')) {
          generatedCode = getTodoTemplate();
          description = 'Generated todo app based on your prompt';
        } else if (lowerPrompt.includes('counter')) {
          generatedCode = getCounterTemplate();
          description = 'Generated counter app based on your prompt';
        } else if (lowerPrompt.includes('weather')) {
          generatedCode = getWeatherTemplate();
          description = 'Generated weather app based on your prompt';
        } else if (lowerPrompt.includes('chat') || lowerPrompt.includes('message')) {
          generatedCode = getChatTemplate();
          description = 'Generated chat app based on your prompt';
        } else if (lowerPrompt.includes('calculator')) {
          generatedCode = getCalculatorTemplate();
          description = 'Generated calculator app based on your prompt';
        } else if (lowerPrompt.includes('dashboard')) {
          generatedCode = getDashboardTemplate();
          description = 'Generated dashboard app based on your prompt';
        } else {
          generatedCode = getDefaultTemplate(prompt);
          description = 'Generated custom app based on your prompt';
        }
      }

      return new Response(JSON.stringify({
        success: true,
        prompt,
        code: generatedCode,
        language,
        description,
        executionId: `gen-${Date.now()}`,
        previewUrl: `/preview?code=${encodeURIComponent(generatedCode)}`,
      }), {
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });

    } catch (error: any) {
      return new Response(JSON.stringify({
        error: error.message,
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }
  }

  // Get swarm stats
  if (method === 'GET' && url.pathname === '/v1/stats') {
    try {
      const response = await dispatcher.fetch(new Request('https://placeholder/stats'));
      const stats = await response.json();

      return new Response(JSON.stringify({
        ...stats,
        service: 'Mimo Swarm',
        timestamp: Date.now(),
      }), {
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    } catch (error: any) {
      return new Response(JSON.stringify({
        error: error.message,
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }
  }

  // List executors
  if (method === 'GET' && url.pathname === '/v1/executors') {
    try {
      const response = await dispatcher.fetch(new Request('https://placeholder/executors'));
      const executors = await response.json();

      return new Response(JSON.stringify(executors), {
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    } catch (error: any) {
      return new Response(JSON.stringify({
        error: error.message,
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }
  }

  // Scale swarm
  if (method === 'POST' && url.pathname === '/v1/scale') {
    try {
      const { minExecutors, maxExecutors } = await request.json();
      
      const response = await dispatcher.fetch(new Request('https://placeholder/scale', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ minExecutors, maxExecutors }),
      }));

      const result = await response.json();
      return new Response(JSON.stringify(result), {
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });

    } catch (error: any) {
      return new Response(JSON.stringify({
        error: error.message,
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }
  }

  return new Response(JSON.stringify({
    error: 'Not found',
  }), {
    status: 404,
    headers: { 'Content-Type': 'application/json', ...corsHeaders },
  });
}

async function handleWebSocket(
  request: Request,
  env: Env,
  url: URL,
  corsHeaders: Record<string, string>
): Promise<Response> {
  const executionId = url.pathname.split('/').pop();

  if (!executionId) {
    return new Response('Missing execution ID', { status: 400 });
  }

  const upgradeHeader = request.headers.get('Upgrade');
  if (upgradeHeader !== 'websocket') {
    return new Response('Expected WebSocket upgrade', { status: 400 });
  }

  const { 0: client, 1: server } = new WebSocketPair();

  const dispatcher = env.DISPATCHER_DO.get(
    env.DISPATCHER_DO.idFromName(DEFAULT_DISPATCHER)
  );

  try {
    server.accept();
    
    server.addEventListener('message', (event) => {
      console.log('Received from client:', event.data);
    });

    server.addEventListener('close', () => {
      console.log('WebSocket closed');
    });

    server.send(JSON.stringify({
      type: 'connected',
      executionId,
      timestamp: Date.now(),
    }));

  } catch (error: any) {
    server.close(1008, error.message);
  }

  return new Response(null, { status: 101, webSocket: client });
}

// ============================================
// TEMPLATES
// ============================================

function getTodoTemplate(): string {
  return `
import React, { useState } from 'react';

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [input, setInput] = useState('');

  const addTask = () => {
    if (!input.trim()) return;
    setTasks([...tasks, { id: Date.now(), text: input, done: false }]);
    setInput('');
  };

  const toggleTask = (id) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, done: !t.done } : t));
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  return (
    <div style={{ 
      minHeight: '100vh', 
      background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)',
      padding: '2rem',
      fontFamily: 'system-ui, sans-serif'
    }}>
      <div style={{ maxWidth: '500px', margin: '0 auto' }}>
        <h1 style={{ color: '#fff', textAlign: 'center', marginBottom: '2rem' }}>
          Todo App
        </h1>
        
        <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '2rem' }}>
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && addTask()}
            placeholder="Add a task..."
            style={{
              flex: 1,
              padding: '0.75rem 1rem',
              borderRadius: '8px',
              border: '1px solid #333',
              background: '#1e1e2e',
              color: '#fff',
              fontSize: '1rem'
            }}
          />
          <button
            onClick={addTask}
            style={{
              padding: '0.75rem 1.5rem',
              background: '#6366f1',
              color: '#fff',
              border: 'none',
              borderRadius: '8px',
              cursor: 'pointer',
              fontWeight: 'bold'
            }}
          >
            Add
          </button>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
          {tasks.length === 0 ? (
            <p style={{ color: '#666', textAlign: 'center' }}>No tasks yet!</p>
          ) : (
            tasks.map(task => (
              <div
                key={task.id}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.75rem',
                  padding: '1rem',
                  background: '#1e1e2e',
                  borderRadius: '8px',
                  border: '1px solid #333'
                }}
              >
                <input
                  type="checkbox"
                  checked={task.done}
                  onChange={() => toggleTask(task.id)}
                  style={{ width: '20px', height: '20px' }}
                />
                <span style={{ 
                  flex: 1, 
                  color: task.done ? '#666' : '#fff',
                  textDecoration: task.done ? 'line-through' : 'none'
                }}>
                  {task.text}
                </span>
                <button
                  onClick={() => deleteTask(task.id)}
                  style={{
                    padding: '0.5rem',
                    background: '#ef4444',
                    color: '#fff',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer'
                  }}
                >
                  ✕
                </button>
              </div>
            ))
          )}
        </div>

        <p style={{ color: '#666', textAlign: 'center', marginTop: '2rem' }}>
          {tasks.filter(t => t.done).length} of {tasks.length} completed
        </p>
      </div>
    </div>
  );
}
`;
}

function getCounterTemplate(): string {
  return `
import React, { useState } from 'react';

export default function App() {
  const [count, setCount] = useState(0);

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      fontFamily: 'system-ui, sans-serif'
    }}>
      <div style={{
        background: 'rgba(255,255,255,0.1)',
        backdropFilter: 'blur(10px)',
        padding: '3rem',
        borderRadius: '20px',
        textAlign: 'center'
      }}>
        <h1 style={{ color: '#fff', fontSize: '4rem', margin: '0 0 2rem 0' }}>
          {count}
        </h1>
        <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center' }}>
          <button
            onClick={() => setCount(c => c - 1)}
            style={{
              padding: '1rem 2rem',
              fontSize: '1.5rem',
              background: '#fff',
              color: '#667eea',
              border: 'none',
              borderRadius: '10px',
              cursor: 'pointer',
              fontWeight: 'bold'
            }}
          >
            -
          </button>
          <button
            onClick={() => setCount(0)}
            style={{
              padding: '1rem 2rem',
              fontSize: '1rem',
              background: 'rgba(255,255,255,0.2)',
              color: '#fff',
              border: '1px solid rgba(255,255,255,0.3)',
              borderRadius: '10px',
              cursor: 'pointer'
            }}
          >
            Reset
          </button>
          <button
            onClick={() => setCount(c => c + 1)}
            style={{
              padding: '1rem 2rem',
              fontSize: '1.5rem',
              background: '#fff',
              color: '#667eea',
              border: 'none',
              borderRadius: '10px',
              cursor: 'pointer',
              fontWeight: 'bold'
            }}
          >
            +
          </button>
        </div>
      </div>
    </div>
  );
}
`;
}

function getWeatherTemplate(): string {
  return `
import React, { useState, useEffect } from 'react';

const WEATHER_DATA = {
  'New York': { temp: 72, condition: 'Sunny', icon: '☀️' },
  'London': { temp: 58, condition: 'Rainy', icon: '🌧️' },
  'Tokyo': { temp: 75, condition: 'Cloudy', icon: '☁️' },
  'Sydney': { temp: 82, condition: 'Sunny', icon: '☀️' },
  'Paris': { temp: 65, condition: 'Partly Cloudy', icon: '⛅' },
};

export default function App() {
  const [city, setCity] = useState('New York');
  const [weather, setWeather] = useState(WEATHER_DATA['New York']);
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    setWeather(WEATHER_DATA[city] || WEATHER_DATA['New York']);
  }, [city]);

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #1e3c72 0%, #2a5298 100%)',
      padding: '2rem',
      fontFamily: 'system-ui, sans-serif'
    }}>
      <div style={{ maxWidth: '400px', margin: '0 auto', textAlign: 'center' }}>
        <h1 style={{ color: '#fff', fontSize: '2.5rem', marginBottom: '0.5rem' }}>
          Weather
        </h1>
        
        <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: '1.2rem', marginBottom: '2rem' }}>
          {time.toLocaleDateString()} • {time.toLocaleTimeString()}
        </p>

        <div style={{
          background: 'rgba(255,255,255,0.15)',
          backdropFilter: 'blur(10px)',
          borderRadius: '20px',
          padding: '2rem',
          marginBottom: '2rem'
        }}>
          <select
            value={city}
            onChange={(e) => setCity(e.target.value)}
            style={{
              padding: '0.75rem',
              borderRadius: '8px',
              border: 'none',
              background: '#fff',
              color: '#333',
              fontSize: '1rem',
              width: '100%',
              marginBottom: '1.5rem',
              cursor: 'pointer'
            }}
          >
            {Object.keys(WEATHER_DATA).map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>

          <div style={{ fontSize: '5rem', marginBottom: '1rem' }}>
            {weather.icon}
          </div>

          <h2 style={{ color: '#fff', fontSize: '4rem', margin: 0 }}>
            {weather.temp}°F
          </h2>

          <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: '1.2rem' }}>
            {weather.condition}
          </p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1rem' }}>
          {[
            { label: 'Humidity', value: '65%' },
            { label: 'Wind', value: '12 mph' },
            { label: 'UV Index', value: '6' },
          ].map(item => (
            <div key={item.label} style={{
              background: 'rgba(255,255,255,0.1)',
              padding: '1rem',
              borderRadius: '10px'
            }}>
              <p style={{ color: 'rgba(255,255,255,0.6)', margin: 0, fontSize: '0.875rem' }}>
                {item.label}
              </p>
              <p style={{ color: '#fff', margin: '0.5rem 0 0 0', fontSize: '1.25rem', fontWeight: 'bold' }}>
                {item.value}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
`;
}

function getChatTemplate(): string {
  return `
import React, { useState, useRef, useEffect } from 'react';

const INITIAL_MESSAGES = [
  { id: 1, role: 'assistant', text: 'Hello! How can I help you today?', time: '10:00' },
  { id: 2, role: 'user', text: 'I need help with my order', time: '10:01' },
  { id: 3, role: 'assistant', text: 'Of course! I can help you with that.', time: '10:01' },
];

export default function App() {
  const [messages, setMessages] = useState(INITIAL_MESSAGES);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);

  const sendMessage = () => {
    if (!input.trim()) return;
    
    const newUserMsg = {
      id: Date.now(),
      role: 'user',
      text: input,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    
    setMessages([...messages, newUserMsg]);
    setInput('');

    setTimeout(() => {
      const botResponse = {
        id: Date.now() + 1,
        role: 'assistant',
        text: 'Thanks for your message! Our team will get back to you shortly.',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, botResponse]);
    }, 1000);
  };

  return (
    <div style={{
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      background: '#0f0f0f',
      fontFamily: 'system-ui, sans-serif'
    }}>
      <div style={{
        padding: '1rem 1.5rem',
        borderBottom: '1px solid #333',
        background: '#1a1a1a'
      }}>
        <h1 style={{ color: '#fff', margin: 0, fontSize: '1.25rem' }}>Chat Support</h1>
        <p style={{ color: '#666', margin: '0.25rem 0 0 0', fontSize: '0.875rem' }}>
          Online • Typically replies instantly
        </p>
      </div>

      <div style={{
        flex: 1,
        overflow: 'auto',
        padding: '1.5rem',
        display: 'flex',
        flexDirection: 'column',
        gap: '1rem'
      }}>
        {messages.map(msg => (
          <div
            key={msg.id}
            style={{
              display: 'flex',
              justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start'
            }}
          >
            <div style={{
              maxWidth: '70%',
              padding: '0.75rem 1rem',
              borderRadius: '12px',
              background: msg.role === 'user' ? '#6366f1' : '#2a2a2a',
              color: '#fff'
            }}>
              <p style={{ margin: 0 }}>{msg.text}</p>
              <p style={{ margin: '0.25rem 0 0 0', fontSize: '0.75rem', opacity: 0.6 }}>
                {msg.time}
              </p>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <div style={{
        padding: '1rem',
        borderTop: '1px solid #333',
        background: '#1a1a1a',
        display: 'flex',
        gap: '0.5rem'
      }}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
          placeholder="Type your message..."
          style={{
            flex: 1,
            padding: '0.75rem 1rem',
            borderRadius: '8px',
            border: '1px solid #333',
            background: '#0f0f0f',
            color: '#fff',
            fontSize: '1rem',
            outline: 'none'
          }}
        />
        <button
          onClick={sendMessage}
          style={{
            padding: '0.75rem 1.5rem',
            background: '#6366f1',
            color: '#fff',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            fontWeight: 'bold'
          }}
        >
          Send
        </button>
      </div>
    </div>
  );
}
`;
}

function getCalculatorTemplate(): string {
  return `
import React, { useState } from 'react';

export default function App() {
  const [display, setDisplay] = useState('0');
  const [firstOperand, setFirstOperand] = useState(null);
  const [operator, setOperator] = useState(null);
  const [waitingForSecondOperand, setWaitingForSecondOperand] = useState(false);

  const buttons = [
    ['C', '±', '%', '÷'],
    ['7', '8', '9', '×'],
    ['4', '5', '6', '-'],
    ['1', '2', '3', '+'],
    ['0', '.', '=']
  ];

  const handleNumber = (num) => {
    if (waitingForSecondOperand) {
      setDisplay(num);
      setWaitingForSecondOperand(false);
    } else {
      setDisplay(display === '0' ? num : display + num);
    }
  };

  const handleOperator = (op) => {
    const inputValue = parseFloat(display);
    
    if (firstOperand === null) {
      setFirstOperand(inputValue);
    } else if (operator) {
      const result = calculate(firstOperand, inputValue, operator);
      setDisplay(String(result));
      setFirstOperand(result);
    }
    
    setWaitingForSecondOperand(true);
    setOperator(op);
  };

  const calculate = (a, b, op) => {
    switch (op) {
      case '+': return a + b;
      case '-': return a - b;
      case '×': return a * b;
      case '÷': return a / b;
      case '%': return a % b;
      default: return b;
    }
  };

  const handleEquals = () => {
    if (firstOperand === null || operator === null) return;
    
    const inputValue = parseFloat(display);
    const result = calculate(firstOperand, inputValue, operator);
    
    setDisplay(String(result));
    setFirstOperand(null);
    setOperator(null);
    setWaitingForSecondOperand(true);
  };

  const handleClear = () => {
    setDisplay('0');
    setFirstOperand(null);
    setOperator(null);
    setWaitingForSecondOperand(false);
  };

  const handleDecimal = () => {
    if (waitingForSecondOperand) {
      setDisplay('0.');
      setWaitingForSecondOperand(false);
    } else if (!display.includes('.')) {
      setDisplay(display + '.');
    }
  };

  const getButtonStyle = (btn) => {
    const isOperator = ['÷', '×', '-', '+', '='].includes(btn);
    const isZero = btn === '0';
    
    return {
      padding: isZero ? '1rem 2rem' : '1rem',
      fontSize: '1.5rem',
      background: isOperator ? '#6366f1' : '#2a2a2a',
      color: '#fff',
      border: 'none',
      borderRadius: '8px',
      cursor: 'pointer',
      gridColumn: isZero ? 'span 2' : 'auto',
    };
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: '#0f0f0f',
      fontFamily: 'system-ui, sans-serif'
    }}>
      <div style={{
        background: '#1a1a1a',
        padding: '1.5rem',
        borderRadius: '20px',
        width: '320px'
      }}>
        <div style={{
          background: '#0f0f0f',
          padding: '1.5rem',
          borderRadius: '12px',
          marginBottom: '1rem',
          textAlign: 'right'
        }}>
          <p style={{
            color: '#666',
            fontSize: '0.875rem',
            margin: 0
          }}>
            {firstOperand} {operator} {waitingForSecondOperand ? '' : display}
          </p>
          <h2 style={{
            color: '#fff',
            fontSize: '2.5rem',
            margin: '0.5rem 0 0 0',
            overflow: 'hidden',
            textOverflow: 'ellipsis'
          }}>
            {display}
          </h2>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(4, 1fr)',
          gap: '0.5rem'
        }}>
          {buttons.flat().map((btn) => (
            <button
              key={btn}
              onClick={() => {
                if (btn === 'C') handleClear();
                else if (btn === '±') setDisplay(String(-parseFloat(display)));
                else if (btn === '%') setDisplay(String(parseFloat(display) / 100));
                else if (btn === '=') handleEquals();
                else if (btn === '.') handleDecimal();
                else if (['÷', '×', '-', '+'].includes(btn)) handleOperator(btn);
                else handleNumber(btn);
              }}
              style={getButtonStyle(btn)}
            >
              {btn}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
`;
}

function getDashboardTemplate(): string {
  return `
import React, { useState } from 'react';

const DATA = [
  { label: 'Revenue', value: '$124,500', change: '+12%', positive: true },
  { label: 'Users', value: '8,234', change: '+8%', positive: true },
  { label: 'Orders', value: '1,456', change: '-3%', positive: false },
  { label: 'Conversion', value: '3.2%', change: '+1%', positive: true },
];

const ACTIVITY = [
  { user: 'John D.', action: 'placed an order', time: '2 min ago', amount: '$299' },
  { user: 'Sarah M.', action: 'signed up', time: '5 min ago', amount: '' },
  { user: 'Mike R.', action: 'left a review', time: '12 min ago', amount: '' },
  { user: 'Emily W.', action: 'upgraded plan', time: '15 min ago', amount: '$99' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div style={{
      minHeight: '100vh',
      background: '#0f0f0f',
      fontFamily: 'system-ui, sans-serif'
    }}>
      <header style={{
        padding: '1rem 2rem',
        borderBottom: '1px solid #222',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <h1 style={{ color: '#fff', margin: 0, fontSize: '1.5rem' }}>Dashboard</h1>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <span style={{ color: '#666', fontSize: '0.875rem' }}>admin@example.com</span>
          <div style={{
            width: '36px',
            height: '36px',
            borderRadius: '50%',
            background: '#6366f1',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#fff',
            fontWeight: 'bold'
          }}>
            A
          </div>
        </div>
      </header>

      <div style={{ display: 'flex' }}>
        <aside style={{
          width: '200px',
          padding: '1.5rem',
          borderRight: '1px solid #222'
        }}>
          {['Overview', 'Analytics', 'Users', 'Settings'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab.toLowerCase())}
              style={{
                display: 'block',
                width: '100%',
                padding: '0.75rem 1rem',
                marginBottom: '0.5rem',
                background: activeTab === tab.toLowerCase() ? '#1a1a1a' : 'transparent',
                color: activeTab === tab.toLowerCase() ? '#fff' : '#666',
                border: 'none',
                borderRadius: '8px',
                cursor: 'pointer',
                textAlign: 'left',
                fontSize: '0.875rem'
              }}
            >
              {tab}
            </button>
          ))}
        </aside>

        <main style={{ flex: 1, padding: '2rem' }}>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(4, 1fr)',
            gap: '1rem',
            marginBottom: '2rem'
          }}>
            {DATA.map(stat => (
              <div key={stat.label} style={{
                background: '#1a1a1a',
                padding: '1.5rem',
                borderRadius: '12px'
              }}>
                <p style={{ color: '#666', margin: '0 0 0.5rem 0', fontSize: '0.875rem' }}>
                  {stat.label}
                </p>
                <p style={{ color: '#fff', margin: '0', fontSize: '1.75rem', fontWeight: 'bold' }}>
                  {stat.value}
                </p>
                <p style={{
                  color: stat.positive ? '#10b981' : '#ef4444',
                  margin: '0.5rem 0 0 0',
                  fontSize: '0.875rem'
                }}>
                  {stat.change} from last month
                </p>
              </div>
            ))}
          </div>

          <div style={{
            background: '#1a1a1a',
            borderRadius: '12px',
            padding: '1.5rem'
          }}>
            <h2 style={{ color: '#fff', margin: '0 0 1.5rem 0' }}>Recent Activity</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              {ACTIVITY.map((item, i) => (
                <div key={i} style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '1rem',
                  paddingBottom: i < ACTIVITY.length - 1 ? '1rem' : 0,
                  borderBottom: i < ACTIVITY.length - 1 ? '1px solid #222' : 'none'
                }}>
                  <div style={{
                    width: '40px',
                    height: '40px',
                    borderRadius: '50%',
                    background: '#2a2a2a',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#fff',
                    fontWeight: 'bold'
                  }}>
                    {item.user.charAt(0)}
                  </div>
                  <div style={{ flex: 1 }}>
                    <p style={{ color: '#fff', margin: 0 }}>
                      <strong>{item.user}</strong> {item.action}
                    </p>
                    <p style={{ color: '#666', margin: '0.25rem 0 0 0', fontSize: '0.75rem' }}>
                      {item.time}
                    </p>
                  </div>
                  {item.amount && (
                    <span style={{ color: '#10b981', fontWeight: 'bold' }}>
                      {item.amount}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
`;
}

function getDefaultTemplate(prompt: string): string {
  return `
import React from 'react';

export default function App() {
  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      fontFamily: 'system-ui, sans-serif',
      padding: '2rem',
      textAlign: 'center'
    }}>
      <div style={{
        background: 'rgba(255,255,255,0.1)',
        backdropFilter: 'blur(10px)',
        padding: '3rem',
        borderRadius: '20px',
        maxWidth: '500px'
      }}>
        <h1 style={{ color: '#fff', fontSize: '2.5rem', marginBottom: '1rem' }}>
          Mimo App
        </h1>
        <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: '1.125rem', marginBottom: '2rem' }}>
          "${prompt}"
        </p>
        <p style={{ color: 'rgba(255,255,255,0.6)', fontSize: '0.875rem' }}>
          Your custom app is being generated...
        </p>
      </div>
    </div>
  );
}
`;
}

// Environment type
export interface Env {
  DISPATCHER_DO: DurableObjectNamespace;
  EXECUTOR_DO: DurableObjectNamespace;
}
