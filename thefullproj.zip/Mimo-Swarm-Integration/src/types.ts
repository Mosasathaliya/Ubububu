/**
 * Durable Execution Swarm - Type Definitions
 * A scalable system using Cloudflare Durable Objects to replace containers
 */

export type ExecutorStatus = 'idle' | 'busy' | 'starting' | 'dead';
export type ExecutionStatus = 'queued' | 'running' | 'completed' | 'failed' | 'timeout';
export type Language = 'javascript' | 'typescript' | 'jsx' | 'tsx';

export interface ExecutionRequest {
  code: string;
  language: Language;
  timeoutMs?: number;
  memoryLimitMB?: number;
  envVars?: Record<string, string>;
  dependencies?: string[];
  executionId?: string;
}

export interface ExecutionResponse {
  executionId: string;
  status: ExecutionStatus;
  websocketUrl?: string;
  result?: any;
  error?: string;
  metrics?: ExecutionMetrics;
}

export interface ExecutionMetrics {
  wallTimeMs: number;
  cpuTimeMs: number;
  memoryUsedMB?: number;
  outputLines: number;
}

export interface ExecutorInfo {
  id: string;
  status: ExecutorStatus;
  lastUsed: number;
  currentExecution?: string;
  warmupTime?: number;
}

export interface PendingTask {
  executionId: string;
  request: ExecutionRequest;
  submittedAt: number;
  priority: number;
}

export interface StreamMessage {
  type: 'stdout' | 'stderr' | 'result' | 'error' | 'metrics' | 'status';
  data: string;
  timestamp: number;
}

export interface WorkerMessage {
  type: 'execute' | 'cancel' | 'health_check';
  executionId: string;
  request?: ExecutionRequest;
}

export interface DispatcherState {
  executorPool: Map<string, ExecutorInfo>;
  queue: PendingTask[];
  metrics: SwarmMetrics;
  config: SwarmConfig;
}

export interface SwarmMetrics {
  totalExecutions: number;
  successfulExecutions: number;
  failedExecutions: number;
  averageExecutionTime: number;
  peakConcurrent: number;
}

export interface SwarmConfig {
  minExecutors: number;
  maxExecutors: number;
  executorTimeoutMs: number;
  queueTimeoutMs: number;
  idleTimeoutMs: number;
  gcIntervalMs: number;
}

export const DEFAULT_CONFIG: SwarmConfig = {
  minExecutors: 2,
  maxExecutors: 50,
  executorTimeoutMs: 30000,
  queueTimeoutMs: 60000,
  idleTimeoutMs: 300000,
  gcIntervalMs: 60000,
};

export const EXECUTOR_STATUS = {
  IDLE: 'idle' as ExecutorStatus,
  BUSY: 'busy' as ExecutorStatus,
  STARTING: 'starting' as ExecutorStatus,
  DEAD: 'dead' as ExecutorStatus,
};

export const EXECUTION_STATUS = {
  QUEUED: 'queued' as ExecutionStatus,
  RUNNING: 'running' as ExecutionStatus,
  COMPLETED: 'completed' as ExecutionStatus,
  FAILED: 'failed' as ExecutionStatus,
  TIMEOUT: 'timeout' as ExecutionStatus,
};
