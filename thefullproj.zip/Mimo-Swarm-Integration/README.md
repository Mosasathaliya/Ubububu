# Mimo Swarm - AI App Builder

**Version 2.0.0** - AI-powered code generation and execution platform

Mimo Swarm combines the power of AI (Kimi/Moonshot AI) with a scalable **Durable Object Swarm** for executing user-generated code. Users can prompt to create apps, and the system generates and executes code in isolated environments.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    Mimo Swarm Gateway                           │
│              (API Routes + WebSocket Streaming)                │
└─────────────────────────┬───────────────────────────────────────┘
                          │
          ┌───────────────┴───────────────┐
          ▼                               ▼
┌─────────────────────┐     ┌─────────────────────┐
│   Kimi AI Service  │     │  Dispatcher DO      │
│  (Code Generation) │     │ (Load Balancer)     │
└─────────────────────┘     └─────────┬───────────┘
                                       │
                    ┌──────────────────┼──────────────────┐
                    ▼                  ▼                  ▼
             ┌──────────┐       ┌──────────┐       ┌──────────┐
             │Executor 1│       │Executor 2│       │Executor N│
             │ (Isolate)│       │ (Isolate)│       │ (Isolate)│
             └──────────┘       └──────────┘       └──────────┘
```

## Features

- **AI-Powered App Generation**: Prompt to create apps using Kimi AI
- **Template Library**: Pre-built templates (Todo, Counter, Weather, Chat, Calculator, Dashboard)
- **Durable Object Swarm**: Scalable code execution replacing containers
- **Real-time Streaming**: WebSocket support for live output
- **Secure Sandbox**: Isolated execution with restricted globals
- **Auto-scaling**: Dynamically spawns executors based on demand

## Quick Start

### 1. Install Dependencies

```bash
cd Mimo-Swarm-Integration
npm install
```

### 2. Deploy to Cloudflare

```bash
wrangler deploy
```

### 3. Use the API

#### Generate an App from Prompt

```bash
curl -X POST https://your-worker.workers.dev/v1/generate \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "build a todo app"
  }'
```

Response:

```json
{
  "success": true,
  "prompt": "build a todo app",
  "code": "import React, { useState } from 'react';\n\nexport default function App() {...}",
  "language": "tsx",
  "description": "Generated todo app based on your prompt",
  "executionId": "gen-123456789",
  "previewUrl": "/preview?code=..."
}
```

#### Use a Template

```bash
curl -X POST https://your-worker.workers.dev/v1/generate \
  -H "Content-Type: application/json" \
  -d '{
    "template": "weather"
  }'
```

#### Execute Code

```bash
curl -X POST https://your-worker.workers.dev/v1/execute \
  -H "Content-Type: application/json" \
  -d '{
    "code": "return 2 + 2;",
    "language": "javascript",
    "timeoutMs": 30000
  }'
```

#### Get Swarm Stats

```bash
curl https://your-worker.workers.dev/v1/stats
```

## Available Templates

| Template | Description | Endpoint |
|----------|-------------|----------|
| `todo` | Task management app | `POST /v1/generate` |
| `counter` | Interactive counter | `POST /v1/generate` |
| `weather` | Weather dashboard | `POST /v1/generate` |
| `chat` | Chat interface | `POST /v1/generate` |
| `calculator` | Calculator app | `POST /v1/generate` |
| `dashboard` | Analytics dashboard | `POST /v1/generate` |

## API Reference

### POST /v1/generate

Generate code from prompt or template.

**Request:**

```json
{
  "prompt": "build a weather app",
  "template": "optional template name"
}
```

**Response:**

```json
{
  "success": true,
  "prompt": "build a weather app",
  "code": "...",
  "language": "tsx",
  "description": "Generated weather app based on your prompt",
  "executionId": "gen-123...",
  "previewUrl": "/preview?code=..."
}
```

### POST /v1/execute

Execute code in the swarm.

**Request:**

```json
{
  "code": "return 2 + 2;",
  "language": "javascript",
  "timeoutMs": 30000,
  "envVars": {
    "KEY": "value"
  }
}
```

**Response:**

```json
{
  "executionId": "exec-123...",
  "status": "completed",
  "result": 4,
  "metrics": {
    "wallTimeMs": 5,
    "cpuTimeMs": 3,
    "outputLines": 0
  }
}
```

### GET /v1/stats

Get swarm statistics.

**Response:**

```json
{
  "metrics": {
    "totalExecutions": 100,
    "successfulExecutions": 95,
    "failedExecutions": 5,
    "averageExecutionTime": 150
  },
  "pool": [
    { "id": "executor-1", "status": "idle", "lastUsed": 1234567890 },
    { "id": "executor-2", "status": "busy", "lastUsed": 1234567890 }
  ],
  "queueLength": 0
}
```

### POST /v1/scale

Scale the swarm.

**Request:**

```json
{
  "minExecutors": 5,
  "maxExecutors": 20
}
```

## Configuration

### Durable Objects

The system uses two types of Durable Objects:

1. **Dispatcher DO**: Load balancer managing the executor pool
2. **Executor DO**: Isolated code execution environments

### Limits

- **Max Executors**: 50 (configurable)
- **Executor Timeout**: 30 seconds (default)
- **Queue Timeout**: 60 seconds

## Security

The sandbox provides:

- No access to `DurableObjectState`, `env`, or `global`
- No `eval()` or `Function()` constructor
- No `require()` or ES modules
- No file system or network access
- Timeout protection against infinite loops

## Integration with Mimo

This system integrates with the original Mimo AI platform to provide:

1. **User Prompts**: Users describe what app they want to build
2. **AI Generation**: Kimi AI generates React/TypeScript code
3. **Code Execution**: The swarm executes and validates the code
4. **Live Preview**: Real-time preview of the generated app

## Example: Building a Todo App

### 1. User Prompt

```
User: "Build me a todo app with add, complete, and delete functionality"
```

### 2. AI Generates Code

The system generates a complete React todo app with:

- Add task functionality
- Mark as complete
- Delete task
- Persistent state (in memory)
- Beautiful UI

### 3. Execute & Preview

The code is executed in the swarm and the user can see the live result.

## Performance

- **Cold Start**: ~200ms
- **Warm Execution**: ~5-50ms
- **Max Concurrent**: Up to 50 parallel executors

## License

MIT
