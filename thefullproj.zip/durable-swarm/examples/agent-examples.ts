/**
 * Example: How Agents Can Use the Durable Execution Swarm
 */

import { SwarmClient } from '../src/client';

// Example 1: Simple Code Execution
async function example1_simpleExecution() {
  const swarm = new SwarmClient({
    baseUrl: 'http://localhost:8787',
  });

  const result = await swarm.execute({
    code: `
      // Simple calculation
      const numbers = [1, 2, 3, 4, 5];
      const sum = numbers.reduce((a, b) => a + b, 0);
      const average = sum / numbers.length;
      
      return {
        numbers,
        sum,
        average: Math.round(average * 100) / 100
      };
    `,
    language: 'javascript',
    timeoutMs: 10000,
  });

  console.log('Result:', result.result);
}

// Example 2: TypeScript Execution
async function example2_typeScript() {
  const swarm = new SwarmClient({
    baseUrl: 'http://localhost:8787',
  });

  const result = await swarm.execute({
    code: `
      interface User {
        name: string;
        age: number;
      }
      
      function greet(user: User): string {
        return \`Hello, \${user.name}! You are \${user.age} years old.\`;
      }
      
      const user: User = { name: 'Agent', age: 25 };
      return greet(user);
    `,
    language: 'typescript',
    timeoutMs: 10000,
  });

  console.log('TypeScript Result:', result.result);
}

// Example 3: Async Code with Streaming
async function example3_streaming() {
  const swarm = new SwarmClient({
    baseUrl: 'http://localhost:8787',
  });

  await swarm.executeWithStream(
    {
      code: `
        // Simulate long-running process
        for (let i = 1; i <= 5; i++) {
          console.log(\`Processing item \${i}...\`);
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
        
        return { status: 'complete', processed: 5 };
      `,
      language: 'javascript',
      timeoutMs: 30000,
    },
    {
      stream: true,
      onOutput: (msg) => {
        console.log(\`[\${msg.type}]\`, msg.data);
      },
    }
  );
}

// Example 4: Parallel Execution (Swarm Pattern)
async function example4_parallelExecution() {
  const swarm = new SwarmClient({
    baseUrl: 'http://localhost:8787',
  });

  // Submit multiple tasks simultaneously
  const tasks = [
    { code: 'return 1 + 1;', name: 'Task 1' },
    { code: 'return 2 + 2;', name: 'Task 2' },
    { code: 'return 3 + 3;', name: 'Task 3' },
    { code: 'return 4 + 4;', name: 'Task 4' },
    { code: 'return 5 + 5;', name: 'Task 5' },
  ];

  console.log('Submitting', tasks.length, 'tasks to swarm...');

  const startTime = Date.now();
  
  // Execute all tasks in parallel
  const results = await Promise.all(
    tasks.map(task =>
      swarm.execute({
        code: task.code,
        language: 'javascript',
        timeoutMs: 10000,
      })
    )
  );

  const totalTime = Date.now() - startTime;

  console.log('All tasks completed in', totalTime, 'ms');
  console.log('Results:', results.map(r => r.result));
  console.log('Average time per task:', Math.round(totalTime / tasks.length), 'ms');
}

// Example 5: With Environment Variables
async function example5_envVars() {
  const swarm = new SwarmClient({
    baseUrl: 'http://localhost:8787',
  });

  const result = await swarm.execute({
    code: `
      // Access environment variables
      const apiKey = process.env.API_KEY || 'not set';
      const debug = process.env.DEBUG === 'true';
      
      return {
        apiKey: apiKey ? '***' : 'not set',
        debug,
        message: 'Environment variables accessed securely'
      };
    `,
    language: 'javascript',
    timeoutMs: 10000,
    envVars: {
      API_KEY: 'secret-key-123',
      DEBUG: 'true',
    },
  });

  console.log('Env Result:', result.result);
}

// Example 6: Error Handling
async function example6_errorHandling() {
  const swarm = new SwarmClient({
    baseUrl: 'http://localhost:8787',
  });

  try {
    // This will fail - trying to use eval
    const result = await swarm.execute({
      code: `eval('1 + 1');`,
      language: 'javascript',
      timeoutMs: 5000,
    });
    console.log('Result:', result);
  } catch (error: any) {
    console.log('Expected error caught:', error.message);
  }

  try {
    // This will timeout - infinite loop
    const result = await swarm.execute({
      code: `while(true) {}`,
      language: 'javascript',
      timeoutMs: 3000,
    });
  } catch (error: any) {
    console.log('Timeout error caught:', error.message);
  }
}

// Example 7: Data Processing Pipeline
async function example7_dataPipeline() {
  const swarm = new SwarmClient({
    baseUrl: 'http://localhost:8787',
  });

  // Simulate a data processing task
  const data = Array.from({ length: 100 }, (_, i) => ({ id: i, value: Math.random() * 100 }));

  const result = await swarm.execute({
    code: `
      const data = process.env.DATA ? JSON.parse(process.env.DATA) : [];
      
      // Filter and transform
      const filtered = data.filter(d => d.value > 50);
      const sorted = filtered.sort((a, b) => b.value - a.value);
      const top10 = sorted.slice(0, 10);
      
      // Calculate stats
      const sum = data.reduce((acc, d) => acc + d.value, 0);
      const avg = sum / data.length;
      
      return {
        totalItems: data.length,
        filteredCount: filtered.length,
        top10,
        average: Math.round(avg * 100) / 100
      };
    `,
    language: 'javascript',
    timeoutMs: 15000,
    envVars: {
      DATA: JSON.stringify(data),
    },
  });

  console.log('Pipeline result:', result.result);
}

// Run all examples
async function runExamples() {
  console.log('=== Durable Execution Swarm Examples ===\\n');

  try {
    // await example1_simpleExecution();
    // await example2_typeScript();
    // await example3_streaming();
    // await example4_parallelExecution();
    // await example5_envVars();
    // await example6_errorHandling();
    // await example7_dataPipeline();
    
    console.log('\\nAll examples completed!');
  } catch (error) {
    console.error('Error running examples:', error);
  }
}

// Export for use in other files
export {
  example1_simpleExecution,
  example2_typeScript,
  example3_streaming,
  example4_parallelExecution,
  example5_envVars,
  example6_errorHandling,
  example7_dataPipeline,
  runExamples,
};
