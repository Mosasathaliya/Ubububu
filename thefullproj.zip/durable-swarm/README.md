# Durable Execution Swarm (DES)

A scalable, serverless backend system utilizing a **swarm of Cloudflare Durable Objects** to execute untrusted JavaScript/TypeScript code in parallel. Designed as a **lightweight replacement for Docker containers** for AI agent code execution.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        Gateway Worker                           │
│                    (Entry Point / API)                         │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                   Dispatcher DO                                 │
│              (Load Balancer & Pool Manager)                    │
│  ┌──────────────┬──────────────┬──────────────┐               │
│  │ Executor 1  │ Executor 2   │ Executor N   │               │
│  │  (Isolate)  │  (Isolate)   │  (Isolate)   │               │
│  └──────────────┴──────────────┴──────────────┘               │
└─────────────────────────────────────────────────────────────────┘
```

## Features

- **Multi-Agent Support**: Multiple agents can submit code simultaneously
- **Parallel Execution**: Pool of DOs executing code concurrently
- **Load Balancing**: Automatic distribution of work across executors
- **Secure Sandbox**: Isolated execution environment with restricted globals
- **Real-time Streaming**: WebSocket support for live output
- **Auto-scaling**: Dynamically spawn new executors based on demand
- **Resource Limits**: Configurable timeout and memory limits
- **TypeScript Support**: Execute both JavaScript and TypeScript

## Quick Start

### 1. Deploy to Cloudflare

```bash
# Install dependencies
npm install

# Deploy to Cloudflare Workers
wrangler deploy
```

### 2. Configure Environment

Add to `wrangler.toml`:

```toml
[[durable_objects.bindings]]
name = "DISPATCHER_DO"
class_name = "DispatcherDO"

[[durable_objects.bindings]]
name = "EXECUTOR_DO"
class_name = "ExecutorDO"
```

### 3. Use the Client SDK

```typescript
import { SwarmClient } from './src/client';

const swarm = new SwarmClient({
  baseUrl: 'https://your-worker.youraccount.workers.dev',
  defaultTimeout: 30000,
});

// Execute JavaScript
const result = await swarm.execute({
  code: `
    console.log('Hello from the swarm!');
    const result = 2 + 2;
    return { result, message: 'Calculation complete' };
  `,
  language: 'javascript',
  timeoutMs: 10000,
});

console.log(result);
// { executionId: 'exec-123...', status: 'completed', result: { result: 4, message: 'Calculation complete' } }
```

### 4. Stream Output

```typescript
await swarm.executeWithStream(
  {
    code: `
      for (let i = 0; i < 5; i++) {
        console.log('Count: ' + i);
      }
      return 'Done!';
    `,
    language: 'javascript',
  },
  {
    stream: true,
    onOutput: (msg) => {
      console.log(`[${msg.type}]`, msg.data);
    },
  }
);
```

## API Reference

### POST /v1/execute

Execute code:

```bash
curl -X POST https://your-worker.workers.dev/v1/execute \
  -H "Content-Type: application/json" \
  -d '{
    "code": "return 2 + 2;",
    "language": "javascript",
    "timeoutMs": 30000
  }'
```

Response:

```json
{
  "executionId": "exec-123456789",
  "status": "completed",
  "result": 4,
  "metrics": {
    "wallTimeMs": 5,
    "cpuTimeMs": 3,
    "outputLines": 0
  }
}
```

### GET /v1/stats

Get swarm statistics:

```bash
curl https://your-worker.workers.dev/v1/stats
```

### GET /v1/executors

List all executors in the pool:

```bash
curl https://your-worker.workers.dev/v1/executors
```

### POST /v1/scale

Manually scale the swarm:

```bash
curl -X POST https://your-worker.workers.dev/v1/scale \
  -H "Content-Type: application/json" \
  -d '{ "minExecutors": 5, "maxExecutors": 20 }'
```

## Configuration

### Dispatcher Configuration

Default configuration in `src/types.ts`:

```typescript
const DEFAULT_CONFIG: SwarmConfig = {
  minExecutors: 2,        // Minimum executors to keep warm
  maxExecutors: 50,       // Maximum executors in pool
  executorTimeoutMs: 30000,  // Max execution time
  queueTimeoutMs: 60000,     // Max time in queue
  idleTimeoutMs: 300000,     // 5 minutes before cleanup
  gcIntervalMs: 60000,       // 1 minute between GC runs
};
```

## Security

The sandbox provides:

- **No access** to `DurableObjectState`, `env`, or `global`
- **No `eval()` or `Function()` constructor**
- **No `require()` or ES modules**
- **No file system or network access** (restricted fetch)
- **Timeout protection** against infinite loops

### Code Validation

The system validates code before execution:

```typescript
const dangerousPatterns = [
  /while\s*\(\s*true\s*\)/gi,  // Infinite loop
  /for\s*\(\s*;\s*;\s*\)/gi,   // Infinite loop
  /eval\s*\(/gi,                // eval()
  /Function\s*\(/gi,            // Function constructor
  // ... more patterns
];
```

## Monitoring

### Health Check

```bash
curl https://your-worker.workers.dev/health
```

### Metrics

The swarm tracks:

- `totalExecutions` - Total tasks executed
- `successfulExecutions` - Successful completions
- `failedExecutions` - Failed executions
- `averageExecutionTime` - Average execution time
- `peakConcurrent` - Peak concurrent executions

## Use Cases

### 1. AI Agent Code Execution

```typescript
const result = await swarm.execute({
  code: `
    // Agent can generate and execute code
    function fibonacci(n) {
      if (n <= 1) return n;
      return fibonacci(n - 1) + fibonacci(n - 2);
    }
    return fibonacci(10);
  `,
  language: 'typescript',
});
```

### 2. Parallel Data Processing

```typescript
// Submit multiple tasks
const tasks = data.map(item => swarm.execute({
  code: `return processItem(${JSON.stringify(item)});`,
}));

// Wait for all to complete
const results = await Promise.all(tasks);
```

### 3. Real-time Streaming

```typescript
await swarm.executeWithStream({
  code: `
    for (let i = 0; i < 10; i++) {
      console.log('Processing step ' + i);
      await new Promise(r => setTimeout(r, 500));
    }
    return 'Complete!';
  `,
}, {
  stream: true,
  onOutput: (msg) => {
    // Live console output
  },
});
```

## Performance

- **Cold Start**: ~200ms (first execution)
- **Warm Execution**: ~5-50ms
- **Max Concurrent**: Up to 50 parallel executors (configurable)
- **Memory**: Isolated per executor

## Limitations

- No native Node.js modules
- No file system access
- No network (unless explicitly enabled)
- Max 30 second timeout (default)
- Max code size: ~1MB

## License

MIT
