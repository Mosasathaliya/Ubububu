/**
 * Secure Sandbox for Code Execution
 * Provides isolation and security for executing untrusted code
 */

import type { ExecutionRequest, StreamMessage } from './types';

// Global console capture
let outputBuffer: string[] = [];
let flushCallback: ((msg: StreamMessage) => void) | null = null;

export function setOutputHandler(callback: (msg: StreamMessage) => void): void {
  flushCallback = callback;
}

function flushOutput(): void {
  if (flushCallback && outputBuffer.length > 0) {
    for (const line of outputBuffer) {
      flushCallback({
        type: 'stdout',
        data: line,
        timestamp: Date.now(),
      });
    }
    outputBuffer = [];
  }
}

// Secure console implementation
const secureConsole = {
  log: (...args: any[]) => {
    const line = args.map(a => {
      if (typeof a === 'object') {
        try {
          return JSON.stringify(a, null, 2);
        } catch {
          return String(a);
        }
      }
      return String(a);
    }).join(' ');
    outputBuffer.push(`[LOG] ${line}`);
  },
  error: (...args: any[]) => {
    const line = args.map(a => {
      if (typeof a === 'object') {
        try {
          return JSON.stringify(a, null, 2);
        } catch {
          return String(a);
        }
      }
      return String(a);
    }).join(' ');
    outputBuffer.push(`[ERROR] ${line}`);
    flushOutput();
  },
  warn: (...args: any[]) => {
    const line = args.map(a => {
      if (typeof a === 'object') {
        try {
          return JSON.stringify(a, null, 2);
        } catch {
          return String(a);
        }
      }
      return String(a);
    }).join(' ');
    outputBuffer.push(`[WARN] ${line}`);
  },
  info: (...args: any[]) => {
    const line = args.map(a => {
      if (typeof a === 'object') {
        try {
          return JSON.stringify(a, null, 2);
        } catch {
          return String(a);
        }
      }
      return String(a);
    }).join(' ');
    outputBuffer.push(`[INFO] ${line}`);
  },
  debug: (...args: any[]) => {
    const line = args.map(a => {
      if (typeof a === 'object') {
        try {
          return JSON.stringify(a, null, 2);
        } catch {
          return String(a);
        }
      }
      return String(a);
    }).join(' ');
    outputBuffer.push(`[DEBUG] ${line}`);
  },
  clear: () => {
    outputBuffer = [];
  },
  table: (data: any) => {
    outputBuffer.push(`[TABLE] ${JSON.stringify(data)}`);
  },
  time: () => {},
  timeEnd: () => {},
  group: () => {},
  groupEnd: () => {},
  trace: () => {},
  assert: (condition: boolean, ...args: any[]) => {
    if (!condition) {
      outputBuffer.push(`[ASSERT] ${args.join(' ')}`);
    }
  },
};

// Dangerous globals to block
const DANGEROUS_GLOBALS = [
  'DurableObjectState',
  'env',
  'global',
  'process',
  'require',
  'module',
  'exports',
  '__dirname',
  '__filename',
  'eval',
  'Function',
  'WebAssembly',
  'Worker',
  'SharedWorker',
  'ServiceWorker',
  'fetch', // Can be re-enabled for specific domains
];

// Create secure context
export function createSecureContext(envVars: Record<string, string> = {}): Record<string, any> {
  return {
    // Console
    console: secureConsole,
    
    // Math & JSON
    Math,
    JSON,
    Number,
    Boolean,
    String,
    Array,
    Object,
    Map,
    Set,
    WeakMap,
    WeakSet,
    Symbol,
    BigInt,
    Date,
    RegExp,
    Error,
    TypeError,
    RangeError,
    SyntaxError,
    ReferenceError,
    
    // Functional
    parseInt,
    parseFloat,
    isNaN,
    isFinite,
    encodeURI,
    decodeURI,
    encodeURIComponent,
    decodeURIComponent,
    
    // Timers (limited)
    setTimeout: (fn: Function, ms: number, ...args: any[]) => {
      if (ms > 30000) ms = 30000; // Cap at 30 seconds
      return setTimeout(fn, ms, ...args);
    },
    setInterval: (fn: Function, ms: number, ...args: any[]) => {
      if (ms > 30000) ms = 30000;
      return setInterval(fn, ms, ...args);
    },
    clearTimeout,
    clearInterval,
    
    // Promise
    Promise,
    
    // Utilities
    setImmediate: (fn: Function, ...args: any[]) => {
      return setTimeout(fn, 0, ...args);
    },
    clearImmediate,
    
    // Console aliases
    console: secureConsole,
    
    // Environment variables (sandboxed)
    ...envVars,
    
    // Safe fetch (restricted)
    fetch: restrictedFetch,
    
    // Buffer for Node.js compatibility
    Buffer: {
      from: (str: string, encoding?: string) => {
        const chars = str.split('').map(c => c.charCodeAt(0));
        return {
          toString: (enc?: string) => {
            if (enc === 'base64') {
              return btoa(str);
            }
            return str;
          },
          length: chars.length,
        };
      },
      alloc: (size: number, fill?: number) => ({
        toString: () => (fill ? String(fill).repeat(size) : ''),
        length: size,
      }),
      isBuffer: () => false,
    },
    
    // Performance
    performance: {
      now: () => Date.now(),
      timing: {},
      navigation: {},
      memory: {
        jsHeapSizeLimit: 0,
        totalJSHeapSize: 0,
        usedJSHeapSize: 0,
      },
    },
    
    // Crypto (limited)
    crypto: {
      getRandomValues: (arr: Uint8Array) => {
        for (let i = 0; i < arr.length; i++) {
          arr[i] = Math.floor(Math.random() * 256);
        }
        return arr;
      },
      subtle: undefined,
    },
    
    // Custom globalThis
    globalThis: {},
    
    // Safe self
    self: {},
    
    // URL utilities
    URL,
    URLSearchParams,
    
    // Text encoding
    TextEncoder,
    TextDecoder,
    
    // Abort controllers
    AbortController,
    AbortSignal,
  };
}

// Restricted fetch implementation
async function restrictedFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  // Block all fetch by default for security
  // Can be configured to allow specific domains
  throw new Error('fetch is disabled in sandbox. Use a different approach or configure allowed domains.');
}

// Execute code in sandbox
export async function executeInSandbox(
  code: string,
  timeoutMs: number = 30000,
  envVars: Record<string, string> = {}
): Promise<{ result: any; error: string | null; metrics: { cpuTimeMs: number; wallTimeMs: number } }> {
  outputBuffer = [];
  const startTime = Date.now();
  let cpuTime = 0;
  
  // Create secure context
  const context = createSecureContext(envVars);
  
  // Wrap console.log to flush immediately for streaming
  const originalLog = context.console.log;
  context.console.log = (...args: any[]) => {
    originalLog.apply(context.console, args);
    flushOutput();
  };
  
  try {
    // Create function from code
    const wrappedCode = `
      "use strict";
      ${code}
    `;
    
    // Execute with timeout
    const executeWithTimeout = new Promise<any>((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('Execution timeout'));
      }, timeoutMs);
      
      try {
        // Create function and execute
        const fn = new Function(wrappedCode);
        const result = fn.call(context);
        
        // Handle async code
        if (result instanceof Promise) {
          result
            .then(r => {
              clearTimeout(timeout);
              resolve(r);
            })
            .catch(err => {
              clearTimeout(timeout);
              reject(err);
            });
        } else {
          clearTimeout(timeout);
          resolve(result);
        }
      } catch (err) {
        clearTimeout(timeout);
        reject(err);
      }
    });
    
    const result = await executeWithTimeout;
    cpuTime = Date.now() - startTime;
    
    // Flush remaining output
    flushOutput();
    
    return {
      result,
      error: null,
      metrics: {
        cpuTimeMs: cpuTime,
        wallTimeMs: Date.now() - startTime,
      },
    };
  } catch (error: any) {
    cpuTime = Date.now() - startTime;
    
    // Send error to output
    flushCallback?.({
      type: 'error',
      data: error.message || String(error),
      timestamp: Date.now(),
    });
    
    flushOutput();
    
    return {
      result: undefined,
      error: error.message || String(error),
      metrics: {
        cpuTimeMs: cpuTime,
        wallTimeMs: Date.now() - startTime,
      },
    };
  }
}

// Validate code for dangerous patterns
export function validateCode(code: string): { valid: boolean; issues: string[] } {
  const issues: string[] = [];
  
  // Check for dangerous patterns
  const dangerousPatterns = [
    { pattern: /while\s*\(\s*true\s*\)/gi, message: 'Infinite while loop detected' },
    { pattern: /for\s*\(\s*;\s*;\s*\)/gi, message: 'Infinite for loop detected' },
    { pattern: /eval\s*\(/gi, message: 'eval() is not allowed' },
    { pattern: /Function\s*\(/gi, message: 'Function constructor is not allowed' },
    { pattern: /import\s+.*\s+from\s+['"]/gi, message: 'ES modules are not supported' },
    { pattern: /require\s*\(/gi, message: 'require() is not allowed' },
    { pattern: /process\./gi, message: 'process global is not allowed' },
    { pattern: /__dirname|__filename/gi, message: 'File system paths are not allowed' },
  ];
  
  for (const { pattern, message } of dangerousPatterns) {
    if (pattern.test(code)) {
      issues.push(message);
    }
  }
  
  return {
    valid: issues.length === 0,
    issues,
  };
}
