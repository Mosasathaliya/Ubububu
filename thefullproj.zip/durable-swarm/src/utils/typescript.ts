/**
 * TypeScript Transpiler
 * Lightweight TypeScript to JavaScript transpilation
 * Uses a simple transpiler for common TypeScript features
 */

import type { Language } from '../types';

// Simple TypeScript transpiler for common patterns
export function transpileTypeScript(code: string): string {
  // If not TypeScript, return as-is
  if (!code.includes(': ') && !code.includes('interface ') && 
      !code.includes('type ') && !code.includes('<')) {
    return code;
  }

  let result = code;

  // Remove type annotations
  result = result.replace(/:\s*(string|number|boolean|any|void|null|undefined|never|unknown|object|bigint|symbol)\s*([=,);\]>])/g, '$2');
  result = result.replace(/:\s*(string|number|boolean|any|void|null|undefined|never|unknown|object|bigint|symbol)\s*$/gm, '');
  
  // Remove return types
  result = result.replace(/:\s*(string|number|boolean|any|void|null|undefined|never|unknown|object)\s*\{/g, ' {');
  result = result.replace(/=>\s*:\s*(string|number|boolean|any|void|null|undefined)\s*{/g, '=> {');
  result = result.replace(/=>\s*:\s*(string|number|boolean|any|void|null|undefined)\s*;/g, '=>');
  
  // Remove generic type parameters from functions
  result = result.replace(/<[A-Za-z_,\s]*>/g, '');
  
  // Remove interface declarations
  result = result.replace(/interface\s+\w+\s*\{[\s\S]*?\n\}/g, '');
  
  // Remove type declarations
  result = result.replace(/type\s+\w+\s*=\s*[\s\S]*?;/g, '');
  
  // Remove 'as' type assertions
  result = result.replace(/\s+as\s+\w+/g, '');
  
  // Remove '<T>' generic calls (simple patterns)
  result = result.replace(/<[A-Za-z_]*(?:\s*,\s*[A-Za-z_]*)*>/g, '');
  
  // Remove access modifiers
  result = result.replace(/\b(public|private|protected|readonly)\s+/g, '');
  
  // Remove enum declarations (convert to object)
  result = result.replace(/enum\s+(\w+)\s*\{([^}]*)\}/g, (match, name, body) => {
    const values = body.split(',')
      .map((line: string) => line.trim())
      .filter((line: string) => line && !line.includes('//'))
      .map((line: string, i: number) => {
        const [key, value] = line.split('=').map((s: string) => s.trim());
        const actualKey = key || `value${i}`;
        const actualValue = value || String(i);
        return `${actualKey}: ${actualValue}`;
      })
      .join(', ');
    return `const ${name} = { ${values} };`;
  });
  
  // Handle optional parameters
  result = result.replace(/\?\s*:/g, ':');
  
  // Remove readonly
  result = result.replace(/\breadonly\s+/g, '');

  return result;
}

// Check if code needs transpilation
export function needsTranspilation(code: string, language: Language): boolean {
  return language === 'typescript' || language === 'tsx';
}

// Execute TypeScript code
export async function executeTypeScript(
  code: string,
  timeoutMs: number,
  envVars: Record<string, string> = {}
): Promise<{ result: any; error: string | null; metrics: { cpuTimeMs: number; wallTimeMs: number } }> {
  // Import the sandbox dynamically to avoid circular deps
  const { executeInSandbox } = await import('./sandbox.js');
  
  // Transpile TypeScript to JavaScript
  const jsCode = transpileTypeScript(code);
  
  // Execute the transpiled code
  return executeInSandbox(jsCode, timeoutMs, envVars);
}

// Validate and prepare code for execution
export function prepareCode(code: string, language: Language): string {
  if (needsTranspilation(code, language)) {
    return transpileTypeScript(code);
  }
  return code;
}
