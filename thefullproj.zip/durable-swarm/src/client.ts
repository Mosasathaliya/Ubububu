/**
 * Agent SDK for Durable Execution Swarm
 * Easy-to-use client for submitting code execution tasks
 */

import type { ExecutionRequest, ExecutionResponse, StreamMessage } from './types';

export type { 
  ExecutionRequest, 
  ExecutionResponse, 
  StreamMessage,
  Language,
  ExecutionStatus,
  ExecutionMetrics,
} from './types';

export interface SwarmClientConfig {
  baseUrl: string;
  apiKey?: string;
  defaultTimeout?: number;
}

export interface ExecutionOptions extends Partial<ExecutionRequest> {
  stream?: boolean;
  onOutput?: (message: StreamMessage) => void;
}

export class SwarmClient {
  private baseUrl: string;
  private apiKey?: string;
  private defaultTimeout: number;

  constructor(config: SwarmClientConfig) {
    this.baseUrl = config.baseUrl.replace(/\/$/, '');
    this.apiKey = config.apiKey;
    this.defaultTimeout = config.defaultTimeout || 30000;
  }

  private getHeaders(): HeadersInit {
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
    };
    
    if (this.apiKey) {
      headers['Authorization'] = `Bearer ${this.apiKey}`;
    }
    
    return headers;
  }

  /**
   * Execute code synchronously (waits for result)
   */
  async execute(request: ExecutionRequest): Promise<ExecutionResponse> {
    const response = await fetch(`${this.baseUrl}/v1/execute`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({
        ...request,
        timeoutMs: request.timeoutMs || this.defaultTimeout,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Execution failed');
    }

    return await response.json();
  }

  /**
   * Execute code with streaming output
   */
  async executeWithStream(
    request: ExecutionRequest,
    options: ExecutionOptions = {}
  ): Promise<ExecutionResponse> {
    // First submit the execution
    const response = await this.execute({
      ...request,
      timeoutMs: request.timeoutMs || this.defaultTimeout,
    });

    // If streaming enabled and we have a WebSocket URL
    if (options.stream && response.websocketUrl) {
      await this.streamOutput(response.executionId, options.onOutput);
    }

    return response;
  }

  /**
   * Stream execution output via WebSocket
   */
  async streamOutput(
    executionId: string,
    onOutput?: (message: StreamMessage) => void
  ): Promise<void> {
    const wsUrl = `${this.baseUrl.replace('http', 'ws')}/ws/${executionId}`;
    const ws = new WebSocket(wsUrl);

    return new Promise((resolve, reject) => {
      ws.onopen = () => {
        console.log('WebSocket connected');
      };

      ws.onmessage = (event) => {
        try {
          const message: StreamMessage = JSON.parse(event.data);
          onOutput?.(message);
        } catch (e) {
          console.error('Failed to parse message:', e);
        }
      };

      ws.onerror = (error) => {
        reject(error);
      };

      ws.onclose = () => {
        resolve();
      };

      // Timeout for streaming
      setTimeout(() => {
        ws.close();
        resolve();
      }, this.defaultTimeout + 5000);
    });
  }

  /**
   * Get execution status
   */
  async getStatus(executionId: string): Promise<any> {
    const response = await fetch(`${this.baseUrl}/v1/status/${executionId}`, {
      headers: this.getHeaders(),
    });

    if (!response.ok) {
      throw new Error('Failed to get status');
    }

    return await response.json();
  }

  /**
   * Get swarm statistics
   */
  async getStats(): Promise<any> {
    const response = await fetch(`${this.baseUrl}/v1/stats`, {
      headers: this.getHeaders(),
    });

    if (!response.ok) {
      throw new Error('Failed to get stats');
    }

    return await response.json();
  }

  /**
   * List all executors
   */
  async listExecutors(): Promise<any> {
    const response = await fetch(`${this.baseUrl}/v1/executors`, {
      headers: this.getHeaders(),
    });

    if (!response.ok) {
      throw new Error('Failed to list executors');
    }

    return await response.json();
  }

  /**
   * Scale the swarm
   */
  async scale(minExecutors: number, maxExecutors: number): Promise<any> {
    const response = await fetch(`${this.baseUrl}/v1/scale`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ minExecutors, maxExecutors }),
    });

    if (!response.ok) {
      throw new Error('Failed to scale swarm');
    }

    return await response.json();
  }

  /**
   * Clear the execution queue
   */
  async clearQueue(): Promise<{ cleared: number }> {
    const response = await fetch(`${this.baseUrl}/v1/clear`, {
      method: 'POST',
      headers: this.getHeaders(),
    });

    if (!response.ok) {
      throw new Error('Failed to clear queue');
    }

    return await response.json();
  }
}

/**
 * Quick execute helper for simple scripts
 */
export async function quickExecute(
  code: string,
  language: 'javascript' | 'typescript' = 'javascript',
  baseUrl: string = 'http://localhost:8787'
): Promise<ExecutionResponse> {
  const client = new SwarmClient({ baseUrl });
  return await client.execute({
    code,
    language,
    timeoutMs: 30000,
  });
}

// Export all types and utilities
export * from './types';
