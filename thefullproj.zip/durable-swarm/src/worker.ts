/**
 * Durable Execution Swarm - Main Worker
 * Gateway and entry point for the code execution swarm
 */

import { DurableObjectNamespace } from 'cloudflare:workers';
import { DispatcherDO } from './durableObjects/dispatcher';
import { ExecutorDO } from './durableObjects/executor';
import type { ExecutionRequest, ExecutionResponse } from './types';

export { DispatcherDO, ExecutorDO };

// Default pool for development
const DEFAULT_DISPATCHER = 'default-dispatcher';

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    const method = request.method;

    // CORS headers
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    };

    // Handle CORS preflight
    if (method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    // Health check
    if (url.pathname === '/health') {
      return new Response(JSON.stringify({
        status: 'healthy',
        service: 'Durable Execution Swarm',
        version: '1.0.0',
        timestamp: Date.now(),
      }), {
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }

    // API v1 routes
    if (url.pathname.startsWith('/v1/')) {
      return handleApiV1(request, env, url, corsHeaders);
    }

    // WebSocket for streaming
    if (url.pathname.startsWith('/ws/')) {
      return handleWebSocket(request, env, url, corsHeaders);
    }

    // Default: return service info
    return new Response(JSON.stringify({
      service: 'Durable Execution Swarm',
      version: '1.0.0',
      endpoints: {
        'POST /v1/execute': 'Execute code',
        'GET /v1/status/:id': 'Get execution status',
        'GET /v1/stats': 'Get swarm stats',
        'GET /v1/executors': 'List executors',
        'WS /ws/:executionId': 'Stream execution output',
        'GET /health': 'Health check',
      },
    }), {
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });
  },
};

async function handleApiV1(
  request: Request,
  env: Env,
  url: URL,
  corsHeaders: Record<string, string>
): Promise<Response> {
  const method = request.method;

  // Get dispatcher
  const dispatcher = env.DISPATCHER_DO.get(
    env.DISPATCHER_DO.idFromName(DEFAULT_DISPATCHER)
  );

  // Execute code
  if (method === 'POST' && url.pathname === '/v1/execute') {
    try {
      const reqData: ExecutionRequest = await request.json();
      
      // Validate request
      if (!reqData.code) {
        return new Response(JSON.stringify({
          error: 'Missing code in request',
        }), {
          status: 400,
          headers: { 'Content-Type': 'application/json', ...corsHeaders },
        });
      }

      // Set defaults
      reqData.language = reqData.language || 'javascript';
      reqData.timeoutMs = reqData.timeoutMs || 30000;
      reqData.executionId = reqData.executionId || `exec-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

      // Send to dispatcher
      const response = await dispatcher.fetch(new Request('https://placeholder/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reqData),
      }));

      const result = await response.json();

      // Add WebSocket URL for streaming
      const wsUrl = `${url.protocol.replace('http', 'ws')}//${url.host}/ws/${reqData.executionId}`;
      if (result.executionId) {
        result.websocketUrl = wsUrl;
      }

      return new Response(JSON.stringify(result), {
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });

    } catch (error: any) {
      return new Response(JSON.stringify({
        error: error.message,
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }
  }

  // Get execution status
  if (method === 'GET' && url.pathname.startsWith('/v1/status/')) {
    const executionId = url.pathname.split('/').pop();
    
    // For now, return basic info
    // In production, you'd query the executor or store results
    return new Response(JSON.stringify({
      executionId,
      status: 'unknown',
      message: 'Status tracking not yet implemented - results returned immediately on completion',
    }), {
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });
  }

  // Get swarm stats
  if (method === 'GET' && url.pathname === '/v1/stats') {
    const response = await dispatcher.fetch(new Request('https://placeholder/stats'));
    const stats = await response.json();

    return new Response(JSON.stringify(stats), {
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });
  }

  // List executors
  if (method === 'GET' && url.pathname === '/v1/executors') {
    const response = await dispatcher.fetch(new Request('https://placeholder/executors'));
    const executors = await response.json();

    return new Response(JSON.stringify(executors), {
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });
  }

  // Scale swarm
  if (method === 'POST' && url.pathname === '/v1/scale') {
    try {
      const { minExecutors, maxExecutors } = await request.json();
      
      const response = await dispatcher.fetch(new Request('https://placeholder/scale', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ minExecutors, maxExecutors }),
      }));

      const result = await response.json();
      return new Response(JSON.stringify(result), {
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });

    } catch (error: any) {
      return new Response(JSON.stringify({
        error: error.message,
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }
  }

  // Clear queue
  if (method === 'POST' && url.pathname === '/v1/clear') {
    const response = await dispatcher.fetch(new Request('https://placeholder/clear', {
      method: 'POST',
    }));

    const result = await response.json();
    return new Response(JSON.stringify(result), {
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });
  }

  return new Response(JSON.stringify({
    error: 'Not found',
  }), {
    status: 404,
    headers: { 'Content-Type': 'application/json', ...corsHeaders },
  });
}

async function handleWebSocket(
  request: Request,
  env: Env,
  url: URL,
  corsHeaders: Record<string, string>
): Promise<Response> {
  const executionId = url.pathname.split('/').pop();

  if (!executionId) {
    return new Response('Missing execution ID', { status: 400 });
  }

  // Check for WebSocket upgrade
  const upgradeHeader = request.headers.get('Upgrade');
  if (upgradeHeader !== 'websocket') {
    return new Response('Expected WebSocket upgrade', { status: 400 });
  }

  // Create WebSocket pair
  const { 0: client, 1: server } = new WebSocketPair();

  // Connect to dispatcher for streaming
  const dispatcher = env.DISPATCHER_DO.get(
    env.DISPATCHER_DO.idFromName(DEFAULT_DISPATCHER)
  );

  try {
    // This is a simplified version - in production you'd route to the specific executor
    // For now, we'll just acknowledge the connection
    server.accept();
    
    server.addEventListener('message', (event) => {
      console.log('Received from client:', event.data);
    });

    server.addEventListener('close', () => {
      console.log('WebSocket closed');
    });

    // Send connection confirmation
    server.send(JSON.stringify({
      type: 'connected',
      executionId,
      timestamp: Date.now(),
    }));

  } catch (error: any) {
    server.close(1008, error.message);
  }

  return new Response(null, { status: 101, webSocket: client });
}

// TypeScript declarations for environment
export interface Env {
  DISPATCHER_DO: DurableObjectNamespace;
  EXECUTOR_DO: DurableObjectNamespace;
}
