/**
 * Executor Durable Object
 * Isolated code execution environment - the worker unit in the swarm
 */

import { DurableObject } from 'cloudflare:workers';
import type { 
  ExecutorStatus, 
  ExecutionRequest, 
  ExecutionResponse,
  ExecutionMetrics,
  StreamMessage,
  WorkerMessage 
} from '../types';
import { executeInSandbox, validateCode } from '../utils/sandbox';

export class ExecutorDO implements DurableObject {
  private status: ExecutorStatus = 'idle';
  private currentExecutionId: string | null = null;
  private outputHandlers: Map<string, (msg: StreamMessage) => void> = new Map();
  private startTime: number = 0;
  private metrics: ExecutionMetrics = {
    wallTimeMs: 0,
    cpuTimeMs: 0,
    memoryUsedMB: 0,
    outputLines: 0,
  };

  constructor(
    private readonly ctx: DurableObjectState,
    private readonly env: Env
  ) {
    // Initialize state from storage
    this.ctx.blockConcurrencyWhile(async () => {
      const stored = await this.ctx.storage.get<{
        status: ExecutorStatus;
        executionCount: number;
        totalTime: number;
      }>('executor-meta');
      
      if (stored) {
        this.status = stored.status || 'idle';
      }
    });
  }

  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);
    const method = request.method;

    // Health check endpoint
    if (url.pathname === '/health') {
      return new Response(JSON.stringify({
        status: this.status,
        currentExecutionId: this.currentExecutionId,
        uptime: this.startTime > 0 ? Date.now() - this.startTime : 0,
      }), {
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // WebSocket upgrade for streaming
    if (url.pathname === '/stream' && request.headers.get('Upgrade') === 'websocket') {
      const executionId = url.searchParams.get('executionId');
      if (!executionId) {
        return new Response('Missing executionId', { status: 400 });
      }

      const { 0: client, 1: server } = new WebSocketPair();
      
      server.addEventListener('message', (event) => {
        // Forward messages from agent to executor
        try {
          const data = JSON.parse(event.data as string);
          this.outputHandlers.get(executionId)?.({
            type: 'status',
            data: JSON.stringify(data),
            timestamp: Date.now(),
          });
        } catch (e) {
          console.error('Failed to parse WebSocket message:', e);
        }
      });

      server.addEventListener('close', () => {
        this.outputHandlers.delete(executionId);
      });

      // Store handler
      this.outputHandlers.set(executionId, (msg: StreamMessage) => {
        server.send(JSON.stringify(msg));
      });

      return new Response(null, { status: 101, webSocket: client });
    }

    // Execute endpoint
    if (method === 'POST' && url.pathname === '/execute') {
      try {
        const requestData: ExecutionRequest = await request.json();
        return await this.handleExecute(requestData);
      } catch (error: any) {
        return new Response(JSON.stringify({
          error: error.message,
        }), {
          status: 500,
          headers: { 'Content-Type': 'application/json' },
        });
      }
    }

    // Cancel endpoint
    if (method === 'POST' && url.pathname === '/cancel') {
      const { executionId } = await request.json();
      return await this.handleCancel(executionId);
    }

    return new Response('Not Found', { status: 404 });
  }

  private async handleExecute(request: ExecutionRequest): Promise<Response> {
    const executionId = request.executionId || `exec-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    // Update status
    this.status = 'busy';
    this.currentExecutionId = executionId;
    this.startTime = Date.now();
    this.metrics = {
      wallTimeMs: 0,
      cpuTimeMs: 0,
      memoryUsedMB: 0,
      outputLines: 0,
    };

    // Save state
    await this.ctx.storage.put('executor-meta', {
      status: 'busy',
      executionCount: ((await this.ctx.storage.get<any>('executor-meta'))?.executionCount || 0) + 1,
      totalTime: 0,
    });

    // Set up output handler for this execution
    const handler = this.outputHandlers.get(executionId);
    if (handler) {
      handler({
        type: 'status',
        data: 'running',
        timestamp: Date.now(),
      });
    }

    try {
      // Validate code first
      const validation = validateCode(request.code);
      if (!validation.valid) {
        throw new Error(`Code validation failed: ${validation.issues.join(', ')}`);
      }

      // Execute with timeout
      const timeoutMs = request.timeoutMs || 30000;
      const result = await executeInSandbox(
        request.code,
        timeoutMs,
        request.envVars || {}
      );

      this.metrics.wallTimeMs = result.metrics.wallTimeMs;
      this.metrics.cpuTimeMs = result.metrics.cpuTimeMs;

      // Send result
      const response: ExecutionResponse = {
        executionId,
        status: result.error ? 'failed' : 'completed',
        result: result.result,
        error: result.error || undefined,
        metrics: this.metrics,
      };

      if (handler) {
        handler({
          type: 'result',
          data: JSON.stringify(response),
          timestamp: Date.now(),
        });
        
        handler({
          type: 'metrics',
          data: JSON.stringify(this.metrics),
          timestamp: Date.now(),
        });
      }

      return new Response(JSON.stringify(response), {
        headers: { 'Content-Type': 'application/json' },
      });

    } catch (error: any) {
      const errorResponse: ExecutionResponse = {
        executionId,
        status: 'failed',
        error: error.message,
        metrics: this.metrics,
      };

      const handler = this.outputHandlers.get(executionId);
      if (handler) {
        handler({
          type: 'error',
          data: error.message,
          timestamp: Date.now(),
        });
      }

      return new Response(JSON.stringify(errorResponse), {
        status: 500,
        headers: { 'Content-Type': 'application/json' },
      });

    } finally {
      // Reset state
      this.status = 'idle';
      this.currentExecutionId = null;
      
      await this.ctx.storage.put('executor-meta', {
        status: 'idle',
        executionCount: ((await this.ctx.storage.get<any>('executor-meta'))?.executionCount || 0),
        totalTime: ((await this.ctx.storage.get<any>('executor-meta'))?.totalTime || 0) + this.metrics.wallTimeMs,
      });
    }
  }

  private async handleCancel(executionId: string): Promise<Response> {
    if (this.currentExecutionId !== executionId) {
      return new Response(JSON.stringify({
        error: 'Execution not found or already completed',
      }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // Mark as cancelled (actual cancellation is handled by timeout in sandbox)
    const handler = this.outputHandlers.get(executionId);
    if (handler) {
      handler({
        type: 'error',
        data: 'Execution cancelled by user',
        timestamp: Date.now(),
      });
    }

    return new Response(JSON.stringify({
      success: true,
      message: 'Cancellation requested',
    }), {
      headers: { 'Content-Type': 'application/json' },
    });
  }

  // Alarm for cleanup
  async alarm(): Promise<void> {
    // Check if idle for too long
    if (this.status === 'idle' && this.currentExecutionId === null) {
      const lastUsed = await this.ctx.storage.get<number>('last-used');
      const idleTimeout = 5 * 60 * 1000; // 5 minutes
      
      if (lastUsed && Date.now() - lastUsed > idleTimeout) {
        // Self-destruct if idle for too long
        await this.ctx.storage.deleteAll();
      }
    }
  }
}

// TypeScript declaration for the environment
export interface Env {
  // Add environment variables as needed
  EXECUTOR_SECRET?: string;
}
