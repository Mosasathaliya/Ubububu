console.log("Keys in process.env:");
Object.keys(process.env).forEach(key => {
  if (key.includes("API") || key.includes("KEY") || key.includes("GEMINI") || key.includes("MOONSHOT") || key.includes("CLOUDFLARE")) {
    console.log(`${key}: ${process.env[key] ? "PRESENT (length " + process.env[key].length + ")" : "MISSING"}`);
  }
});
