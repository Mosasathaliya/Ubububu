import "dotenv/config";
console.log("GEMINI:", process.env.GEMINI_API_KEY ? "YES" : "NO");
