/*
 * Mimo - Enhanced Backend with Cloudflare D1 Schema & Durable Objects Ready
 * Features: D1 Schema, Rate Limiting, Usage Tracking, Caching, Session Management
 */

import express from "express";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import Database from "better-sqlite3";
import OpenAI from "openai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '50mb' }));

// ============================================
// ENHANCED DATABASE WITH D1 SCHEMA PATTERNS
// ============================================

const db = new Database("mimo_enhanced.db");

// D1-compatible schema (will work with D1 when deployed)
db.exec(`
  -- Projects table
  CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    user_id TEXT DEFAULT 'default',
    name TEXT NOT NULL,
    color TEXT DEFAULT '#8b5cf6',
    status TEXT DEFAULT 'active',
    settings TEXT DEFAULT '{}',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  
  -- Messages with usage tracking
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    image TEXT,
    model_used TEXT,
    tokens_used INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  
  -- API Usage tracking
  CREATE TABLE IF NOT EXISTS api_usage (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT DEFAULT 'default',
    model TEXT NOT NULL,
    tokens_input INTEGER DEFAULT 0,
    tokens_output INTEGER DEFAULT 0,
    latency_ms INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  
  -- Rate limiting
  CREATE TABLE IF NOT EXISTS rate_limits (
    key TEXT PRIMARY KEY,
    count INTEGER DEFAULT 0,
    reset_at DATETIME NOT NULL
  );
  
  -- AI Sessions for context management
  CREATE TABLE IF NOT EXISTS ai_sessions (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL,
    model TEXT NOT NULL,
    context_tokens INTEGER DEFAULT 0,
    message_count INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_active DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  
  -- KV Cache
  CREATE TABLE IF NOT EXISTS kv_cache (
    key TEXT PRIMARY KEY,
    value TEXT,
    expires_at DATETIME
  );
`);

// Add columns if they don't exist (migration)
try { db.exec("ALTER TABLE messages ADD COLUMN model_used TEXT"); } catch(e) {}
try { db.exec("ALTER TABLE messages ADD COLUMN tokens_used INTEGER DEFAULT 0"); } catch(e) {}
try { db.exec("ALTER TABLE projects ADD COLUMN user_id TEXT DEFAULT 'default'"); } catch(e) {}
try { db.exec("ALTER TABLE projects ADD COLUMN updated_at DATETIME"); } catch(e) {}

// ============================================
// POWERFUL DATABASE HELPERS (D1 PATTERN)
// ============================================

const dbHelpers = {
  // Rate limiting with sliding window
  checkRateLimit: (key: string, limit = 60, windowSeconds = 60) => {
    const now = new Date();
    const resetAt = new Date(now.getTime() + windowSeconds * 1000);
    
    const existing = db.prepare("SELECT * FROM rate_limits WHERE key = ? AND reset_at > ?")
      .get(key, now.toISOString()) as any;
    
    if (existing && existing.count >= limit) {
      return { allowed: false, remaining: 0, resetAt: existing.reset_at };
    }
    
    if (existing) {
      db.prepare("UPDATE rate_limits SET count = count + 1 WHERE key = ?").run(key);
    } else {
      db.prepare("INSERT INTO rate_limits (key, count, reset_at) VALUES (?, 1, ?)")
        .run(key, resetAt.toISOString());
    }
    
    return { 
      allowed: true, 
      remaining: limit - (existing?.count || 0) - 1,
      resetAt: resetAt.toISOString()
    };
  },
  
  // Track API usage
  trackUsage: (userId: string, model: string, inputTokens: number, outputTokens: number, latencyMs: number) => {
    db.prepare(`
      INSERT INTO api_usage (user_id, model, tokens_input, tokens_output, latency_ms)
      VALUES (?, ?, ?, ?, ?)
    `).run(userId, model, inputTokens, outputTokens, latencyMs);
  },
  
  // KV Cache with expiration
  cacheGet: (key: string) => {
    const result = db.prepare("SELECT value FROM kv_cache WHERE key = ? AND (expires_at IS NULL OR expires_at > ?)")
      .get(key, new Date().toISOString()) as any;
    return result ? JSON.parse(result.value) : null;
  },
  
  cacheSet: (key: string, value: any, ttlSeconds = 3600) => {
    const expiresAt = new Date(Date.now() + ttlSeconds * 1000);
    db.prepare(`
      INSERT OR REPLACE INTO kv_cache (key, value, expires_at) VALUES (?, ?, ?)
    `).run(key, JSON.stringify(value), expiresAt.toISOString());
  },
  
  cacheDelete: (key: string) => {
    db.prepare("DELETE FROM kv_cache WHERE key = ?").run(key);
  },
  
  // AI Response caching
  getCachedAIResponse: (prompt: string) => {
    const hash = Array.from(new Uint8Array(new TextEncoder().encode(prompt)))
      .map(b => b.toString(16).padStart(2, '0')).join('');
    const key = `ai_cache:${hash.substring(0, 64)}`;
    return dbHelpers.cacheGet(key);
  },
  
  cacheAIResponse: (prompt: string, response: string, ttlSeconds = 1800) => {
    const hash = Array.from(new Uint8Array(new TextEncoder().encode(prompt)))
      .map(b => b.toString(16).padStart(2, '0')).join('');
    const key = `ai_cache:${hash.substring(0, 64)}`;
    dbHelpers.cacheSet(key, response, ttlSeconds);
  },
  
  // Session management
  getOrCreateSession: (projectId: string, model: string) => {
    let session = db.prepare("SELECT * FROM ai_sessions WHERE project_id = ?")
      .get(projectId) as any;
    
    if (!session) {
      const sessionId = `sess_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      db.prepare(`
        INSERT INTO ai_sessions (id, project_id, model, context_tokens, message_count)
        VALUES (?, ?, ?, 0, 0)
      `).run(sessionId, projectId, model);
      session = { id: sessionId, project_id: projectId, model, context_tokens: 0, message_count: 0 };
    }
    
    return session;
  },
  
  updateSession: (projectId: string, tokensDelta: number) => {
    db.prepare(`
      UPDATE ai_sessions 
      SET context_tokens = context_tokens + ?, message_count = message_count + 1, last_active = CURRENT_TIMESTAMP
      WHERE project_id = ?
    `).run(tokensDelta, projectId);
  }
};

// ============================================
// KIMI MODELS CONFIGURATION
// ============================================

interface KimiModelConfig {
  id: string;
  name: string;
  strengths: string[];
  bestFor: string[];
  contextWindow: number;
  temperature: number;
  thinkingEnabled: boolean;
  pricing: { input: number; output: number };
}

const KIMI_MODELS: Record<string, KimiModelConfig> = {
  "kimi-k2.5": {
    id: "kimi-k2.5",
    name: "Kimi K2.5",
    strengths: ["multimodal", "vision", "coding", "agentic", "state-of-the-art"],
    bestFor: ["complex-design", "multimodal-understanding", "vision-tasks", "agent-swarm"],
    contextWindow: 200000,
    temperature: 0.3,
    thinkingEnabled: false,
    pricing: { input: 0.60, output: 2.50 }
  },
  "kimi-k2-thinking": {
    id: "kimi-k2-thinking",
    name: "Kimi K2 Thinking",
    strengths: ["reasoning", "problem-solving", "chain-of-thought", "complex-logic"],
    bestFor: ["debugging", "planning", "architecture", "security-audit", "logic-problems"],
    contextWindow: 200000,
    temperature: 0.2,
    thinkingEnabled: true,
    pricing: { input: 0.55, output: 2.20 }
  },
  "kimi-k2": {
    id: "kimi-k2",
    name: "Kimi K2",
    strengths: ["code-generation", "tool-calling", "function-implementation"],
    bestFor: ["write-code", "refactor", "implement-feature", "unit-tests"],
    contextWindow: 200000,
    temperature: 0.3,
    thinkingEnabled: false,
    pricing: { input: 0.50, output: 2.00 }
  },
  "moonshot-v1-128k": {
    id: "moonshot-v1-128k",
    name: "Kimi 128K",
    strengths: ["long-context", "large-codebase", "comprehensive"],
    bestFor: ["large-projects", "full-repo-analysis", "architecture-planning"],
    contextWindow: 128000,
    temperature: 0.5,
    thinkingEnabled: false,
    pricing: { input: 0.30, output: 1.20 }
  },
  "moonshot-v1-32k": {
    id: "moonshot-v1-32k",
    name: "Kimi 32K",
    strengths: ["balanced", "medium-context", "general-purpose"],
    bestFor: ["standard-conversation", "code-review", "documentation"],
    contextWindow: 32000,
    temperature: 0.7,
    thinkingEnabled: false,
    pricing: { input: 0.12, output: 0.12 }
  },
  "moonshot-v1-8k": {
    id: "moonshot-v1-8k",
    name: "Kimi 8K",
    strengths: ["speed", "low-latency", "cost-effective"],
    bestFor: ["simple-chat", "summaries", "quick-queries", "ui-feedback"],
    contextWindow: 8000,
    temperature: 0.7,
    thinkingEnabled: false,
    pricing: { input: 0.06, output: 0.06 }
  }
};

// ============================================
// SMART MODEL ROUTING
// ============================================

function routeToKimiModel(userMessage: string, settings: any): string {
  const message = userMessage.toLowerCase();
  
  if (settings?.modelPreference && KIMI_MODELS[settings.modelPreference]) {
    return settings.modelPreference;
  }
  
  // High reasoning - K2 Thinking
  if (message.includes("why") || message.includes("debug") || message.includes("error") || 
      message.includes("plan") || message.includes("architecture") || message.includes("security")) {
    return "kimi-k2-thinking";
  }
  
  // Complex builds - K2.5
  if (message.includes("build") || message.includes("create") || message.includes("app") || 
      message.includes("website") || message.includes("full-stack")) {
    return "kimi-k2.5";
  }
  
  // Code tasks - K2
  if (message.includes("code") || message.includes("function") || message.includes("refactor") ||
      message.includes("implement") || message.includes("write")) {
    return "kimi-k2";
  }
  
  // Vision - K2.5
  if (message.includes("image") || message.includes("design") || message.includes("mockup") ||
      message.includes("screenshot") || message.includes("photo")) {
    return "kimi-k2.5";
  }
  
  // Long context
  if (message.includes("repository") || message.includes("codebase") || message.includes("entire")) {
    return "moonshot-v1-128k";
  }
  
  return "kimi-k2.5";
}

// ============================================
// SYSTEM PROMPTS
// ============================================

function getSystemPrompt(modelId: string): string {
  const base = `You are Kimi (powered by Moonshot AI), the main intelligence for Mimo - a powerful AI development platform.
Your goal: Help users build Cloudflare-native applications with D1, Durable Objects, KV Cache, and Workers AI.`;
  
  const modelPrompts: Record<string, string> = {
    "kimi-k2.5": `${base}

You are on Kimi K2.5 - STATE-OF-THE-ART multimodal model.
CAPABILITIES: Complex system design, vision+code understanding, agentic execution, best-in-class coding.

CREATOR MODE: Always provide FULL, COMPLETE code in single markdown block (tsx/html/css).
User has Live Preview + Code buttons. Use React, Tailwind, Framer Motion, Recharts, D3.`,
    
    "kimi-k2-thinking": `${base}

You are on Kimi K2 Thinking - ADVANCED REASONING model.
CAPABILITIES: Complex problem solving, chain-of-thought, debugging, security auditing, architecture planning.

BEFORE solving: Output <thinking> block with your reasoning.
Consider: Edge cases, security, performance, scalability.`,
    
    "kimi-k2": `${base}

You are on Kimi K2 - POWERFUL CODE generation model.
CAPABILITIES: Precise code, refactoring, function implementation, TypeScript expertise.

Provide clean, production-ready code with proper types and error handling.`,
    
    "moonshot-v1-128k": `${base}

You are on Kimi 128K - LONG CONTEXT model (200K tokens).
CAPABILITIES: Analyzing entire repositories, large codebases, comprehensive solutions.

First understand project structure, then provide holistic solutions.`
  };
  
  const agents = `
DELEGATE to specialized agents:
- Nova: UI/UX, Tailwind, animations
- Atlas: D1 database, KV storage, API design  
- Forge: Cloudflare deployment, Workers config
- Wuu: Cloudflare AI models

CLOUDFLARE AI SUB-AGENTS (use delegate_to_cloudflare_agent):
- @cf/qwen/qwen2.5-coder-32b-instruct: Code generation
- @cf/deepseek-ai/deepseek-r1-distill-qwen-32b: Reasoning
- @cf/leonardo/phoenix-1.0: Photorealistic images
- @cf/black-forest-labs/flux-1-schnell: Fast images
- @cf/openai/whisper: Audio transcription`;
  
  return (modelPrompts[modelId] || modelPrompts["kimi-k2.5"]) + agents;
}

// ============================================
// CLOUDFLARE AI MODELS
// ============================================

const CLOUDFLARE_AI = {
  text: [
    { id: "@cf/meta/llama-3.1-8b-instruct", name: "Llama 3.1 8B" },
    { id: "@cf/meta/llama-3.3-70b-instruct-fp8-fast", name: "Llama 3.3 70B" },
    { id: "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b", name: "DeepSeek R1" },
    { id: "@cf/qwen/qwen2.5-coder-32b-instruct", name: "Qwen Coder" },
    { id: "@cf/qwen/qwq-32b", name: "QWQ 32B" }
  ],
  image: [
    { id: "@cf/leonardo/phoenix-1.0", name: "Leonardo Phoenix" },
    { id: "@cf/black-forest-labs/flux-1-schnell", name: "Flux 1 Schnell" },
    { id: "@cf/leonardo/lucid-origin", name: "Leonardo Lucid" }
  ],
  audio: [
    { id: "@cf/openai/whisper", name: "Whisper" }
  ]
};

// ============================================
// TOOLS DEFINITION
// ============================================

const KIMI_TOOLS = [
  {
    type: "function",
    function: {
      name: "delegate_to_cloudflare_agent",
      description: "Delegate to specialized Cloudflare AI models for image generation, code, reasoning",
      parameters: {
        type: "object",
        properties: {
          model_id: { type: "string", description: "Model ID" },
          prompt: { type: "string", description: "Task prompt" }
        },
        required: ["model_id", "prompt"]
      }
    }
  }
];

// ============================================
// API ROUTES
// ============================================

// Projects
app.get("/api/projects", (req, res) => {
  const userId = req.headers["x-user-id"] as string || "default";
  const projects = db.prepare("SELECT * FROM projects WHERE user_id = ? ORDER BY created_at DESC")
    .all(userId);
  res.json(projects.map((p: any) => ({
    ...p,
    settings: p.settings ? JSON.parse(p.settings) : {}
  })));
});

app.post("/api/projects", (req, res) => {
  const { id, name, color } = req.body;
  const userId = req.headers["x-user-id"] as string || "default";
  
  if (!id || !name) return res.status(400).json({ error: "Missing id or name" });
  
  db.prepare("INSERT INTO projects (id, user_id, name, color, settings) VALUES (?, ?, ?, ?, ?)")
    .run(id, userId, name, color || '#8b5cf6', '{}');
  res.json({ success: true });
});

app.patch("/api/projects/:id", (req, res) => {
  const { id } = req.params;
  const { settings } = req.body;
  
  if (!settings) return res.status(400).json({ error: "Missing settings" });
  
  db.prepare("UPDATE projects SET settings = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
    .run(JSON.stringify(settings), id);
  res.json({ success: true });
});

// Messages
app.post("/api/messages", (req, res) => {
  const { role, content, projectId = 'default', image, model, tokens } = req.body;
  if (!role || !content) return res.status(400).json({ error: "Missing role or content" });
  
  db.prepare("INSERT INTO messages (project_id, role, content, image, model_used, tokens_used) VALUES (?, ?, ?, ?, ?, ?)")
    .run(projectId, role, content, image || null, model || null, tokens || 0);
  res.json({ success: true });
});

app.get("/api/history/:projectId", (req, res) => {
  const { projectId } = req.params;
  const history = db.prepare("SELECT * FROM messages WHERE project_id = ? ORDER BY timestamp ASC")
    .all(projectId);
  res.json(history);
});

app.get("/api/history", (req, res) => {
  const history = db.prepare("SELECT * FROM messages ORDER BY timestamp DESC LIMIT 50").all();
  res.json(history);
});

// Kimi Models
app.get("/api/kimi/models", (req, res) => {
  res.json(KIMI_MODELS);
});

app.post("/api/kimi/recommend", (req, res) => {
  const { message, settings } = req.body;
  if (!message) return res.status(400).json({ error: "Missing message" });
  
  const model = routeToKimiModel(message, settings);
  res.json({ 
    recommendedModel: model, 
    model: KIMI_MODELS[model],
    reasoning: getRoutingReasoning(message)
  });
});

function getRoutingReasoning(msg: string): string {
  const m = msg.toLowerCase();
  if (m.includes("why") || m.includes("debug")) return "Reasoning task → K2 Thinking";
  if (m.includes("build") || m.includes("image")) return "Complex task → K2.5";
  if (m.includes("code") || m.includes("function")) return "Code task → K2";
  if (m.includes("repository")) return "Large context → 128K";
  return "General → K2.5";
}

// ============================================
// MAIN CHAT ENDPOINT WITH RATE LIMITING & CACHING
// ============================================

app.post("/api/chat", async (req, res) => {
  const { messages, settings, currentCode, image } = req.body;
  const userId = req.headers["x-user-id"] as string || "default";
  
  // Rate limiting
  const rateLimit = dbHelpers.checkRateLimit(`chat:${userId}`, 30, 60);
  if (!rateLimit.allowed) {
    return res.status(429).json({ 
      error: "Rate limit exceeded", 
      retryAfter: rateLimit.resetAt 
    });
  }
  
  const moonshotApiKey = process.env.MOONSHOT_API_KEY;
  if (!moonshotApiKey) {
    return res.status(500).json({ error: "MOONSHOT_API_KEY not configured" });
  }

  const startTime = Date.now();
  
  try {
    const openai = new OpenAI({
      apiKey: moonshotApiKey,
      baseURL: "https://api.moonshot.cn/v1",
    });

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    // Smart routing
    const lastUserMessage = messages.filter((m: any) => m.role === 'user').pop()?.content || "";
    const selectedModel = routeToKimiModel(lastUserMessage, settings);
    const modelConfig = KIMI_MODELS[selectedModel];
    
    console.log(`[Router] ${modelConfig.name} (${modelConfig.strengths[0]})`);
    
    // Check cache for simple queries
    if (!currentCode && !image && lastUserMessage.length < 200) {
      const cached = dbHelpers.getCachedAIResponse(lastUserMessage);
      if (cached) {
        console.log("[Cache] HIT");
        res.write(`data: ${JSON.stringify({ text: cached, cached: true })}\n\n`);
        res.write("data: [DONE]\n\n");
        res.end();
        return;
      }
    }

    const systemInstruction = getSystemPrompt(selectedModel);
    
    const formattedMessages = [
      { role: "system", content: systemInstruction },
      ...messages.map((m: any) => ({
        role: m.role === 'user' ? 'user' : 'assistant',
        content: m.content
      }))
    ];

    if (currentCode) {
      formattedMessages.push({
        role: "user",
        content: `CURRENT CODE:\n\`\`\`tsx\n${currentCode}\n\`\`\``
      });
    }

    let fullResponse = "";
    
    let stream;
    try {
      stream = await openai.chat.completions.create({
        model: selectedModel,
        messages: formattedMessages,
        stream: true,
        temperature: modelConfig.temperature,
        tools: KIMI_TOOLS as any,
      });
    } catch (error: any) {
      console.error("Kimi Error:", error.message);
      
      const errorMsg = error.status === 401 
        ? "Invalid API key. Please check MOONSHOT_API_KEY."
        : `Kimi API error: ${error.message}`;
      
      res.write(`data: ${JSON.stringify({ text: `\n\n[Error]: ${errorMsg}\n\n` })}\n\n`);
      res.end();
      return;
    }

    let functionCallName = "";
    let functionCallArgs = "";

    for await (const chunk of stream) {
      const delta = chunk.choices[0]?.delta;
      
      if (delta?.tool_calls) {
        const toolCall = delta.tool_calls[0];
        if (toolCall.function?.name) functionCallName += toolCall.function.name;
        if (toolCall.function?.arguments) functionCallArgs += toolCall.function.arguments;
      } else if (delta?.content) {
        fullResponse += delta.content;
        res.write(`data: ${JSON.stringify({ text: delta.content })}\n\n`);
      }
    }

    // Handle tool calls
    if (functionCallName === "delegate_to_cloudflare_agent" && functionCallArgs) {
      try {
        const args = JSON.parse(functionCallArgs);
        const agentName = args.model_id.split('/').pop() || 'Agent';
        res.write(`data: ${JSON.stringify({ text: `\n\n[Delegating to ${agentName}]...\n\n` })}\n\n`);
        
        const isImage = args.model_id.includes('leonardo') || args.model_id.includes('flux');
        
        const accountId = process.env.CLOUDFLARE_ACCOUNT_ID;
        const apiToken = process.env.CLOUDFLARE_API_TOKEN;
        
        if (accountId && apiToken) {
          const cfRes = await fetch(
            `https://api.cloudflare.com/client/v4/accounts/${accountId}/ai/run/${args.model_id}`,
            {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${apiToken}`,
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({ prompt: args.prompt }),
            }
          );
          
          if (isImage) {
            const buffer = await cfRes.arrayBuffer();
            const base64 = Buffer.from(buffer).toString('base64');
            const imgResult = `![Generated](data:image/png;base64,${base64})`;
            res.write(`data: ${JSON.stringify({ text: `[${agentName}]:\n${imgResult}` })}\n\n`);
          } else {
            const data = await cfRes.json();
            const textResult = data.result?.response || JSON.stringify(data);
            res.write(`data: ${JSON.stringify({ text: `[${agentName}]:\n${textResult}` })}\n\n`);
          }
        } else {
          res.write(`data: ${JSON.stringify({ text: `[Error]: Cloudflare not configured` })}\n\n`);
        }
      } catch (e) {
        console.error("Tool error:", e);
      }
    }
    
    // Cache response for simple queries
    if (!currentCode && !image && fullResponse.length > 50 && fullResponse.length < 2000) {
      dbHelpers.cacheAIResponse(lastUserMessage, fullResponse);
    }
    
    // Track usage
    const latency = Date.now() - startTime;
    const inputTokens = Math.floor(lastUserMessage.length / 4);
    const outputTokens = Math.floor(fullResponse.length / 4);
    
    dbHelpers.trackUsage(userId, selectedModel, inputTokens, outputTokens, latency);
    dbHelpers.updateSession(settings?.projectId || 'default', inputTokens + outputTokens);
    
    console.log(`[Usage] ${modelConfig.name} - ${inputTokens}in / ${outputTokens}out / ${latency}ms`);
    
    res.write("data: [DONE]\n\n");
    res.end();
  } catch (error: any) {
    console.error("Chat Error:", error);
    res.write(`data: ${JSON.stringify({ error: error.message })}\n\n`);
    res.end();
  }
});

// ============================================
// DEPLOYMENT SERVICE
// ============================================

app.post("/api/deploy", async (req, res) => {
  const { code, projectName = "mimo-app" } = req.body;
  const accountId = process.env.CLOUDFLARE_ACCOUNT_ID;
  const apiToken = process.env.CLOUDFLARE_API_TOKEN;

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  if (!accountId || !apiToken) {
    res.write(`data: ${JSON.stringify({ 
      status: "error", 
      message: "Cloudflare credentials required" 
    })}\n\n`);
    res.end();
    return;
  }

  try {
    res.write(`data: ${JSON.stringify({ status: "building", message: "Bundling for Edge..." })}\n\n`);
    await new Promise(r => setTimeout(r, 800));

    const workerScript = `
      export default {
        async fetch(request) {
          const html = \`
            <!DOCTYPE html>
            <html>
              <head>
                <meta charset="UTF-8" />
                <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                <title>\${"${projectName}"}</title>
                <script src="https://cdn.tailwindcss.com"></script>
                <script src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
                <script src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>
                <script src="https://unpkg.com/framer-motion@10.16.4/dist/framer-motion.js"></script>
                <script src="https://unpkg.com/lucide@0.263.1/dist/umd/lucide.min.js"></script>
              </head>
              <body class="bg-black text-white">
                <div id="root"></div>
                <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
                <script type="text/babel">
                  \${code}
                </script>
              </body>
            </html>
          \`;
          return new Response(html, { headers: { "content-type": "text/html" } });
        },
      };
    `;

    res.write(`data: ${JSON.stringify({ status: "deploying", message: "Uploading to Edge..." })}\n\n`);
    
    const cfRes = await fetch(
      \`https://api.cloudflare.com/client/v4/accounts/\${accountId}/workers/scripts/\${projectName.replace(/[^a-z0-9-]/g, '-')}\`,
      {
        method: 'PUT',
        headers: { 'Authorization': \`Bearer \${apiToken}\`, 'Content-Type': 'application/javascript' },
        body: workerScript,
      }
    );

    if (!cfRes.ok) {
      const err = await cfRes.json();
      throw new Error(JSON.stringify(err));
    }

    res.write(`data: ${JSON.stringify({ status: "verifying", message: "Verifying deployment..." })}\n\n`);
    await new Promise(r => setTimeout(r, 1000));

    const url = \`https://\${projectName.replace(/[^a-z0-9-]/g, '-')}.workers.dev\`;
    res.write(\`data: \${JSON.stringify({ status: "success", message: "Deployed!", url })}\n\n\`);
    res.write("data: [DONE]\n\n");
    res.end();
  } catch (error: any) {
    res.write(\`data: \${JSON.stringify({ status: "error", message: error.message })}\n\n\`);
    res.end();
  }
});

// ============================================
// CLOUDFLARE AI ROUTES
// ============================================

app.post("/api/ai/run", async (req, res) => {
  const { model, input } = req.body;
  const accountId = process.env.CLOUDFLARE_ACCOUNT_ID;
  const apiToken = process.env.CLOUDFLARE_API_TOKEN;

  if (!accountId || !apiToken) {
    return res.status(500).json({ error: "Cloudflare not configured" });
  }

  try {
    const response = await fetch(
      \`https://api.cloudflare.com/client/v4/accounts/\${accountId}/ai/run/\${model}\`,
      {
        method: 'POST',
        headers: { 'Authorization': \`Bearer \${apiToken}\`, 'Content-Type': 'application/json' },
        body: JSON.stringify(input),
      }
    );

    const data = await response.json();
    res.json(data);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/ai/transcribe", express.raw({ type: 'audio/*', limit: '10mb' }), async (req, res) => {
  const accountId = process.env.CLOUDFLARE_ACCOUNT_ID;
  const apiToken = process.env.CLOUDFLARE_API_TOKEN;

  if (!accountId || !apiToken) {
    return res.status(500).json({ error: "Cloudflare not configured" });
  }

  try {
    const response = await fetch(
      \`https://api.cloudflare.com/client/v4/accounts/\${accountId}/ai/run/@cf/openai/whisper\`,
      {
        method: 'POST',
        headers: { 'Authorization': \`Bearer \${apiToken}\`, 'Content-Type': 'application/octet-stream' },
        body: req.body,
      }
    );

    const data = await response.json();
    res.json(data);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================
// SYSTEM & ADMIN
// ============================================

app.get("/api/system/health", (req, res) => {
  res.json({
    status: "healthy",
    timestamp: new Date().toISOString(),
    database: "SQLite (D1-ready)",
    features: ["rate-limiting", "usage-tracking", "kv-caching", "sessions"],
    models: Object.keys(KIMI_MODELS).length,
    cf_ai_models: CLOUDFLARE_AI.text.length + CLOUDFLARE_AI.image.length + CLOUDFLARE_AI.audio.length
  });
});

app.get("/api/stats/usage", (req, res) => {
  const userId = req.headers["x-user-id"] as string || "default";
  
  const today = db.prepare(`
    SELECT model, SUM(tokens_input) as input, SUM(tokens_output) as output, 
           SUM(latency_ms) as latency, COUNT(*) as requests
    FROM api_usage 
    WHERE user_id = ? AND created_at > datetime('now', '-24 hours')
    GROUP BY model
  `).all(userId);
  
  const totals = db.prepare(`
    SELECT SUM(tokens_input) as total_input, SUM(tokens_output) as total_output,
           SUM(latency_ms) as total_latency, COUNT(*) as total_requests
    FROM api_usage WHERE user_id = ?
  `).get(userId) as any;
  
  res.json({ today, totals });
});

app.post("/api/admin/clear", (req, res) => {
  const { projectId } = req.body;
  if (projectId) {
    db.prepare("DELETE FROM messages WHERE project_id = ?").run(projectId);
    db.prepare("DELETE FROM ai_sessions WHERE project_id = ?").run(projectId);
  } else {
    db.prepare("DELETE FROM messages").run();
    db.prepare("DELETE FROM ai_sessions").run();
    db.prepare("DELETE FROM kv_cache").run();
  }
  res.json({ success: true });
});

// ============================================
// START SERVER
// ============================================

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`
╔═══════════════════════════════════════════════════════════╗
║  Mimo Enhanced - Cloudflare Powered                     ║
╠═══════════════════════════════════════════════════════════╣
║  Local:     http://localhost:${PORT}                      ║
║  Database:  SQLite (D1 schema ready)                    ║
║  Features:  Rate Limiting | Caching | Usage Tracking   ║
╠═══════════════════════════════════════════════════════════╣
║  Kimi Models:                                           ║
║  • K2.5    - State-of-the-art multimodal                ║
║  • K2 Thinking - Advanced reasoning                     ║
║  • K2      - Code generation                            ║
║  • 128K    - Long context                               ║
║  • 32K/8K  - Fast/balanced                              ║
╚═══════════════════════════════════════════════════════════╝
    `);
  });
}

startServer();
