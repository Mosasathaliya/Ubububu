console.log("CF_ID:", process.env.CLOUDFLARE_ACCOUNT_ID ? "YES" : "NO");
console.log("CF_TOKEN:", process.env.CLOUDFLARE_API_TOKEN ? "YES" : "NO");
