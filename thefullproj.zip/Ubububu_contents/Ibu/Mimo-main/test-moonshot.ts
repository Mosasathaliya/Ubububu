import OpenAI from "openai";

async function test() {
  try {
    const openai = new OpenAI({
      apiKey: "sk-2skpGzfuLv4P4lPNC3cZ5EiGqwV4WYWLRMVky0boV6NPAsXS",
      baseURL: "https://api.moonshot.cn/v1",
    });

    const response = await openai.chat.completions.create({
      model: "moonshot-v1-8k",
      messages: [{ role: "user", content: "Hello" }],
    });

    console.log("Success:", response.choices[0].message.content);
  } catch (error) {
    console.error("Error:", error);
  }
}

test();
