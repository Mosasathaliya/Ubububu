/*
 * Mimo - Cloudflare Workers Backend
 * Powered by D1, Durable Objects, KV Cache, and Cloudflare AI
 * 
 * This architecture provides:
 * - D1: Persistent SQL database for projects, messages, users
 * - Durable Objects: Real-time sessions, AI streaming, connection management
 * - KV Cache: Fast caching for AI responses, rate limiting
 * - Cloudflare AI: Edge AI inference
 */

export interface Env {
  // D1 Database
  DB: D1Database;
  
  // KV Cache
  CACHE: KVNamespace;
  
  // Durable Objects
  SESSIONS: DurableObjectNamespace;
  
  // Cloudflare AI
  AI: Ai;
  
  // Environment variables
  MOONSHOT_API_KEY: string;
  CLOUDFLARE_ACCOUNT_ID: string;
  CLOUDFLARE_API_TOKEN: string;
  
  // Configuration
  ENVIRONMENT: string;
}

// ============================================
// D1 DATABASE SCHEMA
// ============================================

export const dbSchema = `
-- Projects table (multi-tenant)
CREATE TABLE IF NOT EXISTS projects (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  color TEXT DEFAULT '#8b5cf6',
  status TEXT DEFAULT 'active',
  settings TEXT DEFAULT '{}',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_projects_user ON projects(user_id);

-- Chat history per project
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id TEXT NOT NULL,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  image TEXT,
  model_used TEXT,
  tokens_used INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_messages_project ON messages(project_id);
CREATE INDEX IF NOT EXISTS idx_messages_created ON messages(created_at);

-- User/session management
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE,
  api_key TEXT,
  plan TEXT DEFAULT 'free',
  credits INTEGER DEFAULT 100,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- API usage tracking
CREATE TABLE IF NOT EXISTS api_usage (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  model TEXT NOT NULL,
  tokens_input INTEGER DEFAULT 0,
  tokens_output INTEGER DEFAULT 0,
  latency_ms INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_usage_user ON api_usage(user_id);
CREATE INDEX IF NOT EXISTS idx_usage_created ON api_usage(created_at);

-- Rate limiting
CREATE TABLE IF NOT EXISTS rate_limits (
  key TEXT PRIMARY KEY,
  count INTEGER DEFAULT 0,
  reset_at DATETIME NOT NULL
);

-- AI Sessions (for tracking conversation context)
CREATE TABLE IF NOT EXISTS ai_sessions (
  id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL,
  model TEXT NOT NULL,
  context_tokens INTEGER DEFAULT 0,
  message_count INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  last_active DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_sessions_project ON ai_sessions(project_id);
`;

// ============================================
// KIMI MODEL ROUTING ENGINE
// ============================================

interface KimiModelConfig {
  id: string;
  name: string;
  strengths: string[];
  bestFor: string[];
  contextWindow: number;
  temperature: number;
  thinkingEnabled: boolean;
  pricing: { input: number; output: number };
}

export const KIMI_MODELS: Record<string, KimiModelConfig> = {
  "kimi-k2.5": {
    id: "kimi-k2.5",
    name: "Kimi K2.5",
    strengths: ["multimodal", "vision", "coding", "agentic", "state-of-the-art"],
    bestFor: ["complex-design", "multimodal-understanding", "vision-tasks", "agent-swarm"],
    contextWindow: 200000,
    temperature: 0.3,
    thinkingEnabled: false,
    pricing: { input: 0.60, output: 2.50 }
  },
  "kimi-k2-thinking": {
    id: "kimi-k2-thinking",
    name: "Kimi K2 Thinking",
    strengths: ["reasoning", "problem-solving", "chain-of-thought", "complex-logic"],
    bestFor: ["debugging", "planning", "architecture", "security-audit", "logic-problems"],
    contextWindow: 200000,
    temperature: 0.2,
    thinkingEnabled: true,
    pricing: { input: 0.55, output: 2.20 }
  },
  "kimi-k2": {
    id: "kimi-k2",
    name: "Kimi K2",
    strengths: ["code-generation", "tool-calling", "function-implementation"],
    bestFor: ["write-code", "refactor", "implement-feature", "unit-tests"],
    contextWindow: 200000,
    temperature: 0.3,
    thinkingEnabled: false,
    pricing: { input: 0.50, output: 2.00 }
  },
  "moonshot-v1-128k": {
    id: "moonshot-v1-128k",
    name: "Kimi 128K",
    strengths: ["long-context", "large-codebase", "comprehensive"],
    bestFor: ["large-projects", "full-repo-analysis", "architecture-planning"],
    contextWindow: 128000,
    temperature: 0.5,
    thinkingEnabled: false,
    pricing: { input: 0.30, output: 1.20 }
  },
  "moonshot-v1-32k": {
    id: "moonshot-v1-32k",
    name: "Kimi 32K",
    strengths: ["balanced", "medium-context", "general-purpose"],
    bestFor: ["standard-conversation", "code-review", "documentation"],
    contextWindow: 32000,
    temperature: 0.7,
    thinkingEnabled: false,
    pricing: { input: 0.12, output: 0.12 }
  },
  "moonshot-v1-8k": {
    id: "moonshot-v1-8k",
    name: "Kimi 8K",
    strengths: ["speed", "low-latency", "cost-effective"],
    bestFor: ["simple-chat", "summaries", "quick-queries", "ui-feedback"],
    contextWindow: 8000,
    temperature: 0.7,
    thinkingEnabled: false,
    pricing: { input: 0.06, output: 0.06 }
  }
};

// Smart Model Routing
export function routeToKimiModel(userMessage: string, settings: any): string {
  const message = userMessage.toLowerCase();
  
  if (settings?.modelPreference && KIMI_MODELS[settings.modelPreference]) {
    return settings.modelPreference;
  }
  
  // High reasoning - K2 Thinking
  const reasoningKeywords = ["why", "how does", "debug", "error", "fix", "problem", "plan", "architecture", "security", "logic"];
  if (reasoningKeywords.some(kw => message.includes(kw))) {
    return "kimi-k2-thinking";
  }
  
  // Complex coding - K2.5
  const complexKeywords = ["build", "create", "implement", "develop", "app", "website", "full-stack", "microservice"];
  if (complexKeywords.some(kw => message.includes(kw))) {
    return "kimi-k2.5";
  }
  
  // Standard code - K2
  const codeKeywords = ["write code", "function", "class", "component", "refactor", "test"];
  if (codeKeywords.some(kw => message.includes(kw))) {
    return "kimi-k2";
  }
  
  // Vision - K2.5
  const visionKeywords = ["image", "photo", "screenshot", "design", "mockup", "wireframe"];
  if (visionKeywords.some(kw => message.includes(kw))) {
    return "kimi-k2.5";
  }
  
  // Long context
  if (message.includes("repository") || message.includes("codebase")) {
    return "moonshot-v1-128k";
  }
  
  return "kimi-k2.5";
}

// ============================================
// SYSTEM PROMPTS
// ============================================

export function getSystemPrompt(modelId: string): string {
  const base = `You are Kimi (powered by Moonshot AI), the main intelligence for the Mimo platform.
Your goal is to help users build Cloudflare-native applications using the Wuu Engine.`;
  
  const prompts: Record<string, string> = {
    "kimi-k2.5": `${base}

You are running on Kimi K2.5 - state-of-the-art multimodal model.
EXCELLENT AT: Complex system design, vision+code, agentic execution.

CREATOR MODE: Provide FULL code in single markdown block (tsx/html).`,
    
    "kimi-k2-thinking": `${base}

You are running on Kimi K2 Thinking - advanced reasoning model.
EXCELLENT AT: Debugging, planning, security auditing, logic.

OUTPUT <thinking> blocks with your reasoning before solutions.`,
    
    "kimi-k2": `${base}

You are running on Kimi K2 - powerful code generation model.
EXCELLENT AT: Precise code, refactoring, function implementation.`
  };
  
  const agentSection = `

DELEGATE to specialized agents:
- Nova (UI/UX): Tailwind, animations
- Atlas (Backend): D1, KV, API design
- Forge (DevOps): Cloudflare deployment
- Wuu (AI): Cloudflare AI models

Use delegate_to_cloudflare_agent tool for:
- Image generation: @cf/leonardo/phoenix-1.0
- Code: @cf/qwen/qwen2.5-coder-32b-instruct
- Reasoning: @cf/deepseek-ai/deepseek-r1-distill-qwen-32b`;
  
  return (prompts[modelId] || prompts["kimi-k2.5"]) + agentSection;
}

// ============================================
// DURABLE OBJECT: Session Manager
// ============================================

export class SessionManager implements DurableObject {
  sessions: Map<string, any> = new Map();
  WebSocketPairs: Map<string, WebSocket> = new Map();
  
  constructor(private state: DurableObjectState, private env: Env) {}
  
  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);
    
    // WebSocket upgrade for real-time chat
    if (url.pathname === "/ws") {
      return this.handleWebSocket(request);
    }
    
    // Session management
    if (url.pathname === "/session") {
      return this.handleSession(request);
    }
    
    return new Response("Not Found", { status: 404 });
  }
  
  async handleWebSocket(request: Request): Promise<Response> {
    const pair = new WebSocketPair();
    const sessionId = crypto.randomUUID();
    
    this.WebSocketPairs.set(sessionId, pair[1]);
    
    pair[1].accept();
    
    // Send welcome message
    pair[1].send(JSON.stringify({
      type: "connected",
      sessionId,
      timestamp: Date.now()
    }));
    
    // Handle messages
    pair[1].addEventListener("message", async (event) => {
      try {
        const data = JSON.parse(event.data as string);
        await this.handleMessage(sessionId, data, pair[1]);
      } catch (e) {
        pair[1].send(JSON.stringify({ type: "error", message: "Invalid message" }));
      }
    });
    
    pair[1].addEventListener("close", () => {
      this.WebSocketPairs.delete(sessionId);
    });
    
    return new Response(null, { status: 101, webSocket: pair[0] });
  }
  
  async handleMessage(sessionId: string, data: any, ws: WebSocket): Promise<void> {
    if (data.type === "chat") {
      // Stream AI response to WebSocket
      ws.send(JSON.stringify({ type: "thinking", message: "Routing to Kimi..." }));
      
      // Process and stream back
      const response = await this.processChat(data.message, data.projectId, data.settings);
      
      for (const chunk of this.chunkResponse(response)) {
        ws.send(JSON.stringify({ type: "chunk", content: chunk }));
      }
      
      ws.send(JSON.stringify({ type: "done" }));
    }
  }
  
  async processChat(message: string, projectId: string, settings: any): Promise<string> {
    // This would call the actual AI - implemented in main handler
    return `[Kimi ${routeToKimiModel(message, settings)}]: Processing: ${message.substring(0, 50)}...`;
  }
  
  chunkResponse(response: string): string[] {
    const chunks: string[] = [];
    const words = response.split(" ");
    let current = "";
    
    for (const word of words) {
      if (current.length + word.length > 50) {
        chunks.push(current);
        current = word;
      } else {
        current += " " + word;
      }
    }
    
    if (current) chunks.push(current);
    return chunks;
  }
  
  async handleSession(request: Request): Promise<Response> {
    const method = request.method;
    
    if (method === "POST") {
      const body = await request.json();
      this.sessions.set(body.projectId, {
        ...body,
        created: Date.now()
      });
      return Response.json({ success: true });
    }
    
    if (method === "GET") {
      const url = new URL(request.url);
      const projectId = url.searchParams.get("projectId");
      
      if (projectId) {
        const session = this.sessions.get(projectId);
        return Response.json(session || null);
      }
      
      return Response.json(Array.from(this.sessions.values()));
    }
    
    return new Response("Method not allowed", { status: 405 });
  }
}

// ============================================
// DATABASE HELPERS (D1)
// ============================================

export async function initializeDatabase(db: D1Database): Promise<void> {
  // Split schema into individual statements
  const statements = dbSchema
    .split(';')
    .map(s => s.trim())
    .filter(s => s.length > 0 && !s.startsWith('--'));
  
  for (const statement of statements) {
    try {
      await db.prepare(statement).run();
    } catch (e) {
      // Ignore "already exists" errors
      console.log("DB init:", e);
    }
  }
}

// Project operations
export async function getProjects(db: D1Database, userId: string) {
  return db.prepare(
    "SELECT * FROM projects WHERE user_id = ? ORDER BY created_at DESC"
  ).bind(userId).all();
}

export async function createProject(db: D1Database, project: {
  id: string;
  userId: string;
  name: string;
  color: string;
}) {
  return db.prepare(
    "INSERT INTO projects (id, user_id, name, color) VALUES (?, ?, ?, ?)"
  ).bind(project.id, project.userId, project.name, project.color).run();
}

export async function updateProjectSettings(db: D1Database, projectId: string, settings: object) {
  return db.prepare(
    "UPDATE projects SET settings = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  ).bind(JSON.stringify(settings), projectId).run();
}

// Message operations
export async function saveMessage(db: D1Database, message: {
  projectId: string;
  role: string;
  content: string;
  image?: string;
  model?: string;
  tokens?: number;
}) {
  return db.prepare(
    `INSERT INTO messages (project_id, role, content, image, model_used, tokens_used) 
     VALUES (?, ?, ?, ?, ?, ?)`
  ).bind(
    message.projectId,
    message.role,
    message.content,
    message.image || null,
    message.model || null,
    message.tokens || 0
  ).run();
}

export async function getMessages(db: D1Database, projectId: string, limit = 50) {
  return db.prepare(
    "SELECT * FROM messages WHERE project_id = ? ORDER BY created_at ASC LIMIT ?"
  ).bind(projectId, limit).all();
}

// Usage tracking
export async function trackUsage(db: D1Database, usage: {
  userId: string;
  model: string;
  inputTokens: number;
  outputTokens: number;
  latencyMs: number;
}) {
  return db.prepare(
    `INSERT INTO api_usage (user_id, model, tokens_input, tokens_output, latency_ms) 
     VALUES (?, ?, ?, ?, ?)`
  ).bind(
    usage.userId,
    usage.model,
    usage.inputTokens,
    usage.outputTokens,
    usage.latencyMs
  ).run();
}

// Rate limiting
export async function checkRateLimit(db: D1Database, key: string, limit = 60, windowSeconds = 60): Promise<boolean> {
  const now = new Date();
  const resetAt = new Date(now.getTime() + windowSeconds * 1000);
  
  const result = await db.prepare(
    "SELECT * FROM rate_limits WHERE key = ? AND reset_at > ?"
  ).bind(key, now.toISOString()).first() as any;
  
  if (result && result.count >= limit) {
    return false;
  }
  
  if (result) {
    await db.prepare(
      "UPDATE rate_limits SET count = count + 1 WHERE key = ?"
    ).bind(key).run();
  } else {
    await db.prepare(
      "INSERT INTO rate_limits (key, count, reset_at) VALUES (?, 1, ?)"
    ).bind(key, resetAt.toISOString()).run();
  }
  
  return true;
}

// ============================================
// CACHE HELPERS (KV)
// ============================================

export async function cacheGet(cache: KVNamespace, key: string): Promise<any | null> {
  const value = await cache.get(key);
  if (value) {
    try {
      return JSON.parse(value);
    } catch {
      return value;
    }
  }
  return null;
}

export async function cacheSet(cache: KVNamespace, key: string, value: any, ttlSeconds = 3600): Promise<void> {
  const serialized = typeof value === 'string' ? value : JSON.stringify(value);
  await cache.put(key, serialized, { expirationTtl: ttlSeconds });
}

export async function cacheDelete(cache: KVNamespace, key: string): Promise<void> {
  await cache.delete(key);
}

// Cache AI responses
export async function getCachedResponse(cache: KVNamespace, prompt: string): Promise<string | null> {
  const hash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(prompt));
  const key = `ai:${Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('')}`;
  return cacheGet(cache, key);
}

export async function cacheResponse(cache: KVNamespace, prompt: string, response: string): Promise<void> {
  const hash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(prompt));
  const key = `ai:${Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('')}`;
  await cacheSet(cache, key, response, 1800); // 30 min cache
}

// ============================================
// CLOUDFLARE AI INTEGRATION
// ============================================

export async function runCloudflareAI(ai: Ai, model: string, input: any): Promise<any> {
  return await ai.run(model, input);
}

// ============================================
// EXPORT ALL CONFIG
// ============================================

export const CLOUDFLARE_AI_MODELS = {
  // Text
  "@cf/meta/llama-3.1-8b-instruct": "Llama 3.1 8B",
  "@cf/meta/llama-3.3-70b-instruct-fp8-fast": "Llama 3.3 70B",
  "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b": "DeepSeek R1",
  "@cf/qwen/qwen2.5-coder-32b-instruct": "Qwen Coder",
  "@cf/qwen/qwq-32b": "QWQ 32B",
  
  // Image Generation
  "@cf/leonardo/phoenix-1.0": "Leonardo Phoenix",
  "@cf/black-forest-labs/flux-1-schnell": "Flux 1 Schnell",
  
  // Audio
  "@cf/openai/whisper": "Whisper Transcription"
};

export const KIMI_NATIVE_TOOLS = [
  {
    type: "function",
    function: {
      name: "delegate_to_cloudflare_agent",
      description: "Delegate to specialized Cloudflare AI models",
      parameters: {
        type: "object",
        properties: {
          model_id: { type: "string", description: "Model ID (e.g., @cf/qwen/qwen2.5-coder-32b-instruct)" },
          prompt: { type: "string", description: "Task prompt" }
        },
        required: ["model_id", "prompt"]
      }
    }
  }
];
