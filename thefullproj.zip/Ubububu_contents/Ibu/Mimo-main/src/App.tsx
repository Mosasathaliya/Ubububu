import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Bot, User, Sparkles, Terminal, Database, Cloud, Zap, Trash2, Image as ImageIcon, X, Activity, Globe, Cpu, Layout, Code as CodeIcon, Eye, Menu, CheckCircle2, AlertCircle, Loader2, Mic, Volume2, Ear, Wand2, Settings } from 'lucide-react';
import { runCloudflareAi, transcribeAudio } from './services/cloudflareAi';
import ReactMarkdown from 'react-markdown';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { generateMimoResponse } from './services/kimi';
import Editor from '@monaco-editor/react';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface Message {
  role: 'user' | 'assistant';
  content: string;
  image?: string;
}

interface SystemStats {
  requests_per_sec: number;
  latency_ms: number;
  cache_hit_rate: string;
  active_workers: number;
  d1_storage_used: string;
  kv_keys_count: number;
  durable_objects_active: number;
}

interface ProjectSettings {
  defaultAgent?: string;
  modelPreference?: string;
  displayTheme?: 'dark' | 'light' | 'system';
  enableVoice?: boolean;
}

interface Project {
  id: string;
  name: string;
  color: string;
  status: string;
  settings?: ProjectSettings;
}

function parseAgentMessages(content: string) {
  // Even more resilient regex:
  // - Handles bolding: (?:\*\*)?
  // - Handles brackets with optional internal space: \[\s*(Nova|Atlas|Forge|Mimo|Wuu)\s*\]
  // - Handles optional bolding again: (?:\*\*)?
  // - Handles optional colons and any amount of whitespace: [\s:]*
  const regex = /(?:\*\*)?\[\s*(Nova|Atlas|Forge|Mimo|Wuu)\s*\](?:\*\*)?[\s:]*/gi;
  const parts: { agent: string; text: string }[] = [];
  let lastIndex = 0;
  let currentAgent = 'Mimo';

  let match;
  while ((match = regex.exec(content)) !== null) {
    if (match.index > lastIndex) {
      const text = content.substring(lastIndex, match.index).trim();
      if (text) {
        parts.push({ agent: currentAgent, text });
      }
    }
    // Normalize agent name
    const agentName = match[1].trim().charAt(0).toUpperCase() + match[1].trim().slice(1).toLowerCase();
    currentAgent = agentName;
    lastIndex = match.index + match[0].length;
  }

  if (lastIndex < content.length) {
    const text = content.substring(lastIndex).trim();
    if (text) {
      parts.push({ agent: currentAgent, text });
    }
  }

  // If no agents were found, everything is Mimo
  if (parts.length === 0) {
    parts.push({ agent: 'Mimo', text: content });
  }

  return parts;
}

const MimoCharacter = ({ className, size = "md", isLoading = false }: { className?: string; size?: "sm" | "md" | "lg"; isLoading?: boolean }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isClicked, setIsClicked] = useState(false);
  const dimensions = size === "sm" ? "w-12 h-12" : size === "lg" ? "w-64 h-64" : "w-32 h-32";
  
  // Determine colors based on agent type
  let primaryColor = "#22d3ee"; // Cyan for Mimo
  let coreColor = "#f59e0b"; // Orange for Mimo
  let coreClickColor = "#fbbf24";
  
  const isNova = className?.includes("agent-nova");
  const isAtlas = className?.includes("agent-atlas");
  const isForge = className?.includes("agent-forge");
  const isWuu = className?.includes("agent-wuu");
  const isMimo = !isNova && !isAtlas && !isForge && !isWuu;

  if (isNova) {
    primaryColor = "#ec4899"; // Pink for Nova
    coreColor = "#8b5cf6"; // Purple core
    coreClickColor = "#a78bfa";
  } else if (isAtlas) {
    primaryColor = "#3b82f6"; // Blue for Atlas
    coreColor = "#10b981"; // Green core
    coreClickColor = "#34d399";
  } else if (isForge) {
    primaryColor = "#f97316"; // Orange for Forge
    coreColor = "#ef4444"; // Red core
    coreClickColor = "#f87171";
  } else if (isWuu) {
    primaryColor = "#fb923c"; // Orange for Wuu (Cloudflare)
    coreColor = "#f97316"; // Darker orange core
    coreClickColor = "#fdba74";
  }

  const handleClick = () => {
    setIsClicked(true);
    setTimeout(() => setIsClicked(false), 1000);
  };

  return (
    <motion.div 
      className={cn("relative flex items-center justify-center cursor-pointer", dimensions, className)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={handleClick}
      animate={{ 
        y: isLoading ? [0, -15, 0] : isClicked ? [0, -30, 0] : [0, -10, 0],
        scale: isLoading ? [1, 1.05, 1] : isClicked ? [1, 1.1, 1] : isHovered ? 1.05 : 1,
        rotate: isLoading ? [0, 5, -5, 0] : isClicked ? [0, 10, -10, 0] : 0
      }}
      transition={{ 
        y: { duration: isLoading ? 1.5 : isClicked ? 0.5 : 4, repeat: isClicked ? 0 : Infinity, ease: "easeInOut" },
        scale: { duration: isLoading ? 1.5 : 0.3, repeat: isLoading ? Infinity : 0 },
        rotate: { duration: isLoading ? 1.5 : 0.5, repeat: isLoading ? Infinity : 0 }
      }}
    >
      {/* Agent Body (Detailed SVG) */}
      <svg viewBox="0 0 100 100" className="w-full h-full">
        <defs>
          <linearGradient id="armorGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="100%" stopColor="#e2e8f0" />
          </linearGradient>
          <linearGradient id="darkGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1e293b" />
            <stop offset="100%" stopColor="#0f172a" />
          </linearGradient>
        </defs>

        {/* Tail */}
        <motion.path 
          d={isAtlas ? "M35 85 L20 95 L10 80 L5 70 L15 65" : isForge ? "M35 85 Q25 100 5 70 Q15 60 20 65" : "M35 85 Q20 95 10 80 Q5 70 15 65"} 
          fill="none" 
          stroke={primaryColor} 
          strokeWidth="4" 
          strokeLinecap={isAtlas ? "square" : "round"}
          strokeLinejoin={isAtlas ? "miter" : "round"}
          animate={{ 
            opacity: [0.6, 1, 0.6],
            rotate: isHovered ? [0, 20, -20, 0] : 0
          }}
          transition={{ 
            opacity: { duration: 3, repeat: Infinity },
            rotate: { duration: 0.5, repeat: isHovered ? Infinity : 0 }
          }}
        />

        {/* Ears / Antennas */}
        {isNova && (
          <>
            <path d="M20 35 Q10 5 35 20 Z" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5" />
            <path d="M80 35 Q90 5 65 20 Z" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5" />
            <path d="M22 30 Q15 12 32 22 Z" fill="url(#darkGrad)" />
            <path d="M78 30 Q85 12 68 22 Z" fill="url(#darkGrad)" />
          </>
        )}
        {isAtlas && (
          <>
            <rect x="15" y="5" width="12" height="25" rx="2" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5" transform="rotate(-15 21 17)" />
            <rect x="73" y="5" width="12" height="25" rx="2" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5" transform="rotate(15 79 17)" />
            <rect x="18" y="8" width="6" height="18" rx="1" fill="url(#darkGrad)" transform="rotate(-15 21 17)" />
            <rect x="76" y="8" width="6" height="18" rx="1" fill="url(#darkGrad)" transform="rotate(15 79 17)" />
          </>
        )}
        {isForge && (
          <>
            <path d="M25 35 L5 10 L35 25 Z" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5" />
            <path d="M75 35 L95 10 L65 25 Z" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5" />
            <path d="M25 30 L12 15 L32 25 Z" fill="url(#darkGrad)" />
            <path d="M75 30 L88 15 L68 25 Z" fill="url(#darkGrad)" />
          </>
        )}
        {isMimo && (
          <>
            <path d="M20 30 L10 5 L35 20 Z" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5" />
            <path d="M80 30 L90 5 L65 20 Z" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5" />
            <path d="M22 28 L15 12 L32 22 Z" fill="url(#darkGrad)" />
            <path d="M78 28 L85 12 L68 22 Z" fill="url(#darkGrad)" />
          </>
        )}

        {/* Head Shell */}
        {isAtlas ? (
          <rect x="20" y="20" width="60" height="45" rx="8" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5" />
        ) : isForge ? (
          <path d="M20 45 L35 15 L65 15 L80 45 L65 65 L35 65 Z" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5" />
        ) : isNova ? (
          <circle cx="50" cy="40" r="30" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5" />
        ) : (
          <path d="M20 45 Q20 15 50 15 Q80 15 80 45 Q80 65 50 65 Q20 65 20 45" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5" />
        )}
        
        {/* Visor Area */}
        {isAtlas ? (
          <rect x="25" y="35" width="50" height="20" rx="4" fill="url(#darkGrad)" />
        ) : isForge ? (
          <path d="M25 40 L50 30 L75 40 L65 55 L35 55 Z" fill="url(#darkGrad)" />
        ) : isNova ? (
          <ellipse cx="50" cy="42" rx="25" ry="15" fill="url(#darkGrad)" />
        ) : (
          <path d="M25 40 Q50 35 75 40 L70 55 Q50 60 30 55 Z" fill="url(#darkGrad)" />
        )}
        
        {/* Stylized Eyes - Change expression on click */}
        <motion.path 
          d={isClicked ? "M32 48 Q38 42 44 48" : (isAtlas ? "M32 45 L44 45" : isForge ? "M32 42 L44 46" : "M32 44 Q40 40 45 46")} 
          fill="none" 
          stroke={isClicked ? coreClickColor : primaryColor} 
          strokeWidth="3" 
          strokeLinecap={isAtlas ? "square" : "round"}
          animate={{ 
            opacity: isHovered ? 1 : 0.8,
            scale: isHovered ? 1.1 : 1
          }}
          transition={{ duration: 0.2 }}
        />
        <motion.path 
          d={isClicked ? "M68 48 Q62 42 56 48" : (isAtlas ? "M56 45 L68 45" : isForge ? "M68 42 L56 46" : "M68 44 Q60 40 55 46")} 
          fill="none" 
          stroke={isClicked ? coreClickColor : primaryColor} 
          strokeWidth="3" 
          strokeLinecap={isAtlas ? "square" : "round"}
          animate={{ 
            opacity: isHovered ? 1 : 0.8,
            scale: isHovered ? 1.1 : 1
          }}
          transition={{ duration: 0.2 }}
        />
        
        {/* Face Mask Detail */}
        {isMimo && (
          <motion.path 
            d="M42 54 Q50 58 58 54" 
            fill="none" 
            stroke={primaryColor} 
            strokeWidth="1.5" 
            strokeLinecap="round" 
            animate={{ opacity: [0.4, 0.8, 0.4] }}
            transition={{ duration: 4, repeat: Infinity }}
          />
        )}

        {/* Body Armor */}
        {isAtlas ? (
          <>
            <rect x="30" y="65" width="40" height="20" rx="4" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5" />
            <rect x="35" y="65" width="30" height="15" rx="2" fill="url(#darkGrad)" />
          </>
        ) : isForge ? (
          <>
            <path d="M35 65 L30 85 L50 95 L70 85 L65 65 Z" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5" />
            <path d="M40 65 L42 80 L50 85 L58 80 L60 65 Z" fill="url(#darkGrad)" />
          </>
        ) : isNova ? (
          <>
            <path d="M35 65 Q50 95 65 65 Z" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5" />
            <path d="M40 65 Q50 85 60 65 Z" fill="url(#darkGrad)" />
          </>
        ) : (
          <>
            <path d="M35 65 L30 85 Q50 95 70 85 L65 65 Z" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5" />
            <path d="M40 65 L42 80 L58 80 L60 65 Z" fill="url(#darkGrad)" />
          </>
        )}

        {/* Core Jewel */}
        {isNova ? (
          <motion.circle 
            cx="50" cy="72" r="6"
            fill={isClicked ? coreClickColor : coreColor} 
            animate={{ 
              fill: isClicked ? [coreClickColor, "#ffffff", coreClickColor] : [coreColor, coreClickColor, coreColor],
              scale: isClicked ? [1, 1.4, 1] : [1, 1.1, 1]
            }}
            transition={{ duration: isClicked ? 0.3 : 2, repeat: isClicked ? 0 : Infinity }}
          />
        ) : isAtlas ? (
          <motion.rect 
            x="44" y="68" width="12" height="12" rx="2"
            fill={isClicked ? coreClickColor : coreColor} 
            animate={{ 
              fill: isClicked ? [coreClickColor, "#ffffff", coreClickColor] : [coreColor, coreClickColor, coreColor],
              scale: isClicked ? [1, 1.4, 1] : [1, 1.1, 1]
            }}
            transition={{ duration: isClicked ? 0.3 : 2, repeat: isClicked ? 0 : Infinity }}
          />
        ) : isForge ? (
          <motion.path 
            d="M50 68 L58 72 L50 82 L42 72 Z" 
            fill={isClicked ? coreClickColor : coreColor} 
            animate={{ 
              fill: isClicked ? [coreClickColor, "#ffffff", coreClickColor] : [coreColor, coreClickColor, coreColor],
              scale: isClicked ? [1, 1.4, 1] : [1, 1.1, 1]
            }}
            transition={{ duration: isClicked ? 0.3 : 2, repeat: isClicked ? 0 : Infinity }}
          />
        ) : (
          <motion.path 
            d="M50 68 L58 75 L50 82 L42 75 Z" 
            fill={isClicked ? coreClickColor : coreColor} 
            animate={{ 
              fill: isClicked ? [coreClickColor, "#ffffff", coreClickColor] : [coreColor, coreClickColor, coreColor],
              scale: isClicked ? [1, 1.4, 1] : [1, 1.1, 1]
            }}
            transition={{ duration: isClicked ? 0.3 : 2, repeat: isClicked ? 0 : Infinity }}
          />
        )}

        {/* Floating Limbs */}
        {isAtlas ? (
          <>
            <motion.rect 
              x="11" y="66" width="8" height="8" rx="1" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5"
              animate={{ 
                y: isClicked ? [0, -10, 0] : [0, 8, 0], 
                x: isClicked ? [0, -5, 0] : [0, 2, 0] 
              }} 
              transition={{ duration: isClicked ? 0.5 : 3, repeat: isClicked ? 0 : Infinity }}
            />
            <motion.rect 
              x="81" y="66" width="8" height="8" rx="1" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5"
              animate={{ 
                y: isClicked ? [0, -10, 0] : [0, -8, 0], 
                x: isClicked ? [0, 5, 0] : [0, -2, 0] 
              }} 
              transition={{ duration: isClicked ? 0.5 : 3, repeat: isClicked ? 0 : Infinity }}
            />
          </>
        ) : isForge ? (
          <>
            <motion.path 
              d="M15 65 L19 75 L11 75 Z" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5"
              animate={{ 
                y: isClicked ? [0, -10, 0] : [0, 8, 0], 
                x: isClicked ? [0, -5, 0] : [0, 2, 0] 
              }} 
              transition={{ duration: isClicked ? 0.5 : 3, repeat: isClicked ? 0 : Infinity }}
            />
            <motion.path 
              d="M85 65 L89 75 L81 75 Z" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5"
              animate={{ 
                y: isClicked ? [0, -10, 0] : [0, -8, 0], 
                x: isClicked ? [0, 5, 0] : [0, -2, 0] 
              }} 
              transition={{ duration: isClicked ? 0.5 : 3, repeat: isClicked ? 0 : Infinity }}
            />
          </>
        ) : (
          <>
            <motion.circle 
              cx="15" cy="70" r="4" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5"
              animate={{ 
                y: isClicked ? [0, -10, 0] : [0, 8, 0], 
                x: isClicked ? [0, -5, 0] : [0, 2, 0] 
              }} 
              transition={{ duration: isClicked ? 0.5 : 3, repeat: isClicked ? 0 : Infinity }}
            />
            <motion.circle 
              cx="85" cy="70" r="4" fill="url(#armorGrad)" stroke="#0f172a" strokeWidth="0.5"
              animate={{ 
                y: isClicked ? [0, -10, 0] : [0, -8, 0], 
                x: isClicked ? [0, 5, 0] : [0, -2, 0] 
              }} 
              transition={{ duration: isClicked ? 0.5 : 3, repeat: isClicked ? 0 : Infinity }}
            />
          </>
        )}
      </svg>
      
      {/* Orbiting Data Particles - Simplified to avoid rendering issues */}
      {[...Array(3)].map((_, i) => (
        <motion.div 
          key={i}
          className="absolute rounded-full border border-cyan-400/10"
          animate={{ 
            rotate: 360,
            scale: isHovered ? 1.1 : 1
          }}
          transition={{ 
            rotate: { duration: (10 + i * 5) / (isHovered ? 2 : 1), repeat: Infinity, ease: "linear" },
            scale: { duration: 0.3 }
          }}
          style={{
            width: `${60 + i * 25}px`,
            height: `${60 + i * 25}px`,
          }}
        >
          <div 
            className="absolute w-1 h-1 bg-cyan-400/50 rounded-full"
            style={{ top: 0, left: '50%', transform: 'translate(-50%, -50%)' }}
          />
        </motion.div>
      ))}
    </motion.div>
  );
};

const LivePreview = ({ code }: { code: string }) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    let url: string | null = null;
    if (iframeRef.current && code) {
      const isReact = code.includes('import React') || code.includes('export default') || code.includes('useState') || code.includes('useEffect');
      
      let html = '';
      if (isReact) {
        html = `
          <!DOCTYPE html>
          <html>
            <head>
              <meta charset="UTF-8" />
              <script src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
              <script src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>
              <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
              <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
              <script src="https://unpkg.com/framer-motion@10.16.4/dist/framer-motion.js"></script>
              <script src="https://unpkg.com/recharts/umd/Recharts.js"></script>
              <script src="https://unpkg.com/d3@7"></script>
              <script src="https://cdn.tailwindcss.com"></script>
              <style>
                body { background: #0A0A0B; color: white; margin: 0; font-family: sans-serif; min-height: 100vh; overflow-x: hidden; }
                #root { width: 100%; height: 100%; }
                .preview-loading { display: flex; flex-direction: column; gap: 12px; align-items: center; justify-content: center; height: 100vh; font-family: monospace; color: #666; }
                .spinner { width: 24px; height: 24px; border: 2px solid #333; border-top-color: #6366f1; border-radius: 50%; animation: spin 1s linear infinite; }
                @keyframes spin { to { transform: rotate(360deg); } }
              </style>
            </head>
            <body>
              <div id="root">
                <div class="preview-loading">
                  <div class="spinner"></div>
                  <span>Initializing Kimi Runtime...</span>
                </div>
              </div>
              <script type="text/babel">
                const { useState, useEffect, useMemo, useCallback, useRef, useLayoutEffect } = React;
                
                // Setup Framer Motion
                const motion = window.Motion ? window.Motion.motion : (window.framerMotion ? window.framerMotion.motion : null);
                const AnimatePresence = window.Motion ? window.Motion.AnimatePresence : (window.framerMotion ? window.framerMotion.AnimatePresence : null);
                
                // Setup Recharts
                const { 
                  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, 
                  ResponsiveContainer, AreaChart, Area, BarChart, Bar, 
                  PieChart, Pie, Cell, ScatterChart, Scatter, Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis
                } = window.Recharts || {};
                
                // Mock lucide-react for the preview
                const Lucide = window.lucide;
                const IconProxy = new Proxy({}, {
                  get: (target, name) => {
                    return (props) => {
                      const ref = useRef();
                      useEffect(() => {
                        if (ref.current && Lucide && Lucide.icons[name]) {
                          Lucide.createIcons({
                            icons: { [name]: Lucide.icons[name] },
                            nameAttr: 'data-lucide'
                          });
                        }
                      }, []);
                      return <i data-lucide={name.toLowerCase()} {...props} ref={ref} />;
                    };
                  }
                });

                // Expose libraries to the global scope of the eval
                window.React = React;
                window.ReactDOM = ReactDOM;
                window.motion = motion;
                window.AnimatePresence = AnimatePresence;
                window.LucideIcons = IconProxy;
                
                // Re-map common imports to global variables
                const mockRequire = (moduleName) => {
                  if (moduleName === 'react') return React;
                  if (moduleName === 'react-dom') return ReactDOM;
                  if (moduleName === 'lucide-react') return IconProxy;
                  if (moduleName === 'framer-motion' || moduleName === 'motion/react') return { motion, AnimatePresence };
                  if (moduleName === 'recharts') return window.Recharts;
                  if (moduleName === 'd3') return window.d3;
                  return {};
                };

                try {
                  const rawCode = ${JSON.stringify(code)};
                  
                  // 1. Transpile JSX/TS and convert ES Modules to CommonJS
                  const transpiled = Babel.transform(rawCode, {
                    presets: ['react', 'typescript', ['env', { modules: 'commonjs' }]],
                    filename: 'preview.tsx'
                  }).code;

                  // 2. Define the custom require function and execution environment
                  const finalCode = \`(function() {
                    const { useState, useEffect, useMemo, useCallback, useRef, useLayoutEffect } = React;
                    
                    const require = (moduleName) => {
                      if (moduleName === 'react') return React;
                      if (moduleName === 'react-dom') return ReactDOM;
                      if (moduleName === 'lucide-react') return window.LucideIcons;
                      if (moduleName === 'framer-motion' || moduleName === 'motion/react') {
                        return { motion: window.motion, AnimatePresence: window.AnimatePresence };
                      }
                      if (moduleName === 'recharts') return window.Recharts;
                      if (moduleName === 'd3') return window.d3;
                      return {};
                    };

                    const exports = {};
                    const module = { exports };
                    
                    \${transpiled}
                    
                    return module.exports.default || module.exports[Object.keys(module.exports)[0]] || module.exports;
                  })()\`;

                  const Component = eval(finalCode);
                  
                  if (!Component || typeof Component !== 'function') {
                    throw new Error('Could not find a valid React component to render. Ensure you have an "export default" component.');
                  }

                  const root = ReactDOM.createRoot(document.getElementById('root'));
                  root.render(<Component />);
                } catch (e) {
                  console.error('Preview Error:', e);
                  ReactDOM.createRoot(document.getElementById('root')).render(
                    <div style={{color: '#ff4444', padding: '24px', background: '#0A0A0B', borderRadius: '12px', border: '1px solid #331111', margin: '20px', fontFamily: 'monospace'}}>
                      <h3 style={{margin: '0 0 12px 0', fontSize: '16px', display: 'flex', alignItems: 'center', gap: '8px'}}>
                        <span style={{background: '#ff4444', color: 'white', padding: '2px 6px', borderRadius: '4px', fontSize: '10px'}}>ERROR</span>
                        Preview Execution Failed
                      </h3>
                      <pre style={{whiteSpace: 'pre-wrap', fontSize: '12px', background: '#1a1a1a', padding: '12px', borderRadius: '6px', border: '1px solid #333'}}>{e.message}</pre>
                      <div style={{marginTop: '16px', fontSize: '11px', color: '#666'}}>
                        Tip: Ensure your code has a valid <code>export default function App()</code> or similar.
                      </div>
                    </div>
                  );
                }
              </script>
            </body>
          </html>
        `;
      } else {
        html = code;
      }
      
      const blob = new Blob([html], { type: 'text/html' });
      url = URL.createObjectURL(blob);
      iframeRef.current.src = url;
    }

    return () => {
      if (url) URL.revokeObjectURL(url);
    };
  }, [code]);

  return (
    <iframe 
      ref={iframeRef}
      className="w-full h-full border-none bg-transparent"
      title="Live Preview"
    />
  );
};

const ProjectCreation = ({ onProjectCreated }: { onProjectCreated: (project: Project) => void }) => {
  const [name, setName] = useState('');
  const [color, setColor] = useState('#8b5cf6');
  const [isCreating, setIsCreating] = useState(false);

  const colors = [
    '#8b5cf6', // Purple
    '#06b6d4', // Cyan
    '#10b981', // Emerald
    '#f59e0b', // Amber
    '#ef4444', // Red
    '#ec4899', // Pink
  ];

  const handleCreate = async () => {
    if (!name.trim()) return;
    setIsCreating(true);
    const id = 'p' + Date.now();
    const newProject = { id, name: name.trim(), color, status: 'active' };
    
    try {
      const response = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newProject)
      });
      if (response.ok) {
        onProjectCreated(newProject);
      }
    } catch (error) {
      console.error("Failed to create project:", error);
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-6 bg-[#0A0A0B] text-zinc-100">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md space-y-8 text-center"
      >
        <div className="flex flex-col items-center gap-4">
          <div className="relative">
            <MimoCharacter size="lg" className="drop-shadow-2xl" />
            <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-emerald-500 border-4 border-[#0A0A0B] rounded-full animate-pulse" />
          </div>
          <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-br from-white to-zinc-500 bg-clip-text text-transparent">
            Welcome to Mimo
          </h1>
          <p className="text-zinc-500 text-lg">
            Let's start by creating your first project.
          </p>
        </div>

        <div className="space-y-6 bg-white/5 p-8 rounded-3xl border border-white/10 backdrop-blur-xl">
          <div className="space-y-2 text-left">
            <label className="text-xs font-bold uppercase tracking-widest text-zinc-500 ml-1">
              Project Name
            </label>
            <input 
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Neural Engine v2"
              className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white placeholder:text-zinc-700 focus:outline-none focus:ring-2 focus:ring-violet-500/50 transition-all"
              autoFocus
            />
          </div>

          <div className="space-y-3 text-left">
            <label className="text-xs font-bold uppercase tracking-widest text-zinc-500 ml-1">
              Theme Color
            </label>
            <div className="flex gap-3">
              {colors.map(c => (
                <button
                  key={c}
                  onClick={() => setColor(c)}
                  className={cn(
                    "w-8 h-8 rounded-full transition-all transform hover:scale-110",
                    color === c ? "ring-2 ring-white ring-offset-2 ring-offset-black scale-110" : "opacity-50"
                  )}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>

          <button
            onClick={handleCreate}
            disabled={!name.trim() || isCreating}
            className="w-full py-4 bg-violet-600 hover:bg-violet-500 disabled:opacity-50 disabled:hover:bg-violet-600 text-white font-bold rounded-xl shadow-lg shadow-violet-600/20 transition-all flex items-center justify-center gap-2"
          >
            {isCreating ? (
              <Activity className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                <span>Initialize Project</span>
              </>
            )}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default function App() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeProject, setActiveProject] = useState<Project | null>(null);
  const [isInitialPage, setIsInitialPage] = useState(true);
  const [isLoaded, setIsLoaded] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [generatedCode, setGeneratedCode] = useState<string | null>(null);
  const [deployStatus, setDeployStatus] = useState<{ status: string; message: string; url?: string } | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [systemStats, setSystemStats] = useState<SystemStats | null>(null);
  const [showStats, setShowStats] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showCodeModal, setShowCodeModal] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [isSplitView, setIsSplitView] = useState(false);
  const [wuuParticles, setWuuParticles] = useState<{ id: number; x: number; y: number }[]>([]);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [settingsProject, setSettingsProject] = useState<Project | null>(null);
  
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const mimeType = mediaRecorder.mimeType || 'audio/webm';
        const audioBlob = new Blob(audioChunksRef.current, { type: mimeType });
        setIsTranscribing(true);
        try {
          const response = await transcribeAudio(audioBlob);
          const text = response.result?.text || response.text;
          if (text) {
            setInput(prev => prev + (prev ? ' ' : '') + text);
          }
        } catch (error) {
          console.error("Transcription error:", error);
        } finally {
          setIsTranscribing(false);
        }
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (error) {
      console.error("Error starting recording:", error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
    }
  };

  const handleSpeak = async (text: string) => {
    if (isSpeaking) return;
    setIsSpeaking(true);
    try {
      // Clean text from markdown for better TTS
      const cleanText = text.replace(/\[.*?\]/g, '').replace(/```[\s\S]*?```/g, '').replace(/[*#_]/g, '');
      const audioUrl = await runCloudflareAi('@cf/myshell-ai/melotts', { text: cleanText });
      const audio = new Audio(audioUrl);
      audio.onended = () => setIsSpeaking(false);
      audio.play();
    } catch (error) {
      console.error("TTS error:", error);
      setIsSpeaking(false);
    }
  };

  const handleGenerateImage = async () => {
    if (!input.trim() || isLoading || !activeProject) return;
    const prompt = input;
    setInput('');
    setIsLoading(true);
    
    const userContent = `Generate an image: ${prompt}`;
    setMessages(prev => [...prev, { role: 'user', content: userContent }]);
    
    fetch('/api/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role: 'user', content: userContent, projectId: activeProject.id })
    }).catch(console.error);
    
    try {
      const imageUrl = await runCloudflareAi('@cf/black-forest-labs/flux-1-schnell', { prompt });
      const assistantContent = `[Wuu]: I've generated an image based on your prompt: "${prompt}"\n\n![Generated Image](${imageUrl})`;
      
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: assistantContent 
      }]);
      
      fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: 'assistant', content: assistantContent, projectId: activeProject.id })
      }).catch(console.error);
      
    } catch (error: any) {
      console.error("Image generation error:", error);
      const errorContent = `[Wuu]: I'm sorry, I couldn't generate that image. Error: ${error.message}`;
      setMessages(prev => [...prev, { role: 'assistant', content: errorContent }]);
      
      fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: 'assistant', content: errorContent, projectId: activeProject.id })
      }).catch(console.error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveProjectSettings = async (projectId: string, settings: ProjectSettings) => {
    try {
      const response = await fetch(`/api/projects/${projectId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings })
      });
      if (response.ok) {
        setProjects(prev => prev.map(p => p.id === projectId ? { ...p, settings } : p));
        if (activeProject?.id === projectId) {
          setActiveProject(prev => prev ? { ...prev, settings } : null);
        }
        setIsSettingsModalOpen(false);
      }
    } catch (error) {
      console.error("Error saving settings:", error);
    }
  };

  // Initial load of projects
  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const response = await fetch('/api/projects');
        if (response.ok) {
          const data = await response.json();
          setProjects(data);
          if (data.length > 0) {
            setActiveProject(data[0]);
            setIsInitialPage(false);
          }
        }
      } catch (error) {
        console.error("Failed to fetch projects:", error);
      } finally {
        setIsLoaded(true);
      }
    };
    fetchProjects();
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  // Load project-specific history
  useEffect(() => {
    if (!activeProject) return;
    const fetchHistory = async () => {
      try {
        const response = await fetch(`/api/history/${activeProject.id}`);
        if (response.ok) {
          const history = await response.json();
          setMessages(history.map((m: any) => ({ role: m.role, content: m.content, image: m.image })));
          
          // Try to extract the latest code from history
          const lastAssistantMsg = [...history].reverse().find(m => m.role === 'assistant');
          if (lastAssistantMsg) {
            const codeMatch = lastAssistantMsg.content.match(/```(?:tsx|html|css|javascript|js)?\n([\s\S]*?)```/);
            if (codeMatch) {
              setGeneratedCode(codeMatch[1]);
            } else {
              setGeneratedCode(null);
            }
          } else {
            setGeneratedCode(null);
          }
        }
      } catch (error) {
        console.error("Failed to fetch history:", error);
      }
    };
    fetchHistory();
  }, [activeProject?.id]);

  // Fetch system stats periodically
  useEffect(() => {
    let isMounted = true;
    
    const fetchStats = async () => {
      try {
        const res = await fetch('/api/system/health');
        if (!res.ok) throw new Error();
        const data = await res.json();
        if (isMounted) setSystemStats(data);
      } catch (e) {
        // Silent fail for stats to avoid annoying console errors during startup
      }
    };
    
    // Initial delay to allow server to start
    const timeout = setTimeout(() => {
      fetchStats();
    }, 1000);
    const interval = setInterval(fetchStats, 10000);
    
    return () => {
      isMounted = false;
      clearTimeout(timeout);
      clearInterval(interval);
    };
  }, []);

  // Extract latest code block from messages
  useEffect(() => {
    const lastMessage = messages[messages.length - 1];
    if (lastMessage?.role === 'assistant') {
      const codeMatch = lastMessage.content.match(/```(?:javascript|typescript|js|ts|jsx|tsx|html)?\n([\s\S]*?)```/);
      if (codeMatch) {
        const newCode = codeMatch[1];
        if (newCode !== generatedCode) {
          setGeneratedCode(newCode);
          setShowPreviewModal(true);
        }
      }
    }
  }, [messages]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSend = async () => {
    if ((!input.trim() && !selectedImage) || isLoading) return;

    const userMessage: Message = { 
      role: 'user', 
      content: input,
      image: selectedImage || undefined
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    const currentImage = selectedImage;
    setSelectedImage(null);
    setIsLoading(true);
    setDeployStatus(null);

    // Save user message to DB
    fetch('/api/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role: 'user', content: input, projectId: activeProject.id, image: currentImage })
    }).catch(console.error);

    // Trigger Wuu Particles
    const newParticles = Array.from({ length: 10 }).map((_, i) => ({
      id: Date.now() + i,
      x: Math.random() * 100 - 50,
      y: Math.random() * 100 - 50
    }));
    setWuuParticles(newParticles);
    setTimeout(() => setWuuParticles([]), 1000);

    try {
      setMessages(prev => [...prev, { role: 'assistant', content: '' }]);
      
      const projectContext = `[Project: ${activeProject.name}] ${input}`;
      
      // Ensure we send the current message + history
      const response = await generateMimoResponse(
        projectContext,
        messages.map(m => ({ role: m.role, content: m.content })),
        generatedCode || undefined,
        currentImage || undefined,
        (chunk) => {
          setMessages(prev => {
            const newMessages = [...prev];
            if (newMessages.length > 0) {
              newMessages[newMessages.length - 1].content = chunk;
            }
            return newMessages;
          });
        },
        activeProject.settings
      );

      // Save assistant message to DB
      if (response) {
        fetch('/api/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ role: 'assistant', content: response, projectId: activeProject.id })
        }).catch(console.error);
      }
    } catch (error: any) {
      console.error("Chat Error:", error);
      setMessages(prev => {
        const newMessages = [...prev];
        const errorMessage = error.message || 'Unknown error';
        newMessages[newMessages.length - 1].content = `I encountered an error connecting to my brain. 
        
Error Details: ${errorMessage}

This might be due to a transient network issue or token limits. Try clearing the chat or refreshing.`;
        return newMessages;
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeploy = async () => {
    if (!generatedCode || !activeProject) return;
    setDeployStatus({ status: 'starting', message: 'Contacting BuildOrchestratorDO...' });

    try {
      const response = await fetch('/api/deploy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          code: generatedCode,
          projectName: activeProject.name.toLowerCase().replace(/\s+/g, '-')
        }),
      });

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader!.read();
        if (done) break;

        const chunk = decoder.decode(value);
        const lines = chunk.split('\n');
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') break;
            try {
              const statusUpdate = JSON.parse(data);
              setDeployStatus(statusUpdate);
            } catch (e) {
              // Ignore
            }
          }
        }
      }
    } catch (error: any) {
      setDeployStatus({ status: 'error', message: error.message });
    }
  };

  const clearHistory = async () => {
    if (!activeProject) return;
    await fetch('/api/admin/clear', { 
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId: activeProject.id })
    });
    setMessages([]);
    setGeneratedCode(null);
    setDeployStatus(null);
  };

  const handleProjectCreated = (newProject: Project) => {
    setProjects(prev => [newProject, ...prev]);
    setActiveProject(newProject);
    setIsInitialPage(false);
  };

  if (!isLoaded) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#0A0A0B]">
        <Activity className="w-8 h-8 text-violet-500 animate-spin" />
      </div>
    );
  }

  if (isInitialPage) {
    return <ProjectCreation onProjectCreated={handleProjectCreated} />;
  }

  if (!activeProject) return null;

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-zinc-100 font-sans selection:bg-violet-500/30">
      {/* Background Glows & Grid */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]" />
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-violet-900/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-900/10 blur-[120px] rounded-full" />
        <div className="absolute top-[20%] right-[10%] w-[30%] h-[30%] bg-cyan-900/5 blur-[100px] rounded-full" />
      </div>

      <div className="relative flex h-screen max-w-[100vw] mx-auto border-x border-white/5 bg-black/20 backdrop-blur-3xl overflow-hidden">
        
        {/* Mobile Sidebar Overlay */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 md:hidden"
            />
          )}
        </AnimatePresence>

        {/* Code Modal */}
        <AnimatePresence>
          {showCodeModal && generatedCode && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
            >
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                className="w-full max-w-4xl max-h-[80vh] bg-[#0A0A0B] border border-white/10 rounded-2xl overflow-hidden flex flex-col shadow-2xl"
              >
                <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 bg-white/5">
                  <div className="flex items-center gap-2 text-zinc-300">
                    <CodeIcon className="w-4 h-4" />
                    <span className="text-sm font-medium">Generated Code</span>
                  </div>
                  <button 
                    onClick={() => setShowCodeModal(false)}
                    className="p-1.5 rounded-lg hover:bg-white/10 text-zinc-400 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <div className="flex-1 overflow-hidden bg-[#1e1e1e]">
                  <Editor
                    height="100%"
                    defaultLanguage="typescript"
                    theme="vs-dark"
                    value={generatedCode}
                    onChange={(value) => setGeneratedCode(value || '')}
                    options={{
                      minimap: { enabled: false },
                      fontSize: 14,
                      wordWrap: 'on',
                      scrollBeyondLastLine: false,
                      padding: { top: 16, bottom: 16 },
                    }}
                  />
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

          {/* Preview Modal */}
          <AnimatePresence>
            {showPreviewModal && generatedCode && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
              >
                <motion.div
                  initial={{ scale: 0.95, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.95, opacity: 0 }}
                  className="w-full max-w-5xl h-[85vh] bg-[#0A0A0B] border border-white/10 rounded-2xl overflow-hidden flex flex-col shadow-2xl"
                >
                  <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 bg-white/5">
                    <div className="flex items-center gap-2 text-zinc-300">
                      <Eye className="w-4 h-4" />
                      <span className="text-sm font-medium">Live Preview</span>
                    </div>
                    <button 
                      onClick={() => setShowPreviewModal(false)}
                      className="p-1.5 rounded-lg hover:bg-white/10 text-zinc-400 transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="flex-1 bg-white overflow-hidden">
                    <LivePreview code={generatedCode} />
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Settings Modal */}
          <AnimatePresence>
            {isSettingsModalOpen && settingsProject && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
              >
                <motion.div
                  initial={{ scale: 0.95, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.95, opacity: 0 }}
                  className="w-full max-w-md bg-[#0A0A0B] border border-white/10 rounded-2xl overflow-hidden flex flex-col shadow-2xl"
                >
                  <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 bg-white/5">
                    <div className="flex items-center gap-2 text-zinc-300">
                      <Settings className="w-4 h-4" />
                      <span className="text-sm font-medium">Project Settings</span>
                    </div>
                    <button 
                      onClick={() => setIsSettingsModalOpen(false)}
                      className="p-1.5 rounded-lg hover:bg-white/10 text-zinc-400 transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="p-6 space-y-6 bg-[#050505]">
                    <div className="space-y-4">
                      <div>
                        <label className="block text-xs font-medium text-zinc-400 mb-1.5">Default Agent</label>
                        <select 
                          className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-zinc-300 focus:outline-none focus:border-violet-500/50"
                          value={settingsProject.settings?.defaultAgent || 'mimo'}
                          onChange={(e) => setSettingsProject({...settingsProject, settings: {...settingsProject.settings, defaultAgent: e.target.value}})}
                        >
                          <option value="mimo">Mimo (Orchestrator)</option>
                          <option value="nova">Nova (UI/UX)</option>
                          <option value="atlas">Atlas (Backend)</option>
                          <option value="forge">Forge (DevOps)</option>
                          <option value="wuu">Wuu (Cloudflare AI)</option>
                        </select>
                      </div>
                      
                      <div>
                        <label className="block text-xs font-medium text-zinc-400 mb-1.5">Kimi Model</label>
                        <select 
                          className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-zinc-300 focus:outline-none focus:border-violet-500/50"
                          value={settingsProject.settings?.modelPreference || 'kimi-k2.5'}
                          onChange={(e) => setSettingsProject({...settingsProject, settings: {...settingsProject.settings, modelPreference: e.target.value}})}
                        >
                          <optgroup label="Kimi K2 Series (Latest)">
                            <option value="kimi-k2.5">Kimi K2.5 (Multimodal SOTA)</option>
                            <option value="kimi-k2-thinking">Kimi K2 Thinking (Reasoning)</option>
                            <option value="kimi-k2">Kimi K2 (Code Generation)</option>
                          </optgroup>
                          <optgroup label="Kimi v1 Series (Legacy)">
                            <option value="moonshot-v1-128k">Kimi 128K (Long Context)</option>
                            <option value="moonshot-v1-32k">Kimi 32K (Balanced)</option>
                            <option value="moonshot-v1-8k">Kimi 8K (Fast)</option>
                          </optgroup>
                          <optgroup label="Cloudflare AI Sub-Agents">
                            <option value="@cf/meta/llama-3.2-3b-instruct">Fast (Llama 3.2 3B)</option>
                            <option value="@cf/meta/llama-3.1-8b-instruct">Balanced (Llama 3.1 8B)</option>
                            <option value="@cf/deepseek-ai/deepseek-r1-distill-qwen-32b">Reasoning (DeepSeek R1)</option>
                            <option value="@cf/qwen/qwen2.5-coder-32b-instruct">Coding (Qwen 2.5 Coder)</option>
                            <option value="@cf/meta/llama-3.3-70b-instruct-awq">Powerful (Llama 3.3 70B)</option>
                          </optgroup>
                        </select>
                        <p className="text-[10px] text-zinc-500 mt-1">
                          Leave on K2.5 for smart auto-routing based on task complexity
                        </p>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-zinc-400 mb-1.5">Display Theme</label>
                        <select 
                          className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-zinc-300 focus:outline-none focus:border-violet-500/50"
                          value={settingsProject.settings?.displayTheme || 'dark'}
                          onChange={(e) => setSettingsProject({...settingsProject, settings: {...settingsProject.settings, displayTheme: e.target.value as any}})}
                        >
                          <option value="dark">Dark Mode</option>
                          <option value="light">Light Mode</option>
                          <option value="system">System Default</option>
                        </select>
                      </div>

                      <div className="flex items-center justify-between pt-2">
                        <label className="text-xs font-medium text-zinc-400">Enable Voice Input</label>
                        <button
                          onClick={() => setSettingsProject({...settingsProject, settings: {...settingsProject.settings, enableVoice: !(settingsProject.settings?.enableVoice ?? true)}})}
                          className={cn(
                            "w-10 h-5 rounded-full transition-colors relative",
                            (settingsProject.settings?.enableVoice ?? true) ? "bg-violet-500" : "bg-white/10"
                          )}
                        >
                          <motion.div 
                            className="w-3 h-3 bg-white rounded-full absolute top-1"
                            animate={{ left: (settingsProject.settings?.enableVoice ?? true) ? 24 : 4 }}
                          />
                        </button>
                      </div>
                    </div>

                    <div className="pt-4 border-t border-white/10 flex justify-end gap-3">
                      <button 
                        onClick={() => setIsSettingsModalOpen(false)}
                        className="px-4 py-2 text-xs font-medium text-zinc-400 hover:text-white transition-colors"
                      >
                        Cancel
                      </button>
                      <button 
                        onClick={() => saveProjectSettings(settingsProject.id, settingsProject.settings || {})}
                        className="px-4 py-2 text-xs font-medium bg-violet-500 hover:bg-violet-600 text-white rounded-lg transition-colors"
                      >
                        Save Settings
                      </button>
                    </div>
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>

        {/* Left Sidebar: System Stats & Projects */}
        <motion.div 
          animate={{ 
            width: showStats ? 280 : 0,
            x: isMobileMenuOpen ? 0 : (showStats ? 0 : -280)
          }}
          className={cn(
            "h-full bg-black/90 md:bg-black/40 border-r border-white/5 overflow-hidden flex flex-col z-50",
            "fixed md:relative left-0 top-0 bottom-0",
            !showStats && !isMobileMenuOpen && "hidden md:flex"
          )}
        >
          <div className="p-6 space-y-8 min-w-[280px] overflow-y-auto flex-1 custom-scrollbar">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-violet-400">
                <Layout className="w-5 h-5" />
                <h2 className="text-xs font-bold uppercase tracking-widest">Workspace</h2>
              </div>
              <button 
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  setShowStats(false);
                }}
                className="md:hidden p-2 text-zinc-500 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Project Switcher */}
            <div className="space-y-3">
              <div className="text-[10px] text-zinc-500 uppercase font-mono tracking-widest flex items-center justify-between">
                <span>Active Projects</span>
                <button 
                  onClick={() => setIsInitialPage(true)}
                  className="p-1 hover:bg-white/10 rounded-md transition-colors text-zinc-400 hover:text-white"
                  title="New Project"
                >
                  <Sparkles className="w-3 h-3" />
                </button>
              </div>
              <div className="space-y-1">
                {projects.map((project) => (
                  <div
                    key={project.id}
                    className={cn(
                      "w-full flex items-center gap-3 p-2.5 rounded-xl transition-all group border cursor-pointer",
                      activeProject?.id === project.id 
                        ? "bg-violet-500/10 border-violet-500/20 text-violet-300" 
                        : "hover:bg-white/5 border-transparent text-zinc-500 hover:text-zinc-300"
                    )}
                    onClick={() => setActiveProject(project)}
                  >
                    <div 
                      className="w-2 h-2 rounded-full shadow-[0_0_8px_rgba(0,0,0,0.5)]" 
                      style={{ backgroundColor: project.color, boxShadow: activeProject?.id === project.id ? `0 0 12px ${project.color}` : '' }} 
                    />
                    <div className="flex-1 text-left">
                      <div className="text-xs font-medium">{project.name}</div>
                      <div className="text-[9px] opacity-50 font-mono uppercase">{project.status}</div>
                    </div>
                    {activeProject?.id === project.id && (
                      <div className="flex items-center gap-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSettingsProject(project);
                            setIsSettingsModalOpen(true);
                          }}
                          className="p-1 text-zinc-400 hover:text-white hover:bg-white/10 rounded-md transition-colors"
                        >
                          <Settings className="w-3.5 h-3.5" />
                        </button>
                        <motion.div layoutId="active-pill" className="w-1 h-4 bg-violet-500 rounded-full" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-6 border-t border-white/5 space-y-4">
              <div className="flex items-center gap-2 text-orange-400">
                <Cloud className="w-4 h-4" />
                <h2 className="text-[10px] font-bold uppercase tracking-widest">Cloudflare AI Integrations</h2>
              </div>
              <div className="grid grid-cols-1 gap-2">
                {[
                  { name: 'Llama 3.3 70B', desc: 'High-Reasoning LLM', icon: <Cpu className="w-3 h-3" /> },
                  { name: 'DeepSeek R1', desc: 'Advanced Reasoning', icon: <Activity className="w-3 h-3" /> },
                  { name: 'Qwen 2.5 Coder', desc: 'Code Generation', icon: <CodeIcon className="w-3 h-3" /> },
                  { name: 'QWQ 32B', desc: 'Logic & Problem Solving', icon: <Cpu className="w-3 h-3" /> },
                  { name: 'Qwen 3 30B', desc: 'General Fallback', icon: <Cpu className="w-3 h-3" /> },
                  { name: 'GPT-OSS 120B', desc: 'Massive Scale Logic', icon: <Activity className="w-3 h-3" /> },
                  { name: 'Leonardo Phoenix', desc: 'Photorealistic Assets', icon: <ImageIcon className="w-3 h-3" /> },
                  { name: 'Leonardo Lucid', desc: 'Creative Image Gen', icon: <ImageIcon className="w-3 h-3" /> },
                  { name: 'Flux.1 Schnell', desc: 'Fast Image Gen', icon: <ImageIcon className="w-3 h-3" /> },
                  { name: 'Whisper', desc: 'Audio Transcription', icon: <Activity className="w-3 h-3" /> }
                ].map((item) => (
                  <div key={item.name} className="p-2.5 rounded-xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors cursor-default group">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="text-orange-400/50 group-hover:text-orange-400 transition-colors">
                        {item.icon}
                      </div>
                      <div className="text-[10px] font-bold text-zinc-300">{item.name}</div>
                    </div>
                    <div className="text-[9px] text-zinc-500 font-mono leading-tight">{item.desc}</div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="pt-6 border-t border-white/5">
              <div className="flex items-center gap-2 text-emerald-400 mb-4">
                <Activity className="w-4 h-4" />
                <h2 className="text-[10px] font-bold uppercase tracking-widest">Live Metrics</h2>
              </div>
              {systemStats && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                      <div className="text-[9px] text-zinc-500 uppercase font-mono mb-1">REQ/S</div>
                      <div className="text-lg font-light font-mono text-emerald-400">{systemStats.requests_per_sec}</div>
                    </div>
                    <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                      <div className="text-[9px] text-zinc-500 uppercase font-mono mb-1">LATENCY</div>
                      <div className="text-lg font-light font-mono text-violet-400">{systemStats.latency_ms}ms</div>
                    </div>
                  </div>
                  
                  <div className="space-y-3 pt-2">
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-zinc-500 flex items-center gap-2"><Globe className="w-3 h-3" /> Locations</span>
                      <span className="text-zinc-300">310+</span>
                    </div>
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-zinc-500 flex items-center gap-2"><Cpu className="w-3 h-3" /> Workers</span>
                      <span className="text-zinc-300">{systemStats.active_workers}</span>
                    </div>
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-zinc-500 flex items-center gap-2"><Database className="w-3 h-3" /> D1 Storage</span>
                      <span className="text-zinc-300">{systemStats.d1_storage_used}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="pt-6 border-t border-white/5 space-y-4">
              <div className="flex items-center gap-2 text-cyan-400">
                <Zap className="w-4 h-4" />
                <h2 className="text-[10px] font-bold uppercase tracking-widest">Agent Tech</h2>
              </div>
              <div className="grid grid-cols-1 gap-2">
                {[
                  { name: 'Mooncake', desc: 'KVCache Disaggregated' },
                  { name: 'MoBA', desc: 'Mixture of Block Attention' },
                  { name: 'Muon', desc: 'Scalable LLM Training' },
                  { name: 'Kimi k1.5', desc: 'RL Scaling' }
                ].map((item) => (
                  <div key={item.name} className="p-2.5 rounded-xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors cursor-default">
                    <div className="text-[10px] font-bold text-zinc-300">{item.name}</div>
                    <div className="text-[9px] text-zinc-500 font-mono leading-tight">{item.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Main Chat Panel */}
        <div className="flex flex-col h-full flex-1 max-w-5xl mx-auto border-x border-white/5 bg-black/20 relative w-full">
          {/* Header */}
          <header className="flex items-center justify-between px-4 md:px-6 py-3 md:py-4 border-b border-white/5 bg-black/20">
            <div className="flex items-center gap-2 md:gap-3">
              <button 
                onClick={() => {
                  setShowStats(!showStats);
                  setIsMobileMenuOpen(!isMobileMenuOpen);
                }}
                className={cn(
                  "p-2 rounded-lg transition-colors",
                  (showStats || isMobileMenuOpen) ? "bg-violet-600/20 text-violet-400" : "hover:bg-white/5 text-zinc-500"
                )}
              >
                <Menu className="w-5 h-5 md:hidden" />
                <Activity className="w-5 h-5 hidden md:block" />
              </button>
              <div className="relative hidden sm:block">
                <MimoCharacter size="sm" className="drop-shadow-lg" isLoading={isLoading} />
                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-[#0A0A0B] rounded-full" />
              </div>
              <div>
                <h1 className="text-base md:text-lg font-semibold tracking-tight">Mimo</h1>
                <div className="flex items-center gap-2">
                  <p className="text-[10px] md:text-xs text-zinc-500 font-mono uppercase tracking-widest hidden sm:block">HMM Platform Orchestrator</p>
                  <span className="px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-400 text-[8px] font-bold uppercase tracking-tighter border border-cyan-500/20">Kimi K2.5</span>
                  <span className="px-1.5 py-0.5 rounded bg-violet-500/10 text-violet-400 text-[8px] font-bold uppercase tracking-tighter border border-violet-500/20">{activeProject.name}</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2 md:gap-4">
              <button 
                onClick={clearHistory}
                className="p-2 rounded-lg hover:bg-red-500/10 text-zinc-500 hover:text-red-400 transition-all group"
                title="Clear Workspace"
              >
                <Trash2 className="w-4 h-4 group-hover:scale-110 transition-transform" />
              </button>
              {generatedCode && (
                <>
                  <button
                    onClick={() => setShowCodeModal(true)}
                    className="flex items-center gap-1.5 md:gap-2 px-3 md:px-4 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white text-[10px] md:text-xs font-medium transition-all border border-white/10"
                  >
                    <Database className="w-3 h-3 md:w-4 md:h-4" />
                    <span>Files</span>
                  </button>
                  <button
                    onClick={() => setShowPreviewModal(true)}
                    className="flex items-center gap-1.5 md:gap-2 px-3 md:px-4 py-1.5 rounded-lg bg-violet-600/20 hover:bg-violet-600/30 text-violet-400 text-[10px] md:text-xs font-medium transition-all border border-violet-500/20"
                  >
                    <Eye className="w-3 h-3 md:w-4 md:h-4" />
                    <span>Preview</span>
                  </button>
                  <button
                    onClick={handleDeploy}
                    disabled={deployStatus?.status === 'deploying' || deployStatus?.status === 'building'}
                    className="hidden sm:flex items-center gap-1.5 md:gap-2 px-3 md:px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-[10px] md:text-xs font-medium transition-all shadow-lg shadow-emerald-500/20"
                  >
                    <Cloud className="w-3 h-3 md:w-4 md:h-4" />
                    <span>Deploy</span>
                  </button>
                </>
              )}
              <button 
                onClick={clearHistory}
                className="p-2 rounded-lg hover:bg-white/5 text-zinc-500 transition-colors"
                title="Clear History"
              >
                <Trash2 className="w-4 h-4 md:w-5 md:h-5" />
              </button>
            </div>
          </header>

          {/* Chat Area & Split View */}
          <div className={cn(
            "flex-1 flex min-h-0 relative overflow-hidden",
            isSplitView ? "flex-row" : "flex-col"
          )}>
            {/* Chat Column */}
            <div className={cn(
              "flex flex-col h-full min-w-0 transition-all duration-300 relative",
              isSplitView ? "w-1/2 border-r border-white/10" : "w-full"
            )}>
              {/* Deployment Status Banner */}
              <AnimatePresence>
                {deployStatus && (
                  <motion.div
                    initial={{ y: -50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    exit={{ y: -50, opacity: 0 }}
                    className={cn(
                      "absolute top-0 left-0 right-0 z-20 p-3 flex items-center justify-between border-b backdrop-blur-md",
                      deployStatus.status === 'success' ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" :
                      deployStatus.status === 'error' ? "bg-red-500/10 border-red-500/20 text-red-400" :
                      "bg-violet-500/10 border-violet-500/20 text-violet-400"
                    )}
                  >
                    <div className="flex items-center gap-3">
                      {deployStatus.status === 'success' ? <CheckCircle2 className="w-4 h-4" /> :
                       deployStatus.status === 'error' ? <AlertCircle className="w-4 h-4" /> :
                       <Loader2 className="w-4 h-4 animate-spin" />}
                      <div className="flex flex-col">
                        <span className="text-[10px] font-bold uppercase tracking-widest">{deployStatus.status}</span>
                        <span className="text-xs opacity-80">{deployStatus.message}</span>
                      </div>
                    </div>
                    {deployStatus.url && (
                      <a 
                        href={deployStatus.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="px-3 py-1 rounded-lg bg-emerald-500 text-white text-[10px] font-bold uppercase tracking-widest hover:bg-emerald-400 transition-colors"
                      >
                        Open App
                      </a>
                    )}
                    <button onClick={() => setDeployStatus(null)} className="p-1 hover:bg-white/10 rounded-md transition-colors">
                      <X className="w-4 h-4" />
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>

              <div 
                ref={scrollRef}
                className="flex-1 overflow-y-auto px-4 py-4 md:px-6 md:py-8 space-y-6 md:space-y-8 scrollbar-thin scrollbar-thumb-white/10"
              >
            {messages.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-4 md:space-y-6 px-4">
                <MimoCharacter size="lg" className="mb-2 md:mb-4 scale-75 md:scale-100" />
                <div className="space-y-2">
                  <h2 className="text-xl md:text-2xl font-medium text-white">Greetings, I am Mimo.</h2>
                  <p className="text-sm md:text-base text-zinc-400 max-w-md mx-auto">
                    Your autonomous orchestrator for the Human-Machine Matrix, now powered by **Kimi K2.5**. 
                    Ready to build, deploy, and manage your Cloudflare-native ecosystem with Visual Agentic Intelligence.
                  </p>
                </div>
              </div>
            )}

            <AnimatePresence initial={false}>
              {messages.flatMap((msg, i) => {
                if (msg.role === 'user') {
                  return [
                    <motion.div
                      key={`user-${i}`}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex gap-2 md:gap-4 max-w-[95%] md:max-w-[90%] ml-auto flex-row-reverse"
                    >
                      <div className="shrink-0">
                        <div className="w-6 h-6 md:w-8 md:h-8 rounded-lg bg-zinc-800 flex items-center justify-center">
                          <User className="w-3 h-3 md:w-5 md:h-5" />
                        </div>
                      </div>
                      <div className="space-y-2 max-w-full overflow-hidden">
                        {msg.image && (
                          <div className="rounded-2xl overflow-hidden border border-white/10 max-w-sm">
                            <img src={msg.image} alt="User upload" className="w-full h-auto" referrerPolicy="no-referrer" />
                          </div>
                        )}
                        <div className="px-3 py-2.5 md:px-4 md:py-3 rounded-2xl text-sm leading-relaxed bg-violet-600 text-white rounded-tr-none">
                          <div className="prose prose-invert prose-sm max-w-none">
                            <ReactMarkdown
                              components={{
                                code({node, inline, className, children, ...props}: any) {
                                  const match = /language-(\w+)/.exec(className || '')
                                  return !inline ? (
                                    <div className="relative bg-[#0A0A0B] rounded-xl border border-white/10 overflow-hidden my-4">
                                      <div className="flex items-center justify-between px-3 py-1.5 md:px-4 md:py-2 bg-white/5 border-b border-white/10">
                                        <span className="text-[10px] md:text-xs font-mono text-zinc-400">{match?.[1] || 'code'}</span>
                                      </div>
                                      <div className="p-3 md:p-4 overflow-x-auto">
                                        <code className={cn("text-[10px] md:text-xs font-mono text-zinc-300", className)} {...props}>
                                          {children}
                                        </code>
                                      </div>
                                    </div>
                                  ) : (
                                    <code className="bg-white/10 text-violet-300 px-1.5 py-0.5 rounded-md text-sm font-mono" {...props}>
                                      {children}
                                    </code>
                                  )
                                }
                              }}
                            >
                              {msg.content}
                            </ReactMarkdown>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ];
                } else {
                  const parts = parseAgentMessages(msg.content);
                  const validParts = parts.filter(part => part.text.trim().length > 0);
                  return validParts.map((part, partIndex) => {
                    const isTyping = isLoading && i === messages.length - 1 && partIndex === validParts.length - 1;
                    return (
                    <motion.div
                      key={`assistant-${i}-${partIndex}`}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex gap-2 md:gap-4 max-w-[95%] md:max-w-[90%] mr-auto"
                    >
                      <div className="shrink-0">
                        <div className="scale-75 origin-top md:scale-100 flex flex-col items-center gap-1">
                          <MimoCharacter 
                            size="sm" 
                            className={cn(
                              part.agent === 'Nova' && "agent-nova",
                              part.agent === 'Atlas' && "agent-atlas",
                              part.agent === 'Forge' && "agent-forge",
                              part.agent === 'Wuu' && "agent-wuu",
                              isTyping && "animate-pulse"
                            )}
                          />
                          {part.agent === 'Nova' && (
                            <div className="flex flex-col items-center">
                              <span className="text-[8px] font-mono text-pink-400 uppercase tracking-widest">Nova</span>
                              <span className="text-[6px] font-mono text-pink-500/50 uppercase">Kimi-VL</span>
                            </div>
                          )}
                          {part.agent === 'Atlas' && (
                            <div className="flex flex-col items-center">
                              <span className="text-[8px] font-mono text-blue-400 uppercase tracking-widest">Atlas</span>
                              <span className="text-[6px] font-mono text-blue-500/50 uppercase">Kimi-Researcher</span>
                            </div>
                          )}
                          {part.agent === 'Forge' && (
                            <div className="flex flex-col items-center">
                              <span className="text-[8px] font-mono text-orange-400 uppercase tracking-widest">Forge</span>
                              <span className="text-[6px] font-mono text-orange-500/50 uppercase">Kimi-Dev</span>
                            </div>
                          )}
                          {part.agent === 'Wuu' && (
                            <div className="flex flex-col items-center">
                              <span className="text-[8px] font-mono text-orange-400 uppercase tracking-widest">Wuu</span>
                              <span className="text-[6px] font-mono text-orange-500/50 uppercase">Cloudflare AI</span>
                            </div>
                          )}
                          {part.agent === 'Mimo' && (
                            <div className="flex flex-col items-center">
                              <span className="text-[8px] font-mono text-cyan-400 uppercase tracking-widest">Mimo</span>
                              <span className="text-[6px] font-mono text-cyan-500/50 uppercase">Kimi K2.5</span>
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="space-y-2 max-w-full overflow-hidden">
                        <div className="px-3 py-2.5 md:px-4 md:py-3 rounded-2xl text-sm leading-relaxed bg-white/5 border border-white/10 text-zinc-200 rounded-tl-none w-full relative group">
                          {part.text.includes('```') && (
                            <div className="absolute -top-2 -right-2 px-2 py-0.5 bg-cyan-600 text-[8px] font-bold uppercase tracking-widest rounded-full border border-cyan-400 shadow-lg shadow-cyan-500/20 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
                              Preview Ready
                            </div>
                          )}
                          <div className="prose prose-invert prose-sm max-w-none">
                            <ReactMarkdown
                              components={{
                                code({node, inline, className, children, ...props}: any) {
                                  const match = /language-(\w+)/.exec(className || '')
                                  return !inline ? (
                                    <div className="relative bg-[#0A0A0B] rounded-xl border border-white/10 overflow-hidden my-4">
                                      <div className="flex items-center justify-between px-3 py-1.5 md:px-4 md:py-2 bg-white/5 border-b border-white/10">
                                        <span className="text-[10px] md:text-xs font-mono text-zinc-400">{match?.[1] || 'code'}</span>
                                      </div>
                                      <div className="p-3 md:p-4 overflow-x-auto">
                                        <code className={cn("text-[10px] md:text-xs font-mono text-zinc-300", className)} {...props}>
                                          {children}
                                        </code>
                                      </div>
                                    </div>
                                  ) : (
                                    <code className="bg-white/10 text-violet-300 px-1.5 py-0.5 rounded-md text-sm font-mono" {...props}>
                                      {children}
                                    </code>
                                  )
                                }
                              }}
                            >
                              {part.text + (isTyping ? ' ▍' : '')}
                            </ReactMarkdown>
                          </div>
                          {!isTyping && (
                            <div className="flex justify-end mt-2">
                              <button 
                                onClick={() => handleSpeak(part.text)}
                                disabled={isSpeaking}
                                className="p-1.5 rounded-md bg-white/5 hover:bg-white/10 text-zinc-500 hover:text-cyan-400 transition-all disabled:opacity-50"
                                title="Speak Message"
                              >
                                <Volume2 className={cn("w-3.5 h-3.5", isSpeaking && "animate-pulse text-cyan-400")} />
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  )});
                }
              })}
            </AnimatePresence>
            {isLoading && messages[messages.length - 1]?.content === '' && (
              <div className="flex gap-2 md:gap-4 mr-auto">
                <div className="scale-75 origin-top md:scale-100">
                  <MimoCharacter size="sm" className="animate-pulse" />
                </div>
                <div className="flex items-center gap-1 px-3 py-2.5 md:px-4 md:py-3 rounded-2xl bg-white/5 border border-white/10">
                  <div className="w-1.5 h-1.5 bg-violet-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-1.5 h-1.5 bg-violet-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-1.5 h-1.5 bg-violet-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            )}
              </div>
            </div>

            {/* Split View Preview Column */}
            {isSplitView && (
              <div className="hidden lg:flex flex-col flex-1 h-full bg-white overflow-hidden border-l border-white/10">
                <div className="flex items-center justify-between px-4 py-2 bg-zinc-100 border-b border-zinc-200">
                  <div className="flex items-center gap-2 text-zinc-600">
                    <Eye className="w-3.5 h-3.5" />
                    <span className="text-[10px] font-bold uppercase tracking-wider">Live Edge Preview</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-[10px] text-zinc-500 font-mono">STABLE</span>
                  </div>
                </div>
                <div className="flex-1">
                  <LivePreview code={generatedCode || ''} />
                </div>
              </div>
            )}
          </div>

          {/* Input Area */}
          <div className="p-4 md:p-6 border-t border-white/5 bg-black/20 pb-[calc(1rem+env(safe-area-inset-bottom))]">
            {selectedImage && (
              <div className="mb-4 relative inline-block">
                <img src={selectedImage} alt="Preview" className="w-16 h-16 md:w-20 md:h-20 object-cover rounded-xl border border-white/20" referrerPolicy="no-referrer" />
                <button 
                  onClick={() => setSelectedImage(null)}
                  className="absolute -top-2 -right-2 p-1 bg-zinc-800 rounded-full border border-white/10 text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            )}
            <div className="relative max-w-3xl mx-auto flex items-end gap-2">
              <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                accept="image/*" 
                onChange={handleImageUpload} 
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="p-3 md:p-3.5 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 transition-colors border border-white/10 shrink-0"
                title="Upload Image"
              >
                <ImageIcon className="w-5 h-5 md:w-5 md:h-5" />
              </button>
              <button
                onClick={handleGenerateImage}
                disabled={!input.trim() || isLoading}
                className="p-3 md:p-3.5 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-cyan-400 transition-colors border border-white/10 shrink-0 disabled:opacity-50"
                title="Generate Image with Wuu"
              >
                <Wand2 className="w-5 h-5 md:w-5 md:h-5" />
              </button>
              <button
                onClick={isRecording ? stopRecording : startRecording}
                className={cn(
                  "p-3 md:p-3.5 rounded-xl transition-all border shrink-0",
                  isRecording 
                    ? "bg-red-500/20 border-red-500/50 text-red-500 animate-pulse" 
                    : "bg-white/5 border-white/10 text-zinc-400 hover:bg-white/10 hover:text-violet-400"
                )}
                title={isRecording ? "Stop Recording" : "Voice Input"}
              >
                <Mic className="w-5 h-5 md:w-5 md:h-5" />
              </button>
              <div className="relative flex-1">
                {isTranscribing && (
                  <div className="absolute -top-8 left-0 flex items-center gap-2 text-[10px] text-violet-400 font-mono animate-pulse">
                    <Ear className="w-3 h-3" />
                    <span>Transcribing Audio...</span>
                  </div>
                )}
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                  placeholder="Ask Mimo to build something..."
                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-3.5 md:py-4 pr-12 md:pr-14 text-base md:text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50 transition-all resize-none h-[52px] md:h-14 max-h-32 scrollbar-none"
                />
                <button
                  onClick={handleSend}
                  disabled={(!input.trim() && !selectedImage) || isLoading}
                  className="absolute right-1.5 top-1.5 md:right-2 md:top-2 p-2 md:p-2 rounded-xl bg-violet-600 hover:bg-violet-500 disabled:opacity-50 disabled:hover:bg-violet-600 text-white transition-all shadow-lg shadow-violet-500/20 overflow-hidden"
                >
                  <Send className="w-4 h-4 md:w-5 md:h-5 relative z-10" />
                  <AnimatePresence>
                    {wuuParticles.map(p => (
                      <motion.div
                        key={p.id}
                        initial={{ x: 0, y: 0, scale: 1, opacity: 1 }}
                        animate={{ x: p.x, y: p.y, scale: 0, opacity: 0 }}
                        exit={{ opacity: 0 }}
                        className="absolute inset-0 m-auto w-1 h-1 bg-cyan-400 rounded-full"
                      />
                    ))}
                  </AnimatePresence>
                </button>
              </div>
            </div>
            <p className="text-[8px] md:text-[10px] text-center text-zinc-600 mt-3 md:mt-4 font-mono uppercase tracking-[0.2em]">
              Powered by Kimi K2.5 & Cloudflare Wuu Engine
            </p>
          </div>

          {/* Deployment Status Panel (Overlay) */}
          {deployStatus && (
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              className="absolute bottom-0 left-0 right-0 border-t border-white/5 bg-black/80 backdrop-blur-xl p-4 flex items-center justify-between z-50"
            >
              <div className="flex items-center gap-3">
                <Zap className={cn(
                  "w-4 h-4",
                  deployStatus.status === 'success' ? "text-emerald-400" : "text-violet-400 animate-pulse"
                )} />
                <span className="text-[10px] font-medium text-zinc-300">{deployStatus.message}</span>
              </div>
              {deployStatus.url && (
                <a 
                  href={deployStatus.url} 
                  target="_blank" 
                  rel="noreferrer"
                  className="text-[10px] text-emerald-400 hover:underline flex items-center gap-1"
                >
                  Visit Site <Globe className="w-3 h-3" />
                </a>
              )}
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
