// Kimi AI Service
// This service handles communication with the Kimi-powered backend API
// All AI processing is done server-side with smart model routing

import { runCloudflareAi } from "./cloudflareAi";

// Export the main response generation function
// The backend handles all Kimi model routing and tool calling
export const generateMimoResponse = async (
  message: string,
  history: { role: 'user' | 'assistant', content: string }[],
  currentCode?: string,
  image?: string,
  onChunk?: (text: string) => void,
  settings?: any
) => {
  try {
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        messages: [
          ...history,
          { role: 'user', content: message }
        ],
        currentCode,
        image,
        settings
      }),
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.statusText}`);
    }

    if (!response.body) {
      throw new Error('No response body');
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let fullText = '';

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      
      const chunk = decoder.decode(value, { stream: true });
      const lines = chunk.split('\n');
      
      for (const line of lines) {
        if (line.startsWith('data: ') && line !== 'data: [DONE]') {
          try {
            const data = JSON.parse(line.slice(6));
            if (data.error) {
              throw new Error(data.error);
            }
            if (data.text) {
              fullText += data.text;
              if (onChunk) onChunk(fullText);
            }
          } catch (e) {
            // Ignore parse errors for incomplete chunks
          }
        }
      }
    }

    return fullText;
  } catch (error) {
    console.error("AI API Error:", error);
    throw error;
  }
};

// Re-export Cloudflare AI functions for compatibility
export { runCloudflareAi };
