
export interface CloudflareAiModel {
  id: string;
  name: string;
  type: 'llm' | 'image' | 'audio' | 'embedding' | 'other';
  description: string;
}

export const CLOUDFLARE_MODELS: CloudflareAiModel[] = [
  // LLMs
  { id: '@cf/meta/llama-3.2-3b-instruct', name: 'Llama 3.2 3B', type: 'llm', description: 'Fast, efficient instruction following' },
  { id: '@cf/meta/llama-3.1-8b-instruct-fp8-fast', name: 'Llama 3.1 8B Fast', type: 'llm', description: 'High performance 8B model' },
  { id: '@cf/meta/llama-3.3-70b-instruct-fp8-fast', name: 'Llama 3.3 70B Fast', type: 'llm', description: 'Powerful 70B model for complex tasks' },
  { id: '@cf/deepseek-ai/deepseek-r1-distill-qwen-32b', name: 'DeepSeek R1 32B', type: 'llm', description: 'Reasoning-focused model' },
  { id: '@cf/qwen/qwen2.5-coder-32b-instruct', name: 'Qwen 2.5 Coder 32B', type: 'llm', description: 'Specialized for code generation' },
  { id: '@cf/qwen/qwq-32b', name: 'QWQ 32B', type: 'llm', description: 'High-quality reasoning and problem-solving' },
  { id: '@cf/qwen/qwen3-30b-a3b-fp8', name: 'Qwen 3 30B', type: 'llm', description: 'Efficient general-purpose fallback' },
  { id: '@cf/openai/gpt-oss-120b', name: 'GPT-OSS 120B', type: 'llm', description: 'Massive scale open-source logic' },
  
  // Image
  { id: '@cf/black-forest-labs/flux-1-schnell', name: 'Flux.1 Schnell', type: 'image', description: 'High-quality fast image generation' },
  { id: '@cf/leonardo/phoenix-1.0', name: 'Leonardo Phoenix 1.0', type: 'image', description: 'Photorealistic image generation' },
  { id: '@cf/leonardo/lucid-origin', name: 'Leonardo Lucid Origin', type: 'image', description: 'Creative and stylized image generation' },
  
  // Audio
  { id: '@cf/openai/whisper', name: 'Whisper', type: 'audio', description: 'Speech-to-text transcription' },
  { id: '@cf/myshell-ai/melotts', name: 'MeloTTS', type: 'audio', description: 'Text-to-speech synthesis' },
];

export const runCloudflareAi = async (model: string, input: any) => {
  const response = await fetch('/api/ai/run', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model, input }),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(`Cloudflare AI Error: ${JSON.stringify(error)}`);
  }

  const contentType = response.headers.get("content-type");
  if (contentType?.includes("application/json")) {
    return await response.json();
  } else {
    const blob = await response.blob();
    return URL.createObjectURL(blob);
  }
};

export const transcribeAudio = async (audioBlob: Blob) => {
  const response = await fetch('/api/ai/transcribe', {
    method: 'POST',
    headers: { 'Content-Type': audioBlob.type },
    body: audioBlob,
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(`Transcription Error: ${JSON.stringify(error)}`);
  }

  return await response.json();
};
